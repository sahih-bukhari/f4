// اجرای فایل‌های SQL پوشه‌ی drizzle/ به ترتیب نام، فقط یک بار برای هر فایل.
// استفاده: npm run db:migrate   (متغیر DATABASE_URL لازم است)
import "dotenv/config";
import { readdirSync, readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

const url = process.env.DATABASE_URL;
if (!url) {
  console.error("DATABASE_URL تنظیم نشده است.");
  process.exit(1);
}

const dir = join(dirname(fileURLToPath(import.meta.url)), "..", "drizzle");
const files = readdirSync(dir).filter((f) => f.endsWith(".sql")).sort();

const client = new pg.Client({ connectionString: url });
await client.connect();
try {
  await client.query(
    "CREATE TABLE IF NOT EXISTS _migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())"
  );
  const done = new Set((await client.query("SELECT name FROM _migrations")).rows.map((r) => r.name));
  for (const f of files) {
    if (done.has(f)) {
      console.log(`- ${f} (قبلاً اجرا شده)`);
      continue;
    }
    const sql = readFileSync(join(dir, f), "utf8");
    await client.query("BEGIN");
    try {
      await client.query(sql);
      await client.query("INSERT INTO _migrations (name) VALUES ($1)", [f]);
      await client.query("COMMIT");
      console.log(`✓ ${f}`);
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    }
  }
  console.log("مایگریشن کامل شد.");
} finally {
  await client.end();
}
