import { and, eq, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { usage } from "@/db/schema";
import { DAILY_LIMITS, type Kind, type Tier } from "@/lib/limits";

export { DAILY_LIMITS };
export type { Kind };

export function todayKey(d = new Date()): string {
  return d.toISOString().slice(0, 10);
}

/**
 * مصرف یک واحد از سهمیه‌ی روزانه به‌صورت اتمیک.
 * اگر سقف پر باشد ok=false برمی‌گردد و چیزی افزوده نمی‌شود.
 */
export async function consumeQuota(
  key: string,
  kind: Kind,
  tier: Tier
): Promise<{ ok: boolean; used: number; limit: number }> {
  const limit = DAILY_LIMITS[tier][kind];
  const day = todayKey();
  const rows = await db
    .insert(usage)
    .values({ sessionId: key, day, kind, count: 1 })
    .onConflictDoUpdate({
      target: [usage.sessionId, usage.day, usage.kind],
      set: { count: sql`${usage.count} + 1` },
      setWhere: lt(usage.count, limit),
    })
    .returning({ count: usage.count });
  if (!rows.length) return { ok: false, used: limit, limit };
  return { ok: true, used: rows[0].count, limit };
}

/** برگرداندن یک واحد (مثلاً وقتی سرویس هوش مصنوعی خطا داد) */
export async function refundQuota(key: string, kind: Kind): Promise<void> {
  await db
    .update(usage)
    .set({ count: sql`GREATEST(${usage.count} - 1, 0)` })
    .where(and(eq(usage.sessionId, key), eq(usage.day, todayKey()), eq(usage.kind, kind)));
}

export async function getUsage(key: string): Promise<Record<Kind, number>> {
  const rows = await db
    .select({ kind: usage.kind, count: usage.count })
    .from(usage)
    .where(and(eq(usage.sessionId, key), eq(usage.day, todayKey())));
  const out: Record<Kind, number> = { chat: 0, build: 0 };
  for (const r of rows) out[r.kind] = r.count;
  return out;
}
