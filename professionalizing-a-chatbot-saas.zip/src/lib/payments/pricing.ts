/** توابع خالص قیمت‌گذاری و تمدید — بدون وابستگی به دیتابیس */

/** قیمت پلن حرفه‌ای برای هر ماه (به سنت)؛ قابل تنظیم با PRO_PRICE_CENTS */
export function monthlyPriceCents(): number {
  const n = Number(process.env.PRO_PRICE_CENTS);
  return Number.isInteger(n) && n > 0 ? n : 500;
}

export function priceCurrency(): string {
  return (process.env.PRO_CURRENCY || "usd").toLowerCase().slice(0, 3);
}

export const ALLOWED_MONTHS = [1, 3, 12] as const;

const DAY_MS = 24 * 60 * 60 * 1000;

/** تاریخ انقضای جدید: از بزرگ‌تر «الان» و «انقضای فعلی» ادامه می‌یابد */
export function extendExpiry(current: Date | null, days: number, now = new Date()): Date {
  const base = current && current.getTime() > now.getTime() ? current.getTime() : now.getTime();
  return new Date(base + days * DAY_MS);
}
