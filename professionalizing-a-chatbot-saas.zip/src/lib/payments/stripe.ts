import { createHmac, timingSafeEqual } from "crypto";
import type { CheckoutInput, CheckoutResult, PaymentProvider } from "./types";

/** Stripe Checkout از طریق REST (بدون SDK) */
export const stripeProvider: PaymentProvider = {
  id: "stripe",
  isConfigured: () => Boolean(process.env.STRIPE_SECRET_KEY),
  async createCheckout(input: CheckoutInput): Promise<CheckoutResult> {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) throw new Error("stripe_not_configured");

    const form = new URLSearchParams();
    form.set("mode", "payment");
    form.set("success_url", `${input.baseUrl}/pricing?paid=1`);
    form.set("cancel_url", `${input.baseUrl}/pricing?canceled=1`);
    form.set("client_reference_id", input.paymentId);
    form.set("customer_email", input.user.email);
    form.set("metadata[payment_id]", input.paymentId);
    form.set("line_items[0][quantity]", "1");
    form.set("line_items[0][price_data][currency]", input.currency);
    form.set("line_items[0][price_data][unit_amount]", String(input.amountCents));
    form.set("line_items[0][price_data][product_data][name]", `Nova Pro — ${input.months} month(s)`);

    const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/x-www-form-urlencoded" },
      body: form,
    });
    if (!res.ok) throw new Error(`stripe_${res.status}`);
    const data = (await res.json()) as { id?: string; url?: string };
    if (!data.id || !data.url) throw new Error("stripe_bad_response");
    return { externalId: data.id, redirectUrl: data.url };
  },
};

/**
 * بررسی امضای webhook استریپ (هدر Stripe-Signature: t=...,v1=...).
 * toleranceSec: حداکثر اختلاف زمانی مجاز برای جلوگیری از replay.
 */
export function verifyStripeSignature(
  rawBody: string,
  header: string | null,
  secret: string,
  toleranceSec = 300,
  nowSec = Math.floor(Date.now() / 1000)
): boolean {
  if (!header) return false;
  const parts = header.split(",").map((p) => p.trim().split("="));
  const t = parts.find(([k]) => k === "t")?.[1];
  const sigs = parts.filter(([k]) => k === "v1").map(([, v]) => v);
  if (!t || !sigs.length) return false;
  const ts = Number(t);
  if (!Number.isFinite(ts) || Math.abs(nowSec - ts) > toleranceSec) return false;
  const expected = createHmac("sha256", secret).update(`${t}.${rawBody}`).digest("hex");
  const expBuf = Buffer.from(expected, "hex");
  return sigs.some((s) => {
    try {
      const b = Buffer.from(s, "hex");
      return b.length === expBuf.length && timingSafeEqual(b, expBuf);
    } catch {
      return false;
    }
  });
}
