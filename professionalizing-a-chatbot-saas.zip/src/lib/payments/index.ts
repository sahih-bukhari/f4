import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { payments, users } from "@/db/schema";
import { manualProvider } from "./manual";
import { stripeProvider } from "./stripe";
import { extendExpiry } from "./pricing";
import type { PaymentProvider } from "./types";

const registry: Record<string, PaymentProvider> = {
  [manualProvider.id]: manualProvider,
  [stripeProvider.id]: stripeProvider,
};

export function getProvider(id: string): PaymentProvider | null {
  const p = registry[id];
  return p && p.isConfigured() ? p : null;
}

export function availableProviders(): string[] {
  return Object.values(registry)
    .filter((p) => p.isConfigured())
    .map((p) => p.id);
}

export { ALLOWED_MONTHS, extendExpiry, monthlyPriceCents, priceCurrency } from "./pricing";

/**
 * تأیید پرداخت — ایدمپوتنت: فقط اگر وضعیت هنوز pending باشد پلن فعال می‌شود،
 * پس webhook تکراری یا کلیک دوباره‌ی ادمین اشتراک را دوباره تمدید نمی‌کند.
 */
export async function markPaid(paymentId: string): Promise<boolean> {
  return db.transaction(async (tx) => {
    const updated = await tx
      .update(payments)
      .set({ status: "paid", paidAt: new Date() })
      .where(and(eq(payments.id, paymentId), eq(payments.status, "pending")))
      .returning();
    if (!updated.length) return false;
    const pay = updated[0];
    const rows = await tx.select().from(users).where(eq(users.id, pay.userId)).limit(1);
    const user = rows[0];
    if (!user) return false;
    const expires = extendExpiry(user.plan === "pro" ? user.planExpiresAt : null, pay.months * 30);
    await tx.update(users).set({ plan: "pro", planExpiresAt: expires }).where(eq(users.id, user.id));
    return true;
  });
}
