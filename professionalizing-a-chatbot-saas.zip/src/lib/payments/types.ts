import type { User } from "@/db/schema";

export type CheckoutInput = {
  user: User;
  paymentId: string;
  months: number;
  amountCents: number;
  currency: string;
  baseUrl: string;
};

export type CheckoutResult = {
  /** شناسه‌ی سمت درگاه یا کد پیگیری */
  externalId: string;
  /** اگر درگاه آنلاین است: آدرس پرداخت */
  redirectUrl?: string;
  /** اگر پرداخت دستی است: راهنمای پرداخت برای نمایش به کاربر */
  instructions?: string;
};

/**
 * اینترفیس مستقل از درگاه پرداخت — برای افزودن درگاه تازه فقط یک پیاده‌سازی جدید
 * و ثبت آن در registry (src/lib/payments/index.ts) کافی است.
 */
export interface PaymentProvider {
  readonly id: string;
  isConfigured(): boolean;
  createCheckout(input: CheckoutInput): Promise<CheckoutResult>;
}
