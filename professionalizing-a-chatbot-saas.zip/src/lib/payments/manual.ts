import type { CheckoutInput, CheckoutResult, PaymentProvider } from "./types";

/**
 * پرداخت دستی (کارت‌به‌کارت، حواله، حساب موبایلی و…):
 * کاربر درخواست را ثبت می‌کند، طبق راهنما پول را می‌فرستد و ادمین در پنل تأیید می‌کند.
 * متن راهنما از MANUAL_PAYMENT_INSTRUCTIONS خوانده می‌شود.
 */
export const manualProvider: PaymentProvider = {
  id: "manual",
  isConfigured: () => true,
  async createCheckout(input: CheckoutInput): Promise<CheckoutResult> {
    const code = `NV-${input.paymentId.slice(0, 8).toUpperCase()}`;
    const amount = (input.amountCents / 100).toFixed(2);
    const base =
      process.env.MANUAL_PAYMENT_INSTRUCTIONS?.trim() ||
      "برای پرداخت با ادمین هماهنگ کن و کد پیگیری را همراه رسید بفرست.";
    return {
      externalId: code,
      instructions: `${base}\n\nمبلغ: ${amount} ${input.currency.toUpperCase()}\nکد پیگیری: ${code}`,
    };
  },
};
