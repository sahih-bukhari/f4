import { checkRateLimit } from "@/lib/security";

/**
 * محدودیت درخواست پایدار.
 * اگر UPSTASH_REDIS_REST_URL و UPSTASH_REDIS_REST_TOKEN تنظیم باشند از Redis (پنجره‌ی ثابت)
 * استفاده می‌شود تا بین چند نمونه‌ی سرور مشترک باشد؛ در غیر این صورت (یا در صورت خطا)
 * به محدودیت درون‌حافظه‌ای قبلی برمی‌گردد.
 */

export type RateResult = { ok: boolean; retryAfterSec: number };

function redisConfig(): { url: string; token: string } | null {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return null;
  return { url: url.replace(/\/$/, ""), token };
}

export async function rateLimit(key: string, limit: number, windowMs: number): Promise<RateResult> {
  const cfg = redisConfig();
  if (!cfg) return checkRateLimit(key, limit, windowMs);

  const now = Date.now();
  const bucket = Math.floor(now / windowMs);
  const redisKey = `rl:${key}:${bucket}`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 1500);
  try {
    const res = await fetch(`${cfg.url}/pipeline`, {
      method: "POST",
      headers: { Authorization: `Bearer ${cfg.token}`, "Content-Type": "application/json" },
      body: JSON.stringify([
        ["INCR", redisKey],
        ["PEXPIRE", redisKey, String(windowMs), "NX"],
      ]),
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`redis ${res.status}`);
    const data = (await res.json()) as { result?: unknown }[];
    const count = Number(data?.[0]?.result);
    if (!Number.isFinite(count)) throw new Error("bad redis response");
    if (count > limit) {
      const retryAfterSec = Math.max(1, Math.ceil(((bucket + 1) * windowMs - now) / 1000));
      return { ok: false, retryAfterSec };
    }
    return { ok: true, retryAfterSec: 0 };
  } catch {
    return checkRateLimit(key, limit, windowMs);
  } finally {
    clearTimeout(timer);
  }
}

/** چند پنجره را هم‌زمان بررسی می‌کند؛ اولین مسدودشده را برمی‌گرداند */
export async function rateLimitAll(
  rules: { key: string; limit: number; windowMs: number }[]
): Promise<RateResult> {
  const results = await Promise.all(rules.map((r) => rateLimit(r.key, r.limit, r.windowMs)));
  const blocked = results.find((r) => !r.ok);
  return blocked ?? { ok: true, retryAfterSec: 0 };
}
