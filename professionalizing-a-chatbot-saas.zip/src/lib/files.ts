import { unzipSync } from "fflate";

/**
 * پردازش امن آپلودها:
 *  - وایت‌لیست پسوندهای متنی + زیپ (با بررسی Magic Bytes)
 *  - ضد Zip Bomb: سقف حجم خروجی фактических داده‌ها و تعداد ورودی‌ها
 *  - ضد Path Traversal: ورودی‌های شامل «..» یا مسیر مطلق حذف می‌شوند
 *  - تشخیص باینری (بایت NUL) و رد آن‌ها
 *  - استخراج متن پاک‌سازی‌شده با سقف نویسه — هیچ‌وقت چیزی «اجرا» نمی‌شود
 */

export const UPLOAD_RULES = {
  maxFileBytes: 5 * 1024 * 1024, // ۵ مگابایت برای هر فایل
  maxFilesPerRequest: 3,
  maxExtractChars: 8000, // برای هر فایل
  zipMaxEntries: 200,
  zipMaxUncompressedBytes: 2 * 1024 * 1024, // مجموع حجم بازشده
} as const;

const TEXT_EXTS = new Set([
  "txt", "md", "markdown", "csv", "tsv", "json", "jsonl", "log",
  "js", "mjs", "cjs", "ts", "tsx", "jsx", "py", "rb", "go", "rs",
  "html", "htm", "css", "scss", "sql", "yml", "yaml", "xml", "env",
  "toml", "ini", "cfg", "conf", "sh", "bat", "java", "c", "cpp", "h",
]);

const CONTROL_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u2028\u2029]/g;

export type ExtractedFile = {
  name: string;
  ext: string;
  extract: string;
  sizeBytes: number;
};

type Fail = { error: string };

function extOf(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}

function cleanName(name: string): string {
  return name
    .replace(/[\u0000-\u001F]/g, "")
    .replace(/[/\\]/g, "-")
    .trim()
    .slice(0, 120) || "file";
}

/** تشخیص باینری: وجود بایت NUL در نمونه‌ی اولیه */
function looksBinary(buf: Uint8Array): boolean {
  const head = buf.subarray(0, Math.min(512, buf.length));
  for (const b of head) if (b === 0) return true;
  return false;
}

function decodeAndClean(buf: Uint8Array): string {
  const text = new TextDecoder("utf-8", { fatal: false }).decode(buf);
  return text
    .replace(CONTROL_CHARS, " ")
    .replace(/ {3,}/g, "  ")
    .replace(/\n{4,}/g, "\n\n\n")
    .trim()
    .slice(0, UPLOAD_RULES.maxExtractChars);
}

function isSafeZipPath(p: string): boolean {
  if (!p || p.length > 200) return false;
  if (p.startsWith("/") || p.startsWith("\\") || /^[a-z]:/i.test(p)) return false;
  return !p.split(/[/\\]/).some((seg) => seg === "..");
}

/**
 * ورودی: بافر خام فایل آپلودی.
 * خروجی: لیست فایل‌های متنی استخراج‌شده (برای زیپ ممکن است چندتا باشد).
 */
export function processUpload(buf: Uint8Array, filename: string): ExtractedFile[] | Fail {
  if (buf.length > UPLOAD_RULES.maxFileBytes) {
    return { error: "file_too_large" };
  }
  const ext = extOf(filename);

  // ——— ZIP ———
  if (ext === "zip") {
    // Magic bytes: PK
    if (buf.length < 4 || buf[0] !== 0x50 || buf[1] !== 0x4b) {
      return { error: "bad_zip" };
    }
    let entries: Record<string, Uint8Array>;
    try {
      entries = unzipSync(buf);
    } catch {
      return { error: "bad_zip" };
    }
    const out: ExtractedFile[] = [];
    let totalRaw = 0;
    const names = Object.keys(entries);
    if (names.length > UPLOAD_RULES.zipMaxEntries) {
      return { error: "zip_too_many" };
    }
    const zipBase = cleanName(filename.replace(/\.zip$/i, ""));
    for (const rawPath of names) {
      const p = rawPath.replace(/\\/g, "/");
      if (p.endsWith("/")) continue; // دایرکتوری
      if (!isSafeZipPath(p)) continue; // ضد traversal
      const innerExt = extOf(p);
      if (!TEXT_EXTS.has(innerExt)) continue; // فقط متنی‌ها
      const data = entries[rawPath];
      totalRaw += data.length;
      if (totalRaw > UPLOAD_RULES.zipMaxUncompressedBytes) continue; // ضد بمب
      if (looksBinary(data)) continue;
      const extract = decodeAndClean(data);
      if (!extract) continue;
      out.push({
        name: `${zipBase} › ${cleanName(p.split("/").pop() ?? p)}`,
        ext: innerExt,
        extract,
        sizeBytes: data.length,
      });
      if (out.length >= 20) break;
    }
    if (!out.length) return { error: "zip_no_text" };
    return out;
  }

  // ——— فایل متنی تکی ———
  if (!TEXT_EXTS.has(ext)) return { error: "bad_type" };
  if (looksBinary(buf)) return { error: "binary" };
  const extract = decodeAndClean(buf);
  if (!extract) return { error: "empty" };
  return [
    {
      name: cleanName(filename),
      ext,
      extract,
      sizeBytes: buf.length,
    },
  ];
}

/** ساخت بلوک کانتکست پیوست برای تزریق به پرامپت مدل */
export function buildAttachmentsContext(
  files: { name: string; extract: string }[],
  lang: "fa" | "en"
): string {
  if (!files.length) return "";
  const header =
    lang === "fa"
      ? "کاربر این فایل‌ها را پیوست کرده است — محتوای آن‌ها را در پاسخ لحاظ کن:"
      : "The user attached these files — consider their contents in your answer:";
  let budget = 9000;
  const parts: string[] = [header];
  for (const f of files.slice(0, 3)) {
    const body = f.extract.slice(0, Math.max(500, Math.min(3000, budget)));
    parts.push(`\n<file name="${f.name}">\n${body}\n</file>`);
    budget -= body.length;
    if (budget <= 500) break;
  }
  return parts.join("\n");
}
