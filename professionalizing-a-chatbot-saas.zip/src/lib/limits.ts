export type Tier = "guest" | "free" | "pro";
export type Kind = "chat" | "build";

/** سقف روزانه برای هر پلن (UTC) — فایل خالص، قابل استفاده در کلاینت */
export const DAILY_LIMITS: Record<Tier, Record<Kind, number>> = {
  guest: { chat: 10, build: 1 },
  free: { chat: 30, build: 2 },
  pro: { chat: 500, build: 50 },
};
