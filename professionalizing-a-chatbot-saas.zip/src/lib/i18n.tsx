"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";

export type Lang = "fa" | "en";

const fa = {
  dir: "rtl" as "rtl" | "ltr",
  langLabel: "English",
  online: "آنلاین و آماده",
  modelOn: (m: string) => `مدل ${m}`,
  modelOff: "نیازمند پیکربندی کلید",
  bannerA: "پاسخ‌گویی هوش مصنوعی فعلاً فعال نیست — برای انتشار عمومی، متغیر محیطی",
  bannerB: "را تنظیم کنید.",
  newChat: "گفت‌وگوی جدید",
  searchPh: "جست‌وجو در گفت‌وگوها…",
  emptyChats: "هنوز گفت‌وگویی نداری",
  noResults: "چیزی پیدا نشد",
  delQ: "حذف شود؟",
  yes: "بله",
  no: "خیر",
  rename: "تغییر نام",
  del: "حذف",
  close: "بستن",
  secureFooter: "گفت‌وگوهای تو خصوصی و امن ذخیره می‌شوند",
  groupToday: "امروز",
  groupYesterday: "دیروز",
  groupOlder: "قدیمی‌تر",
  composerPh: "پیامت را بنویس… (Enter برای ارسال)",
  composerBusy: "نُوا دارد پاسخ می‌دهد…",
  send: "ارسال",
  stop: "توقف",
  stopAria: "توقف پاسخ",
  voice: "ورودی صوتی (فارسی)",
  voiceStop: "توقف ضبط",
  charsLeft: (n: string) => `${n} نویسه مانده`,
  disclaimer: "نُوا ممکن است اشتباه کند — اطلاعات مهم را بازبینی کنید.",
  newlineTip: "Shift+Enter خط جدید",
  newChatTip: "گفت‌وگوی جدید",
  jump: "پرش به پایین",
  thinking: "نُوا دارد فکر می‌کند…",
  copy: "کپی متن",
  copied: "کپی شد!",
  aiBadge: "هوش مصنوعی",
  morning: "صبح بخیر",
  noon: "ظهر بخیر",
  afternoon: "عصر بخیر",
  night: "شب بخیر",
  welcome: "خوش آمدی",
  heroTitle: "من نُوا هستم",
  heroSub:
    "دستیار هوش مصنوعی فارسی‌زبان تو — نگارش، برنامه‌نویسی، یادگیری و ایده‌پردازی. سؤالت را بپرس؛ گفت‌وگوها امن و دائمی ذخیره می‌شوند.",
  sug1t: "نگارش حرفه‌ای",
  sug1p: "یک ایمیل رسمی برای درخواست مرخصی بنویس",
  sug2t: "برنامه‌نویسی",
  sug2p: "تابعی در جاوااسکریپت بنویس که ایمیل را اعتبارسنجی کند",
  sug3t: "یادگیری مفاهیم",
  sug3p: "یادگیری ماشین را با یک مثال ساده توضیح بده",
  sug4t: "ایده‌پردازی",
  sug4p: "پنج ایده برای شروع یک کسب‌وکار آنلاین بده",
  defaultChatTitle: "گفت‌وگوی جدید",
  menu: "باز کردن منو",
  errNetwork: "ارتباط با سرور برقرار نشد.",
  errRateLimited: (sec: string) =>
    `برای جلوگیری از سوءاستفاده، ارسال پیام محدود شد. ${sec} ثانیه دیگر تلاش کن.`,
  errMissingKey: "سرویس هوش مصنوعی هنوز پیکربندی نشده است.",
  errTimeout: "پاسخ مدل بیش از حد طول کشید؛ دوباره تلاش کن.",
  errUpstream: "خطا در ارتباط با سرویس هوش مصنوعی.",
  errFull: "این گفت‌وگو پر شده است — یک گفت‌وگوی جدید بساز.",
  errDailyQuota: "سهمیه‌ی روزانه‌ات تمام شد — برای سقف بالاتر وارد شو یا پلن حرفه‌ای بگیر.",
  errBlocked: "این حساب مسدود شده است.",
  errGeneric: "مشکلی پیش آمد؛ لطفاً دوباره تلاش کن.",
  modeChat: "گفت‌وگو",
  modeBuild: "ساخت سایت و اپ",
  composerBuildPh: "سایت یا اپی که می‌خواهی را توصیف کن… مثلاً «یک لندینگ کافی‌شاپ»",
  stAnalyze: "تحلیل درخواست",
  stDesign: "طراحی ساختار و رابط کاربری",
  stCode: "تولید کد",
  stPreview: "آماده‌سازی پیش‌نمایش زنده",
  stFinish: "تکمیل و ذخیره",
  building: "نُوا دارد می‌سازد…",
  cancel: "انصراف",
  codeChars: (n: string) => `${n} نویسه کد تولید شد`,
  openPreview: "باز کردن پیش‌نمایش",
  buildCardSub: "ساخته‌شده با نُوا",
  previewTitle: "پیش‌نمایش زنده",
  copyCode: "کپی کد",
  downloadHtml: "دانلود HTML",
  openNewTab: "باز کردن در تب جدید",
  refresh: "تازه‌سازی پیش‌نمایش",
  errBuild: "ساخت ناموفق بود — دوباره تلاش کن.",
  buildTagline: "کافئ؛ تو بگو، نُوا می‌سازد",
  attach: "پیوست فایل",
  attachHint: "متن، کد، JSON، CSV یا ZIP — حداکثر ۵ مگابایت",
  attachErrSize: "حجم فایل بیش از ۵ مگابایت است",
  attachErrType: "این نوع فایل پشتیبانی نمی‌شود",
  attachErrMax: "حداکثر ۳ فایل می‌توانی بفرستی",
  attachUploading: "در حال آپلود فایل…",
  attachErr: "آپلود ناموفق بود — دوباره تلاش کن",
  filesTab: "فایل‌های پروژه",
  previewTab: "پیش‌نمایش زنده",
  downloadZip: "دانلود ZIP",
  backendBadge: "بک‌اند + دیتابیس",
  selectFile: "فایلی را برای مشاهده انتخاب کن",
  fileLines: (n: string) => `${n} خط`,
};

export type Dict = typeof fa;

const en: Dict = {
  dir: "ltr",
  langLabel: "فارسی",
  online: "Online and ready",
  modelOn: (m: string) => `Model ${m}`,
  modelOff: "API key required",
  bannerA: "AI responses are currently disabled — for public release, set the env var",
  bannerB: ".",
  newChat: "New chat",
  searchPh: "Search chats…",
  emptyChats: "No conversations yet",
  noResults: "Nothing found",
  delQ: "Delete it?",
  yes: "Yes",
  no: "No",
  rename: "Rename",
  del: "Delete",
  close: "Close",
  secureFooter: "Your conversations are stored privately and securely",
  groupToday: "Today",
  groupYesterday: "Yesterday",
  groupOlder: "Older",
  composerPh: "Type a message… (Enter to send)",
  composerBusy: "Nova is replying…",
  send: "Send",
  stop: "Stop",
  stopAria: "Stop generating",
  voice: "Voice input (English)",
  voiceStop: "Stop recording",
  charsLeft: (n: string) => `${n} characters left`,
  disclaimer: "Nova can make mistakes — verify important information.",
  newlineTip: "Shift+Enter newline",
  newChatTip: "New chat",
  jump: "Jump to bottom",
  thinking: "Nova is thinking…",
  copy: "Copy text",
  copied: "Copied!",
  aiBadge: "AI",
  morning: "Good morning",
  noon: "Good afternoon",
  afternoon: "Good afternoon",
  night: "Good evening",
  welcome: "Welcome",
  heroTitle: "I'm Nova",
  heroSub:
    "Your multilingual AI assistant — writing, coding, learning and brainstorming. Ask anything; conversations are stored securely and privately.",
  sug1t: "Professional writing",
  sug1p: "Write a formal leave-request email",
  sug2t: "Programming",
  sug2p: "Write a JavaScript function that validates an email",
  sug3t: "Learn concepts",
  sug3p: "Explain machine learning with a simple example",
  sug4t: "Brainstorming",
  sug4p: "Give me five ideas to start an online business",
  defaultChatTitle: "New chat",
  menu: "Open menu",
  errNetwork: "Could not reach the server.",
  errRateLimited: (sec: string) =>
    `Sending is rate-limited to prevent abuse. Try again in ${sec}s.`,
  errMissingKey: "The AI service is not configured yet.",
  errTimeout: "The model took too long; please try again.",
  errUpstream: "Failed to reach the AI service.",
  errFull: "This conversation is full — start a new chat.",
  errDailyQuota: "You have used today's quota — sign in or go Pro for a higher limit.",
  errBlocked: "This account has been blocked.",
  errGeneric: "Something went wrong; please try again.",
  modeChat: "Chat",
  modeBuild: "Build site & app",
  composerBuildPh: "Describe the site or app you want… e.g. “a coffee shop landing page”",
  stAnalyze: "Analyzing your request",
  stDesign: "Designing structure & UI",
  stCode: "Generating code",
  stPreview: "Preparing live preview",
  stFinish: "Finishing & saving",
  building: "Nova is building…",
  cancel: "Cancel",
  codeChars: (n: string) => `${n} characters of code generated`,
  openPreview: "Open preview",
  buildCardSub: "Built with Nova",
  previewTitle: "Live preview",
  copyCode: "Copy code",
  downloadHtml: "Download HTML",
  openNewTab: "Open in new tab",
  refresh: "Refresh preview",
  errBuild: "Build failed — please try again.",
  buildTagline: "You describe it, Nova builds it",
  attach: "Attach file",
  attachHint: "Text, code, JSON, CSV or ZIP — max 5MB",
  attachErrSize: "File is larger than 5MB",
  attachErrType: "This file type is not supported",
  attachErrMax: "You can attach up to 3 files",
  attachUploading: "Uploading file…",
  attachErr: "Upload failed — try again",
  filesTab: "Project files",
  previewTab: "Live preview",
  downloadZip: "Download ZIP",
  backendBadge: "Backend + Database",
  selectFile: "Select a file to view",
  fileLines: (n: string) => `${n} lines`,
};

export const DICTS: Record<Lang, Dict> = { fa, en };

/* ------------------------------- context --------------------------------- */

type LangCtxValue = {
  lang: Lang;
  t: Dict;
  toggle: () => void;
  setLang: (l: Lang) => void;
};

const LangCtx = createContext<LangCtxValue | null>(null);

const STORAGE_KEY = "nova_lang";

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("fa");

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === "fa" || saved === "en") setLangState(saved);
    } catch {
      /* noop */
    }
  }, []);

  const apply = useCallback((l: Lang) => {
    setLangState(l);
    try {
      localStorage.setItem(STORAGE_KEY, l);
    } catch {
      /* noop */
    }
    document.documentElement.lang = l;
    document.documentElement.dir = DICTS[l].dir;
  }, []);

  const toggle = useCallback(() => {
    apply(lang === "fa" ? "en" : "fa");
  }, [lang, apply]);

  return (
    <LangCtx.Provider value={{ lang, t: DICTS[lang], toggle, setLang: apply }}>
      {children}
    </LangCtx.Provider>
  );
}

export function useLang(): LangCtxValue {
  const ctx = useContext(LangCtx);
  if (!ctx) throw new Error("useLang must be used inside LangProvider");
  return ctx;
}
