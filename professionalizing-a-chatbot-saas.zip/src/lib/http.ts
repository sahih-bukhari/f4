import { NextResponse } from "next/server";
import { clientIp, isSameOrigin } from "@/lib/security";
import { rateLimitAll } from "@/lib/ratelimit";

export function jsonError(error: string, code: string, status: number, headers?: Record<string, string>) {
  return NextResponse.json({ error, code }, { status, headers });
}

/** بررسی‌های مشترک مسیرهای تغییردهنده: Same-Origin، JSON، اندازه‌ی بدنه */
export function guardJson(req: Request, maxBytes = 8 * 1024): NextResponse | null {
  if (!isSameOrigin(req)) return jsonError("Bad request.", "bad_request", 403);
  const ct = req.headers.get("content-type") ?? "";
  if (!ct.includes("application/json")) {
    return jsonError("نوع محتوا نامعتبر است.", "bad_request", 415);
  }
  if (Number(req.headers.get("content-length") ?? "0") > maxBytes) {
    return jsonError("بدنه‌ی درخواست بیش از حد بزرگ است.", "bad_request", 413);
  }
  return null;
}

/** محدودیت درخواست بر اساس IP؛ در صورت عبور از سقف، پاسخ 429 برمی‌گرداند */
export async function limitByIp(
  req: Request,
  name: string,
  rules: { limit: number; windowMs: number }[]
): Promise<NextResponse | null> {
  const ip = clientIp(req);
  const r = await rateLimitAll(
    rules.map((x) => ({ key: `${name}:${x.windowMs}:${ip}`, limit: x.limit, windowMs: x.windowMs }))
  );
  if (r.ok) return null;
  return NextResponse.json(
    { error: `محدودیت درخواست — ${r.retryAfterSec} ثانیه دیگر تلاش کن.`, code: "rate_limited", retryAfterSec: r.retryAfterSec },
    { status: 429, headers: { "Retry-After": String(r.retryAfterSec) } }
  );
}

export function publicUser(u: {
  id: string;
  email: string;
  role: string;
  plan: string;
  planExpiresAt: Date | null;
}, tier: string) {
  return {
    id: u.id,
    email: u.email,
    role: u.role,
    tier,
    planExpiresAt: u.planExpiresAt ? u.planExpiresAt.toISOString() : null,
  };
}
