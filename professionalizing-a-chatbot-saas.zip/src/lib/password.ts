import { randomBytes, scrypt as scryptCb, timingSafeEqual, createHash } from "crypto";

/**
 * هش رمز عبور با scrypt (داخلی Node — بدون وابستگی اضافه).
 * قالب ذخیره: scrypt$N$r$p$saltHex$hashHex
 */
const N = 16384;
const R = 8;
const P = 1;
const KEYLEN = 64;

function scrypt(password: string, salt: Buffer, keylen: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCb(password, salt, keylen, { N, r: R, p: P, maxmem: 64 * 1024 * 1024 }, (err, key) =>
      err ? reject(err) : resolve(key)
    );
  });
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await scrypt(password, salt, KEYLEN);
  return `scrypt$${N}$${R}$${P}$${salt.toString("hex")}$${key.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  try {
    const salt = Buffer.from(parts[4], "hex");
    const expected = Buffer.from(parts[5], "hex");
    // هش خراب/خالی هرگز نباید با هیچ رمزی تطابق پیدا کند
    if (salt.length !== 16 || expected.length !== KEYLEN) return false;
    const actual = await scrypt(password, salt, expected.length);
    return actual.length === expected.length && timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

/** توکن تصادفی ۲۵۶ بیتی (hex) */
export function randomToken(): string {
  return randomBytes(32).toString("hex");
}

export function sha256(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

/** حداقل کیفیت رمز: ۸ تا ۱۲۸ نویسه */
export function validatePassword(pw: string): boolean {
  return pw.length >= 8 && pw.length <= 128;
}

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}
