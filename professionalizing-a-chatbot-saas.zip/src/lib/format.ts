import type { Lang } from "./i18n";

const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";

/** اعداد را بر اساس زبان محلی‌سازی می‌کند */
export function num(input: string | number, lang: Lang): string {
  const s = String(input);
  return lang === "fa" ? s.replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]) : s;
}

export function formatTime(iso: string | Date, lang: Lang): string {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return d.toLocaleTimeString(lang === "fa" ? "fa-IR" : "en-US", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** برچسب زمانی نسبی برای لیست مکالمات */
export function relativeTime(iso: string | Date, lang: Lang): string {
  const date = typeof iso === "string" ? new Date(iso) : iso;
  const diff = Date.now() - date.getTime();
  const min = Math.floor(diff / 60000);
  const n = (v: number) => num(v, lang);
  if (lang === "fa") {
    if (min < 1) return "همین حالا";
    if (min < 60) return `${n(min)} دقیقه پیش`;
    const h = Math.floor(min / 60);
    if (h < 24) return `${n(h)} ساعت پیش`;
    const d2 = Math.floor(h / 24);
    if (d2 === 1) return "دیروز";
    if (d2 < 7) return `${n(d2)} روز پیش`;
    return date.toLocaleDateString("fa-IR");
  }
  if (min < 1) return "just now";
  if (min < 60) return `${n(min)}m ago`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${n(h)}h ago`;
  const d2 = Math.floor(h / 24);
  if (d2 === 1) return "yesterday";
  if (d2 < 7) return `${n(d2)}d ago`;
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}
