import { randomUUID } from "crypto";

/**
 * جلسه‌ی ناشناس برای ایزوله‌سازی گفت‌وگوهای هر بازدیدکننده.
 *  - کوکی HttpOnly: از JavaScript کلاینت غیرقابل خواندن است (ضد XSS سرقت)
 *  - SameSite=Lax: از ارسال متقابل توسط سایت‌های دیگر جلوگیری می‌کند (ضد CSRF)
 *  - Secure در پروداکشن: فقط روی HTTPS
 *  - مقدار ۱۲۸ بیت تصادفی: حدس‌زدن عملاً ناممکن است
 */

export const SESSION_COOKIE = "nova_sid";

/** خواندن امن شناسه‌ی جلسه از هدر کوکی (فقط UUID معتبر پذیرفته می‌شود) */
export function getSessionId(req: Request): string | null {
  const cookie = req.headers.get("cookie");
  if (!cookie) return null;
  const m = cookie.match(
    new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})`, "i")
  );
  return m?.[1] ?? null;
}

export function newSessionId(): string {
  return randomUUID();
}

/** ساخت مقدار Set-Cookie با پرچم‌های امنیتی کامل */
export function buildSessionCookie(id: string): string {
  const maxAge = 60 * 60 * 24 * 365; // یک سال
  const parts = [
    `${SESSION_COOKIE}=${id}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    `Max-Age=${maxAge}`,
  ];
  if (process.env.NODE_ENV === "production") parts.push("Secure");
  return parts.join("; ");
}
