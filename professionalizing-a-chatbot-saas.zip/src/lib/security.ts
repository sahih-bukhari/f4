/**
 * لایه‌ی امنیتی سمت سرور:
 *  - Rate limiting پنجره‌ی لغزان (درون‌حافظه‌ای — در استقرار چندنمونه‌ای از Redis استفاده کنید)
 *  - استخراج امن IP کلاینت از هدرهای پروکسی
 *  - بررسی Same-Origin برای درخواست‌های تغییردهنده (ضد CSRF)
 *  - پاک‌سازی ورودی کاربر از نویسه‌های کنترلی مخرب
 */

type Window = { hits: number[] };

const store = new Map<string, Window>();
const MAX_KEYS = 5000;

/** پنجره‌ی لغزان: بیشتر از limit بار در windowMs مجاز نیست */
export function checkRateLimit(
  key: string,
  limit: number,
  windowMs: number
): { ok: boolean; retryAfterSec: number } {
  const now = Date.now();

  // جمع‌آوری زباله وقتی نقشه بزرگ شد
  if (store.size > MAX_KEYS) {
    for (const [k, w] of store) {
      w.hits = w.hits.filter((t) => now - t < windowMs);
      if (w.hits.length === 0) store.delete(k);
    }
  }

  let w = store.get(key);
  if (!w) {
    w = { hits: [] };
    store.set(key, w);
  }
  w.hits = w.hits.filter((t) => now - t < windowMs);

  if (w.hits.length >= limit) {
    const oldest = w.hits[0];
    return {
      ok: false,
      retryAfterSec: Math.max(1, Math.ceil((oldest + windowMs - now) / 1000)),
    };
  }
  w.hits.push(now);
  return { ok: true, retryAfterSec: 0 };
}

/** استخراج IP واقعی کلاینت از پشت پروکسی */
export function clientIp(req: Request): string {
  const h = req.headers;
  const fwd = h.get("x-forwarded-for");
  if (fwd) {
    const first = fwd.split(",")[0]?.trim();
    if (first) return first.slice(0, 64);
  }
  return (h.get("x-real-ip") ?? "unknown").slice(0, 64);
}

/**
 * بررسی Same-Origin برای جلوگیری از CSRF از راه یک سایت دیگر.
 * اگر هدر Origin وجود دارد باید با میزبان درخواست یکی باشد.
 */
export function isSameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return true; // درخواست‌های غیرمرورگری معمولاً Origin ندارند
  const host = req.headers.get("host");
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

const CONTROL_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u2028\u2029]/g;

/** پاک‌سازی متن ورودی کاربر از نویسه‌های کنترلی (به‌جز خط جدید و تب) */
export function sanitizeUserText(input: string): string {
  return input
    .replace(CONTROL_CHARS, " ")
    .replace(/ {3,}/g, "  ")
    .trim();
}
