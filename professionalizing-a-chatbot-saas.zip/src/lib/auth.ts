import { and, eq, gt, ne } from "drizzle-orm";
import { db } from "@/db";
import { authSessions, builds, conversations, uploads, users, type User } from "@/db/schema";
import { randomToken, sha256 } from "@/lib/password";
import { getSessionId, newSessionId } from "@/lib/session";
import type { Tier } from "@/lib/limits";

export const AUTH_COOKIE = "nova_auth";
const AUTH_MAX_AGE_SEC = 60 * 60 * 24 * 30; // ۳۰ روز

function cookieFlags(maxAge: number): string {
  const parts = ["Path=/", "HttpOnly", "SameSite=Lax", `Max-Age=${maxAge}`];
  if (process.env.NODE_ENV === "production") parts.push("Secure");
  return parts.join("; ");
}

export function buildAuthCookie(token: string): string {
  return `${AUTH_COOKIE}=${token}; ${cookieFlags(AUTH_MAX_AGE_SEC)}`;
}

export function clearAuthCookie(): string {
  return `${AUTH_COOKIE}=; ${cookieFlags(0)}`;
}

export function getAuthToken(req: Request): string | null {
  const cookie = req.headers.get("cookie");
  if (!cookie) return null;
  const m = cookie.match(new RegExp(`(?:^|;\\s*)${AUTH_COOKIE}=([0-9a-f]{64})`));
  return m?.[1] ?? null;
}

/** ساخت نشست ورود جدید؛ توکن خام برگردانده می‌شود و فقط هش آن در دیتابیس می‌ماند */
export async function createAuthSession(userId: string): Promise<string> {
  const token = randomToken();
  await db.insert(authSessions).values({
    tokenHash: sha256(token),
    userId,
    expiresAt: new Date(Date.now() + AUTH_MAX_AGE_SEC * 1000),
  });
  return token;
}

export async function destroyAuthSession(token: string): Promise<void> {
  await db.delete(authSessions).where(eq(authSessions.tokenHash, sha256(token)));
}

/** کاربر واردشده‌ی این درخواست (یا null) */
export async function getCurrentUser(req: Request): Promise<User | null> {
  const token = getAuthToken(req);
  if (!token) return null;
  const rows = await db
    .select({ user: users })
    .from(authSessions)
    .innerJoin(users, eq(users.id, authSessions.userId))
    .where(and(eq(authSessions.tokenHash, sha256(token)), gt(authSessions.expiresAt, new Date())))
    .limit(1);
  return rows[0]?.user ?? null;
}

export type { Tier };

/** پلن مؤثر: pro فقط تا زمان انقضا معتبر است */
export function tierOf(user: User | null): Tier {
  if (!user) return "guest";
  if (user.plan === "pro" && (!user.planExpiresAt || user.planExpiresAt.getTime() > Date.now())) {
    return "pro";
  }
  return "free";
}

/** آیا این sessionId پیش‌تر به یک کاربر ثبت‌نام‌شده تعلق دارد؟ */
export async function sessionBelongsToUser(sid: string): Promise<boolean> {
  const rows = await db.select({ id: users.id }).from(users).where(eq(users.sessionId, sid)).limit(1);
  return rows.length > 0;
}

/**
 * انتقال داده‌های مهمان (گفتگو، ساخت‌ها، فایل‌ها) به شناسه‌ی جلسه‌ی کاربر.
 * فقط وقتی انجام می‌شود که جلسه‌ی مهمان متعلق به کاربر دیگری نباشد.
 */
export async function mergeGuestData(guestSid: string | null, userSid: string): Promise<void> {
  if (!guestSid || guestSid === userSid) return;
  if (await sessionBelongsToUser(guestSid)) return;
  await db.transaction(async (tx) => {
    await tx.update(conversations).set({ sessionId: userSid }).where(eq(conversations.sessionId, guestSid));
    await tx.update(builds).set({ sessionId: userSid }).where(eq(builds.sessionId, guestSid));
    await tx.update(uploads).set({ sessionId: userSid }).where(eq(uploads.sessionId, guestSid));
  });
}

/**
 * شناسه‌ی جلسه‌ی مناسب برای کاربر تازه: جلسه‌ی مهمان فعلی (تا داده‌ها همراهش بمانند)،
 * مگر اینکه قبلاً مال کاربر دیگری باشد.
 */
export async function pickSessionIdForNewUser(req: Request): Promise<string> {
  const guest = getSessionId(req);
  if (guest && !(await sessionBelongsToUser(guest))) return guest;
  return newSessionId();
}

export async function countOtherAdmins(exceptId: string): Promise<number> {
  const rows = await db
    .select({ id: users.id })
    .from(users)
    .where(and(eq(users.role, "admin"), ne(users.id, exceptId), eq(users.blocked, false)));
  return rows.length;
}

/**
 * شناسه‌ی جلسه‌ی مؤثر این درخواست:
 * کاربر واردشده ← همیشه sessionId خودش (حتی اگر کوکی nova_sid پاک شده باشد)،
 * مهمان ← مقدار کوکی (ممکن است null باشد).
 */
export async function resolveSession(
  req: Request
): Promise<{ user: User | null; sessionId: string | null; tier: Tier }> {
  const user = await getCurrentUser(req);
  return {
    user,
    sessionId: user ? user.sessionId : getSessionId(req),
    tier: tierOf(user),
  };
}

/** فقط ادمین فعال؛ در غیر این صورت null */
export async function requireAdmin(req: Request): Promise<User | null> {
  const user = await getCurrentUser(req);
  return user && user.role === "admin" && !user.blocked ? user : null;
}
