import { describe, expect, it } from "vitest";
import { checkRateLimit, clientIp, isSameOrigin, sanitizeUserText } from "@/lib/security";

describe("checkRateLimit", () => {
  it("بعد از سقف مسدود می‌کند و retryAfter می‌دهد", () => {
    const key = `t:${Math.random()}`;
    expect(checkRateLimit(key, 2, 60_000).ok).toBe(true);
    expect(checkRateLimit(key, 2, 60_000).ok).toBe(true);
    const third = checkRateLimit(key, 2, 60_000);
    expect(third.ok).toBe(false);
    expect(third.retryAfterSec).toBeGreaterThan(0);
  });

  it("کلیدهای مختلف مستقل‌اند", () => {
    const a = `a:${Math.random()}`;
    const b = `b:${Math.random()}`;
    checkRateLimit(a, 1, 60_000);
    expect(checkRateLimit(a, 1, 60_000).ok).toBe(false);
    expect(checkRateLimit(b, 1, 60_000).ok).toBe(true);
  });
});

describe("isSameOrigin", () => {
  const mk = (headers: Record<string, string>) => new Request("https://x.test/api", { headers });
  it("بدون Origin مجاز است", () => {
    expect(isSameOrigin(mk({ host: "x.test" }))).toBe(true);
  });
  it("Origin هم‌میزبان مجاز و غیرهم‌میزبان رد می‌شود", () => {
    expect(isSameOrigin(mk({ host: "x.test", origin: "https://x.test" }))).toBe(true);
    expect(isSameOrigin(mk({ host: "x.test", origin: "https://evil.test" }))).toBe(false);
    expect(isSameOrigin(mk({ host: "x.test", origin: "not a url" }))).toBe(false);
  });
});

describe("clientIp و sanitizeUserText", () => {
  it("اولین IP از x-forwarded-for", () => {
    const r = new Request("https://x.test", { headers: { "x-forwarded-for": "1.2.3.4, 5.6.7.8" } });
    expect(clientIp(r)).toBe("1.2.3.4");
  });
  it("نویسه‌های کنترلی پاک می‌شوند و خط جدید می‌ماند", () => {
    expect(sanitizeUserText("a\u0000b\u0007c\nd")).toBe("a b c\nd");
  });
});
