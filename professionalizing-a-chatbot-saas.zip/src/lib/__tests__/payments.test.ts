import { createHmac } from "node:crypto";
import { afterEach, describe, expect, it } from "vitest";
import { ALLOWED_MONTHS, extendExpiry, monthlyPriceCents, priceCurrency } from "@/lib/payments/pricing";
import { verifyStripeSignature } from "@/lib/payments/stripe";
import { DAILY_LIMITS } from "@/lib/limits";

const DAY = 24 * 60 * 60 * 1000;

describe("extendExpiry", () => {
  const now = new Date("2026-01-01T00:00:00Z");
  it("بدون اشتراک فعال از «الان» شروع می‌شود", () => {
    expect(extendExpiry(null, 30, now).getTime()).toBe(now.getTime() + 30 * DAY);
  });
  it("اشتراک منقضی‌شده از «الان» ادامه می‌یابد", () => {
    const old = new Date("2025-06-01T00:00:00Z");
    expect(extendExpiry(old, 30, now).getTime()).toBe(now.getTime() + 30 * DAY);
  });
  it("اشتراک فعال از انقضای فعلی تمدید می‌شود", () => {
    const future = new Date(now.getTime() + 10 * DAY);
    expect(extendExpiry(future, 30, now).getTime()).toBe(future.getTime() + 30 * DAY);
  });
});

describe("قیمت", () => {
  const orig = { ...process.env };
  afterEach(() => {
    process.env = { ...orig };
  });
  it("پیش‌فرض و override از env", () => {
    delete process.env.PRO_PRICE_CENTS;
    expect(monthlyPriceCents()).toBe(500);
    process.env.PRO_PRICE_CENTS = "900";
    expect(monthlyPriceCents()).toBe(900);
    process.env.PRO_PRICE_CENTS = "abc";
    expect(monthlyPriceCents()).toBe(500);
    process.env.PRO_CURRENCY = "EUR";
    expect(priceCurrency()).toBe("eur");
    expect(ALLOWED_MONTHS).toContain(12);
  });
  it("سقف‌ها به‌ترتیب guest < free < pro", () => {
    expect(DAILY_LIMITS.guest.chat).toBeLessThan(DAILY_LIMITS.free.chat);
    expect(DAILY_LIMITS.free.chat).toBeLessThan(DAILY_LIMITS.pro.chat);
  });
});

describe("verifyStripeSignature", () => {
  const secret = "whsec_test";
  const body = '{"type":"checkout.session.completed"}';
  const now = 1_800_000_000;
  const sign = (t: number, b = body) => createHmac("sha256", secret).update(`${t}.${b}`).digest("hex");

  it("امضای درست پذیرفته می‌شود", () => {
    const h = `t=${now},v1=${sign(now)}`;
    expect(verifyStripeSignature(body, h, secret, 300, now)).toBe(true);
  });
  it("بدنه‌ی دستکاری‌شده رد می‌شود", () => {
    const h = `t=${now},v1=${sign(now)}`;
    expect(verifyStripeSignature(body + " ", h, secret, 300, now)).toBe(false);
  });
  it("امضای قدیمی (replay) رد می‌شود", () => {
    const old = now - 1000;
    const h = `t=${old},v1=${sign(old)}`;
    expect(verifyStripeSignature(body, h, secret, 300, now)).toBe(false);
  });
  it("هدر خالی یا ناقص رد می‌شود", () => {
    expect(verifyStripeSignature(body, null, secret, 300, now)).toBe(false);
    expect(verifyStripeSignature(body, "t=1", secret, 300, now)).toBe(false);
    expect(verifyStripeSignature(body, `t=${now},v1=zz`, secret, 300, now)).toBe(false);
  });
});
