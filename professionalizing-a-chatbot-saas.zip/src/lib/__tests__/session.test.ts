import { describe, expect, it } from "vitest";
import { buildSessionCookie, getSessionId, newSessionId } from "@/lib/session";

describe("session", () => {
  it("شناسه‌ی UUID از کوکی خوانده می‌شود", () => {
    const id = newSessionId();
    const req = new Request("https://x.test", { headers: { cookie: `a=1; nova_sid=${id}; b=2` } });
    expect(getSessionId(req)).toBe(id);
  });
  it("مقدار نامعتبر پذیرفته نمی‌شود", () => {
    const req = new Request("https://x.test", { headers: { cookie: "nova_sid=not-a-uuid" } });
    expect(getSessionId(req)).toBeNull();
  });
  it("کوکی پرچم‌های امنیتی دارد", () => {
    const c = buildSessionCookie(newSessionId());
    expect(c).toContain("HttpOnly");
    expect(c).toContain("SameSite=Lax");
  });
});
