import { describe, expect, it } from "vitest";
import {
  hashPassword,
  normalizeEmail,
  randomToken,
  sha256,
  validatePassword,
  verifyPassword,
} from "@/lib/password";

describe("password", () => {
  it("hash و verify درست کار می‌کنند", async () => {
    const h = await hashPassword("correct horse battery");
    expect(h.startsWith("scrypt$")).toBe(true);
    expect(await verifyPassword("correct horse battery", h)).toBe(true);
    expect(await verifyPassword("wrong password", h)).toBe(false);
  });

  it("هر بار salt متفاوت دارد", async () => {
    const a = await hashPassword("same-password");
    const b = await hashPassword("same-password");
    expect(a).not.toBe(b);
  });

  it("هش خراب یا ساختگی را رد می‌کند", async () => {
    expect(await verifyPassword("x", "garbage")).toBe(false);
    expect(await verifyPassword("x", "scrypt$1$2$3$zz$zz")).toBe(false);
  });

  it("اعتبارسنجی رمز و ایمیل", () => {
    expect(validatePassword("1234567")).toBe(false);
    expect(validatePassword("12345678")).toBe(true);
    expect(validatePassword("x".repeat(129))).toBe(false);
    expect(normalizeEmail("  Test@Example.COM ")).toBe("test@example.com");
  });

  it("توکن تصادفی ۶۴ نویسه‌ی hex است و sha256 پایدار است", () => {
    expect(randomToken()).toMatch(/^[0-9a-f]{64}$/);
    expect(randomToken()).not.toBe(randomToken());
    expect(sha256("abc")).toBe("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  });
});
