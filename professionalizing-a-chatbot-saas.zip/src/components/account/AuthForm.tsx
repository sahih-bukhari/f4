"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { errText } from "@/lib/account-i18n";
import { PageShell } from "./PageShell";
import { btnCls, cardCls, inputCls, sendJson, useA } from "./hooks";

type Mode = "login" | "register" | "forgot" | "reset";

function Form({ mode }: { mode: Mode }) {
  const { a } = useA();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  useEffect(() => {
    if (mode === "reset") setToken(new URLSearchParams(window.location.search).get("token") ?? "");
  }, [mode]);

  const title =
    mode === "login" ? a.loginTitle : mode === "register" ? a.registerTitle : mode === "forgot" ? a.forgotTitle : a.resetTitle;
  const sub = mode === "register" ? a.registerSub : mode === "forgot" ? a.forgotSub : "";
  const cta =
    mode === "login" ? a.login : mode === "register" ? a.register : mode === "forgot" ? a.sendLink : a.save;

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");
    setInfo("");
    try {
      if (mode === "login" || mode === "register") {
        const r = await sendJson(`/api/auth/${mode}`, "POST", { email, password });
        if (!r.ok) return setError(errText(a, r.data.code, r.data.error));
        window.location.href = "/";
      } else if (mode === "forgot") {
        const r = await sendJson("/api/auth/forgot", "POST", { email });
        if (!r.ok) return setError(errText(a, r.data.code, r.data.error));
        setInfo(a.forgotSent);
      } else {
        if (!token) return setError(a.resetNoToken);
        const r = await sendJson("/api/auth/reset", "POST", { token, password });
        if (!r.ok) return setError(errText(a, r.data.code, r.data.error));
        setInfo(a.resetDone);
      }
    } catch {
      setError(a.netErr);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className={`${cardCls} space-y-4`}>
      <div>
        <h1 className="text-xl font-extrabold text-white">{title}</h1>
        {sub && <p className="mt-1 text-xs leading-6 text-slate-400">{sub}</p>}
      </div>

      {mode !== "reset" && (
        <input
          type="email"
          dir="ltr"
          autoComplete="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder={a.email}
          className={inputCls}
        />
      )}
      {mode !== "forgot" && (
        <div>
          <input
            type="password"
            dir="ltr"
            autoComplete={mode === "login" ? "current-password" : "new-password"}
            required
            minLength={mode === "login" ? 1 : 8}
            maxLength={128}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={mode === "reset" ? a.newPassword : a.password}
            className={inputCls}
          />
          {mode !== "login" && <p className="mt-1.5 text-[11px] text-slate-500">{a.passwordHint}</p>}
        </div>
      )}

      {error && <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-xs text-rose-300">{error}</p>}
      {info && <p className="rounded-lg bg-emerald-500/10 px-3 py-2 text-xs text-emerald-300">{info}</p>}

      <button type="submit" disabled={busy} className={`${btnCls} w-full`}>
        {busy ? a.loading : cta}
      </button>

      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
        {mode === "login" && (
          <>
            <Link href="/forgot" className="hover:text-white">{a.forgotLink}</Link>
            <span>
              {a.noAccount}{" "}
              <Link href="/register" className="font-bold text-cyan-300 hover:text-white">{a.register}</Link>
            </span>
          </>
        )}
        {mode === "register" && (
          <span>
            {a.haveAccount}{" "}
            <Link href="/login" className="font-bold text-cyan-300 hover:text-white">{a.login}</Link>
          </span>
        )}
        {(mode === "forgot" || mode === "reset") && (
          <Link href="/login" className="font-bold text-cyan-300 hover:text-white">{a.login}</Link>
        )}
      </div>
    </form>
  );
}

export function AuthForm({ mode }: { mode: Mode }) {
  return (
    <PageShell>
      <Form mode={mode} />
    </PageShell>
  );
}
