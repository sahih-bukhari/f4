"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import { ArrowRight, Languages } from "lucide-react";
import { LangProvider } from "@/lib/i18n";
import { useA } from "./hooks";

function Inner({ children, wide }: { children: ReactNode; wide?: boolean }) {
  const { a, toggle, lang } = useA();
  return (
    <div className="relative z-10 min-h-dvh px-4 py-6 sm:py-10">
      <div className={`mx-auto w-full ${wide ? "max-w-5xl" : "max-w-md"}`}>
        <div className="mb-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-1.5 text-sm text-slate-400 transition hover:text-white">
            <ArrowRight size={15} className={lang === "fa" ? "" : "rotate-180"} />
            {a.back}
          </Link>
          <button
            onClick={toggle}
            className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[11px] font-bold text-slate-300 transition hover:border-violet-400/40 hover:text-white"
          >
            <Languages size={12} className="text-cyan-300" />
            {lang === "fa" ? "English" : "فارسی"}
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function PageShell({ children, wide }: { children: ReactNode; wide?: boolean }) {
  return (
    <LangProvider>
      <Inner wide={wide}>{children}</Inner>
    </LangProvider>
  );
}
