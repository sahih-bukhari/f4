"use client";

import { useCallback, useEffect, useState } from "react";
import { useLang } from "@/lib/i18n";
import { ACCOUNT_TEXT } from "@/lib/account-i18n";

export type Tier = "guest" | "free" | "pro";

export type Me = {
  user: { id: string; email: string; role: string; tier: Tier; planExpiresAt: string | null } | null;
  tier: Tier;
  limits: { chat: number; build: number };
  used: { chat: number; build: number };
  paymentProviders: string[];
  price: { monthlyCents: number; currency: string; months: number[] };
};

export function useA() {
  const { lang, toggle } = useLang();
  return { a: ACCOUNT_TEXT[lang], lang, toggle };
}

export function useMe() {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me", { cache: "no-store" });
      if (res.ok) setMe((await res.json()) as Me);
    } catch {
      /* noop */
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void refresh();
  }, [refresh]);
  return { me, loading, refresh };
}

export async function sendJson<T = Record<string, unknown>>(
  url: string,
  method: "POST" | "PATCH",
  body: unknown
): Promise<{ ok: boolean; status: number; data: T & { error?: string; code?: string } }> {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string; code?: string };
  return { ok: res.ok, status: res.status, data };
}

export const inputCls =
  "w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-violet-400/50";
export const btnCls =
  "rounded-xl bg-gradient-to-l from-violet-500 to-cyan-500 px-4 py-3 text-sm font-bold text-white transition hover:opacity-90 disabled:opacity-50";
export const ghostBtnCls =
  "rounded-lg border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs font-bold text-slate-300 transition hover:border-violet-400/40 hover:text-white disabled:opacity-50";
export const cardCls = "rounded-2xl border border-white/10 bg-white/[0.04] p-5 backdrop-blur";
