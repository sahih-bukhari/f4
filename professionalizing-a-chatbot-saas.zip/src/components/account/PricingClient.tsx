"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Check, Crown } from "lucide-react";
import { DAILY_LIMITS } from "@/lib/limits";
import { errText, shortDate } from "@/lib/account-i18n";
import { PageShell } from "./PageShell";
import { btnCls, cardCls, ghostBtnCls, sendJson, useA, useMe } from "./hooks";

type Row = {
  id: string;
  provider: string;
  status: "pending" | "paid" | "rejected" | "canceled";
  amountCents: number;
  currency: string;
  months: number;
  externalId: string | null;
  createdAt: string;
};

function money(cents: number, currency: string, lang: string) {
  try {
    return new Intl.NumberFormat(lang === "fa" ? "fa-IR" : "en-US", { style: "currency", currency: currency.toUpperCase() }).format(cents / 100);
  } catch {
    return `${(cents / 100).toFixed(2)} ${currency.toUpperCase()}`;
  }
}

function Inner() {
  const { a, lang } = useA();
  const { me, loading, refresh } = useMe();
  const [months, setMonths] = useState(1);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [manual, setManual] = useState<{ instructions: string } | null>(null);
  const [history, setHistory] = useState<Row[]>([]);

  async function loadHistory() {
    try {
      const r = await fetch("/api/billing/payments", { cache: "no-store" });
      if (r.ok) setHistory(((await r.json()) as { payments: Row[] }).payments);
    } catch {
      /* noop */
    }
  }

  useEffect(() => {
    const q = new URLSearchParams(window.location.search);
    if (q.get("paid")) setNotice(a.paidOk);
    else if (q.get("canceled")) setNotice(a.paidCanceled);
  }, [a.paidOk, a.paidCanceled]);

  useEffect(() => {
    if (me?.user) void loadHistory();
  }, [me?.user]);

  async function buy(provider: string) {
    setBusy(provider);
    setError("");
    setManual(null);
    try {
      const r = await sendJson<{ redirectUrl: string | null; instructions: string | null }>(
        "/api/billing/checkout",
        "POST",
        { provider, months }
      );
      if (!r.ok) return setError(errText(a, r.data.code, r.data.error));
      if (r.data.redirectUrl) {
        window.location.href = r.data.redirectUrl;
        return;
      }
      if (r.data.instructions) setManual({ instructions: r.data.instructions });
      await loadHistory();
      await refresh();
    } catch {
      setError(a.netErr);
    } finally {
      setBusy("");
    }
  }

  const tiers = [
    { id: "guest", name: a.guest },
    { id: "free", name: a.free },
    { id: "pro", name: a.pro },
  ] as const;
  const current = me?.tier;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold text-white">{a.pricingTitle}</h1>
        <p className="mt-1 text-sm text-slate-400">{a.pricingSub}</p>
      </div>

      {notice && <p className="rounded-lg bg-emerald-500/10 px-3 py-2 text-xs text-emerald-300">{notice}</p>}

      <div className="grid gap-3 sm:grid-cols-3">
        {tiers.map((tr) => (
          <div
            key={tr.id}
            className={`${cardCls} ${tr.id === "pro" ? "border-violet-400/40" : ""} ${current === tr.id ? "ring-1 ring-cyan-400/50" : ""}`}
          >
            <div className="flex items-center gap-2 text-base font-extrabold text-white">
              {tr.id === "pro" && <Crown size={15} className="text-amber-300" />}
              {tr.name}
            </div>
            {current === tr.id && <div className="mt-1 text-[11px] text-cyan-300">{a.yourPlan}</div>}
            <ul className="mt-3 space-y-2 text-sm text-slate-300">
              <li className="flex items-center gap-2">
                <Check size={14} className="text-emerald-400" />
                {DAILY_LIMITS[tr.id].chat.toLocaleString(lang === "fa" ? "fa-IR" : "en-US")} {a.messages} {a.perDay}
              </li>
              <li className="flex items-center gap-2">
                <Check size={14} className="text-emerald-400" />
                {DAILY_LIMITS[tr.id].build.toLocaleString(lang === "fa" ? "fa-IR" : "en-US")} {a.builds} {a.perDay}
              </li>
            </ul>
          </div>
        ))}
      </div>

      <div className={`${cardCls} space-y-4`}>
        {loading ? (
          <p className="text-sm text-slate-400">{a.loading}</p>
        ) : !me?.user ? (
          <p className="text-sm text-slate-300">
            {a.needLogin}{" "}
            <Link href="/login" className="font-bold text-cyan-300 hover:text-white">{a.login}</Link>
          </p>
        ) : (
          <>
            <div className="flex flex-wrap gap-2">
              {me.price.months.map((m) => (
                <button
                  key={m}
                  onClick={() => setMonths(m)}
                  className={`rounded-xl border px-4 py-2 text-sm font-bold transition ${
                    months === m
                      ? "border-violet-400/60 bg-violet-500/20 text-white"
                      : "border-white/10 bg-white/[0.04] text-slate-300 hover:text-white"
                  }`}
                >
                  {a.months(m)} · {money(me.price.monthlyCents * m, me.price.currency, lang)}
                </button>
              ))}
            </div>
            <div className="flex flex-wrap gap-2">
              {me.paymentProviders.includes("stripe") && (
                <button disabled={!!busy} onClick={() => buy("stripe")} className={btnCls}>
                  {busy === "stripe" ? a.loading : a.payOnline}
                </button>
              )}
              {me.paymentProviders.includes("manual") && (
                <button disabled={!!busy} onClick={() => buy("manual")} className={ghostBtnCls + " !px-4 !py-3 !text-sm"}>
                  {busy === "manual" ? a.loading : a.payManual}
                </button>
              )}
            </div>
            {error && <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-xs text-rose-300">{error}</p>}
            {manual && (
              <div className="rounded-xl border border-amber-400/25 bg-amber-400/[0.06] p-4 text-sm leading-7 text-amber-100/90">
                <div className="mb-1 font-bold">{a.manualTitle}</div>
                <p className="whitespace-pre-wrap">{manual.instructions}</p>
                <p className="mt-2 text-xs text-amber-200/70">{a.manualNote}</p>
              </div>
            )}
          </>
        )}
      </div>

      {me?.user && (
        <div className={cardCls}>
          <div className="mb-3 text-sm font-bold text-white">{a.history}</div>
          {history.length === 0 ? (
            <p className="text-xs text-slate-500">{a.noHistory}</p>
          ) : (
            <ul className="divide-y divide-white/5 text-xs text-slate-300">
              {history.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                  <span dir="ltr" className="font-mono text-slate-400">{p.externalId ?? p.id.slice(0, 8)}</span>
                  <span>{a.months(p.months)} · {money(p.amountCents, p.currency, lang)}</span>
                  <span>{shortDate(p.createdAt, lang)}</span>
                  <span className="rounded-full bg-white/10 px-2 py-0.5">{a[`st_${p.status}` as const]}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

export function PricingClient() {
  return (
    <PageShell wide>
      <Inner />
    </PageShell>
  );
}
