"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { errText, shortDate } from "@/lib/account-i18n";
import { PageShell } from "./PageShell";
import { cardCls, ghostBtnCls, inputCls, sendJson, useA, useMe } from "./hooks";

type Stats = {
  users: number;
  proUsers: number;
  pendingPayments: number;
  revenue: { currency: string; cents: number }[];
  today: { chat: number; build: number };
};
type AUser = {
  id: string;
  email: string;
  role: "user" | "admin";
  plan: "free" | "pro";
  planExpiresAt: string | null;
  blocked: boolean;
  createdAt: string;
  conversations: number;
  builds: number;
};
type APay = {
  id: string;
  email: string;
  provider: string;
  status: "pending" | "paid" | "rejected" | "canceled";
  amountCents: number;
  currency: string;
  months: number;
  externalId: string | null;
  createdAt: string;
};

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className={cardCls}>
      <div className="text-[11px] text-slate-400">{label}</div>
      <div className="mt-1 text-2xl font-extrabold text-white">{value}</div>
    </div>
  );
}

function Inner() {
  const { a, lang } = useA();
  const { me, loading } = useMe();
  const [tab, setTab] = useState<"users" | "payments">("users");
  const [stats, setStats] = useState<Stats | null>(null);
  const [usersList, setUsersList] = useState<AUser[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");
  const [pays, setPays] = useState<APay[]>([]);
  const [error, setError] = useState("");

  const loadStats = useCallback(async () => {
    const r = await fetch("/api/admin/stats", { cache: "no-store" });
    if (r.ok) setStats((await r.json()) as Stats);
  }, []);

  const loadUsers = useCallback(
    async (p: number, query: string, append: boolean) => {
      const r = await fetch(`/api/admin/users?page=${p}&q=${encodeURIComponent(query)}`, { cache: "no-store" });
      if (!r.ok) return;
      const d = (await r.json()) as { users: AUser[]; hasMore: boolean };
      setUsersList((prev) => (append ? [...prev, ...d.users] : d.users));
      setHasMore(d.hasMore);
      setPage(p);
    },
    []
  );

  const loadPays = useCallback(async () => {
    const r = await fetch("/api/admin/payments", { cache: "no-store" });
    if (r.ok) setPays(((await r.json()) as { payments: APay[] }).payments);
  }, []);

  const isAdmin = me?.user?.role === "admin";

  useEffect(() => {
    if (!isAdmin) return;
    void loadStats();
    void loadUsers(1, "", false);
    void loadPays();
  }, [isAdmin, loadStats, loadUsers, loadPays]);

  async function patchUser(id: string, body: Record<string, unknown>) {
    setError("");
    const r = await sendJson(`/api/admin/users/${id}`, "PATCH", body);
    if (!r.ok) return setError(errText(a, r.data.code, r.data.error));
    await Promise.all([loadUsers(1, q, false), loadStats()]);
  }

  async function payAction(id: string, action: "approve" | "reject") {
    setError("");
    const r = await sendJson(`/api/admin/payments/${id}`, "POST", { action });
    if (!r.ok) setError(errText(a, r.data.code, r.data.error));
    await Promise.all([loadPays(), loadStats(), loadUsers(1, q, false)]);
  }

  if (loading) return <p className="text-sm text-slate-400">{a.loading}</p>;
  if (!isAdmin) {
    return (
      <div className={cardCls}>
        <p className="text-sm text-slate-300">{a.forbidden}</p>
        <Link href="/login" className="mt-3 inline-block text-sm font-bold text-cyan-300 hover:text-white">{a.login}</Link>
      </div>
    );
  }

  const num = (n: number) => n.toLocaleString(lang === "fa" ? "fa-IR" : "en-US");

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-extrabold text-white">{a.adminTitle}</h1>

      {stats && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <Stat label={a.usersStat} value={num(stats.users)} />
          <Stat label={a.proStat} value={num(stats.proUsers)} />
          <Stat label={a.pendingStat} value={num(stats.pendingPayments)} />
          <Stat label={a.todayChat} value={num(stats.today.chat)} />
          <Stat label={a.todayBuild} value={num(stats.today.build)} />
          <Stat
            label={a.revenue}
            value={stats.revenue.length ? stats.revenue.map((r) => `${(r.cents / 100).toFixed(0)} ${r.currency.toUpperCase()}`).join(" + ") : "0"}
          />
        </div>
      )}

      {error && <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-xs text-rose-300">{error}</p>}

      <div className="flex gap-2">
        {(["users", "payments"] as const).map((k) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`rounded-xl border px-4 py-2 text-sm font-bold transition ${
              tab === k ? "border-violet-400/60 bg-violet-500/20 text-white" : "border-white/10 bg-white/[0.04] text-slate-300"
            }`}
          >
            {k === "users" ? a.usersTab : `${a.paymentsTab}${stats?.pendingPayments ? ` (${num(stats.pendingPayments)})` : ""}`}
          </button>
        ))}
      </div>

      {tab === "users" && (
        <div className={`${cardCls} space-y-3`}>
          <input
            dir="ltr"
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              void loadUsers(1, e.target.value, false);
            }}
            placeholder={a.search}
            className={inputCls}
          />
          {usersList.length === 0 ? (
            <p className="text-xs text-slate-500">{a.noRows}</p>
          ) : (
            <ul className="divide-y divide-white/5">
              {usersList.map((u) => (
                <li key={u.id} className="space-y-2 py-3">
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    <span dir="ltr" className="font-bold text-white">{u.email}</span>
                    {u.role === "admin" && <span className="rounded-full bg-violet-500/25 px-2 py-0.5 text-[10px] text-violet-200">admin</span>}
                    {u.plan === "pro" && (
                      <span className="rounded-full bg-amber-400/20 px-2 py-0.5 text-[10px] text-amber-200">
                        {a.pro} {a.proUntil(shortDate(u.planExpiresAt, lang))}
                      </span>
                    )}
                    {u.blocked && <span className="rounded-full bg-rose-500/25 px-2 py-0.5 text-[10px] text-rose-200">blocked</span>}
                    <span className="ms-auto text-[11px] text-slate-500">
                      {num(u.conversations)} {a.convs} · {num(u.builds)} {a.builds} · {shortDate(u.createdAt, lang)}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button className={ghostBtnCls} onClick={() => patchUser(u.id, { blocked: !u.blocked })}>
                      {u.blocked ? a.unblock : a.block}
                    </button>
                    <button className={ghostBtnCls} onClick={() => patchUser(u.id, { role: u.role === "admin" ? "user" : "admin" })}>
                      {u.role === "admin" ? a.removeAdmin : a.makeAdmin}
                    </button>
                    <button className={ghostBtnCls} onClick={() => patchUser(u.id, { extendDays: 30 })}>{a.addMonth}</button>
                    {u.plan === "pro" && (
                      <button className={ghostBtnCls} onClick={() => patchUser(u.id, { plan: "free" })}>{a.setFree}</button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
          {hasMore && (
            <button className={ghostBtnCls} onClick={() => loadUsers(page + 1, q, true)}>{a.more}</button>
          )}
        </div>
      )}

      {tab === "payments" && (
        <div className={cardCls}>
          {pays.length === 0 ? (
            <p className="text-xs text-slate-500">{a.noRows}</p>
          ) : (
            <ul className="divide-y divide-white/5 text-xs text-slate-300">
              {pays.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center gap-3 py-3">
                  <span dir="ltr" className="font-bold text-white">{p.email}</span>
                  <span dir="ltr" className="font-mono text-slate-400">{p.externalId ?? p.id.slice(0, 8)}</span>
                  <span>{p.provider} · {a.months(p.months)} · {(p.amountCents / 100).toFixed(2)} {p.currency.toUpperCase()}</span>
                  <span>{shortDate(p.createdAt, lang)}</span>
                  <span className="rounded-full bg-white/10 px-2 py-0.5">{a[`st_${p.status}` as const]}</span>
                  {p.status === "pending" && (
                    <span className="ms-auto flex gap-2">
                      <button className={ghostBtnCls} onClick={() => payAction(p.id, "approve")}>{a.approve}</button>
                      <button className={ghostBtnCls} onClick={() => payAction(p.id, "reject")}>{a.reject}</button>
                    </span>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

export function AdminClient() {
  return (
    <PageShell wide>
      <Inner />
    </PageShell>
  );
}
