"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Crown, LogIn, LogOut, ShieldCheck, User } from "lucide-react";
import { shortDate } from "@/lib/account-i18n";
import { sendJson, useA, useMe } from "./hooks";

/** دکمه‌ی حساب کاربری در هدر چت: ورود برای مهمان، منوی حساب برای کاربر */
export function AccountMenu() {
  const { a, lang } = useA();
  const { me, loading, refresh } = useMe();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  // مصرف امروز بعد از هر پیام تازه می‌شود (فقط وقتی منو باز می‌شود)
  useEffect(() => {
    if (open) void refresh();
  }, [open, refresh]);

  if (loading || !me) return null;

  if (!me.user) {
    return (
      <Link
        href="/login"
        className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[11px] font-bold text-slate-300 transition hover:border-violet-400/40 hover:text-white"
      >
        <LogIn size={12} className="text-cyan-300" />
        {a.login}
      </Link>
    );
  }

  const u = me.user;
  const nf = (n: number) => n.toLocaleString(lang === "fa" ? "fa-IR" : "en-US");

  async function logout() {
    await sendJson("/api/auth/logout", "POST", {}).catch(() => undefined);
    window.location.href = "/";
  }

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label={a.accountMenu}
        className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[11px] font-bold text-slate-300 transition hover:border-violet-400/40 hover:text-white"
      >
        {u.tier === "pro" ? <Crown size={12} className="text-amber-300" /> : <User size={12} className="text-cyan-300" />}
        <span dir="ltr" className="hidden max-w-[110px] truncate sm:inline">{u.email}</span>
      </button>
      {open && (
        <div className="absolute end-0 top-11 z-50 w-64 rounded-2xl border border-white/10 bg-[#0d0d17]/95 p-3 shadow-2xl backdrop-blur-xl">
          <div dir="ltr" className="truncate px-2 text-xs font-bold text-white">{u.email}</div>
          <div className="px-2 pb-2 pt-1 text-[11px] text-slate-400">
            {u.tier === "pro" ? `${a.pro} ${a.proUntil(shortDate(u.planExpiresAt, lang))}` : a.free}
          </div>
          <div className="space-y-1 rounded-xl bg-white/[0.04] p-2 text-[11px] text-slate-300">
            <div className="flex justify-between"><span>{a.chatsToday}</span><span>{nf(me.used.chat)} / {nf(me.limits.chat)}</span></div>
            <div className="flex justify-between"><span>{a.buildsToday}</span><span>{nf(me.used.build)} / {nf(me.limits.build)}</span></div>
          </div>
          <div className="mt-2 flex flex-col text-xs">
            <Link href="/pricing" className="flex items-center gap-2 rounded-lg px-2 py-2 text-slate-300 hover:bg-white/5 hover:text-white">
              <Crown size={13} className="text-amber-300" /> {a.pricing}
            </Link>
            {u.role === "admin" && (
              <Link href="/admin" className="flex items-center gap-2 rounded-lg px-2 py-2 text-slate-300 hover:bg-white/5 hover:text-white">
                <ShieldCheck size={13} className="text-emerald-300" /> {a.adminPanel}
              </Link>
            )}
            <button onClick={logout} className="flex items-center gap-2 rounded-lg px-2 py-2 text-start text-slate-300 hover:bg-white/5 hover:text-white">
              <LogOut size={13} className="text-rose-300" /> {a.logout}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
