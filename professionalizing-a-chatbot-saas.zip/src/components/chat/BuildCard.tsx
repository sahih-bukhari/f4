"use client";

import { useEffect, useState } from "react";
import { ArrowUpLeft, LayoutTemplate } from "lucide-react";
import { useLang } from "@/lib/i18n";

export const OPEN_BUILD_EVENT = "nova:open-build";

type Meta = { id: string; title: string; createdAt: string };

/** کارت ساخت داخل پیام — کلیک آن پنل پیش‌نمایش را باز می‌کند */
export function BuildCard({ id }: { id: string }) {
  const { t, lang } = useLang();
  const [meta, setMeta] = useState<Meta | null>(null);

  useEffect(() => {
    let alive = true;
    fetch(`/api/builds/${id}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (alive && d?.build) setMeta(d.build);
      })
      .catch(() => null);
    return () => {
      alive = false;
    };
  }, [id]);

  function open() {
    window.dispatchEvent(new CustomEvent(OPEN_BUILD_EVENT, { detail: { id } }));
  }

  return (
    <button
      onClick={open}
      className="group/card mt-1 flex w-full items-center gap-3 rounded-xl border border-violet-400/25 bg-gradient-to-l from-violet-500/[0.14] to-cyan-500/[0.07] p-3 text-start transition hover:border-violet-300/50 hover:from-violet-500/20 hover:to-cyan-500/10"
      dir={lang === "fa" ? "rtl" : "ltr"}
    >
      <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-violet-300/25 bg-[#131322] text-violet-300 shadow-[inset_0_0_18px_rgba(139,92,246,0.25)]">
        <LayoutTemplate size={18} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-[13.5px] font-bold text-white">
          {meta?.title ?? t.previewTitle}
        </div>
        <div className="mt-0.5 text-[11.5px] text-slate-400">{t.buildCardSub}</div>
      </div>
      <span className="flex shrink-0 items-center gap-1.5 rounded-lg bg-white/[0.07] px-2.5 py-1.5 text-[11px] font-bold text-slate-200 transition group-hover/card:bg-violet-500/25">
        {t.openPreview}
        <ArrowUpLeft size={12} />
      </span>
    </button>
  );
}
