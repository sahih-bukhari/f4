"use client";

import { memo, useState } from "react";
import { motion } from "framer-motion";
import { Check, Copy } from "lucide-react";
import { Markdown } from "./Markdown";
import { AttachmentChips } from "./AttachmentChips";
import { formatTime } from "@/lib/format";
import { useLang } from "@/lib/i18n";
import type { ChatMessage } from "@/lib/types";

/** جداسازی نشانگر پیوست‌ها از متن پیام کاربر */
function splitAttachments(content: string): { text: string; attachJson: string | null } {
  const m = content.match(/([\s\S]*?)\n\n```attachments\n([\s\S]*?)```\s*$/);
  if (!m) return { text: content, attachJson: null };
  return { text: m[1], attachJson: m[2] };
}

export function TypingDots() {
  return (
    <div className="flex items-center gap-1.5 px-1 py-1" aria-hidden>
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="h-2 w-2 rounded-full bg-violet-300"
          animate={{ y: [0, -5, 0], opacity: [0.35, 1, 0.35] }}
          transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.16, ease: "easeInOut" }}
        />
      ))}
    </div>
  );
}

function BotAvatar({ size = 34 }: { size?: number }) {
  return (
    <div
      className="relative shrink-0 select-none"
      style={{ width: size, height: size }}
      aria-hidden
    >
      <div className="absolute inset-0 rounded-full bg-violet-500/40 blur-md" />
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/images/nova-avatar.png"
        alt=""
        width={size}
        height={size}
        className="relative h-full w-full rounded-full border border-white/15 object-cover shadow-[0_0_18px_rgba(139,92,246,0.45)]"
      />
      <span className="absolute end-0 bottom-0 h-2.5 w-2.5 rounded-full border-2 border-[#0a0a12] bg-emerald-400" />
    </div>
  );
}

export const MessageBubble = memo(function MessageBubble({
  message,
  streaming = false,
}: {
  message: ChatMessage;
  streaming?: boolean;
}) {
  const isUser = message.role === "user";
  const [copied, setCopied] = useState(false);
  const { lang, t } = useLang();
  const time = formatTime(message.createdAt, lang);

  async function copy() {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* noop */
    }
  }

  if (isUser) {
    const { text, attachJson } = splitAttachments(message.content);
    return (
      <motion.div
        initial={{ opacity: 0, y: 14, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        className="flex justify-end"
      >
        <div className="max-w-[82%] sm:max-w-[70%]">
          <div
            dir="auto"
            className="relative rounded-2xl rounded-ee-sm bg-gradient-to-br from-violet-500 via-fuchsia-600 to-indigo-600 px-4 py-3 text-[15px] leading-7 whitespace-pre-wrap text-white shadow-[0_10px_30px_-8px_rgba(139,92,246,0.55)]"
          >
            {text}
            {attachJson && <AttachmentChips json={attachJson} />}
          </div>
          <div className="mt-1.5 pe-1 text-end text-[11px] text-slate-500">{time}</div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className="flex items-start gap-3"
    >
      <BotAvatar />
      <div className="group min-w-0 max-w-[86%] sm:max-w-[76%]">
        <div className="flex items-center gap-2 pb-1.5">
          <span className="text-[12px] font-bold tracking-wide text-violet-200">
            {lang === "fa" ? "نُوا" : "Nova"}
          </span>
          <span className="rounded-full border border-violet-400/20 bg-violet-400/10 px-2 py-px text-[10px] text-violet-300/80">
            {t.aiBadge}
          </span>
          <span className="text-[11px] text-slate-500">{time}</span>
        </div>
        <div
          dir="auto"
          className="relative rounded-2xl rounded-ss-sm border border-white/[0.07] bg-white/[0.045] px-4 py-3 text-[15px] text-slate-200 shadow-[0_10px_30px_-12px_rgba(0,0,0,0.5)] backdrop-blur-sm"
        >
          {message.content ? (
            <>
              <Markdown content={message.content} />
              {streaming && (
                <span className="mb-0.5 inline-block h-4 w-[7px] animate-pulse rounded-[2px] bg-cyan-300 align-middle shadow-[0_0_10px_rgba(103,232,249,0.9)]" />
              )}
            </>
          ) : (
            <TypingDots />
          )}
        </div>
        {message.content && !streaming && (
          <div className="mt-1.5 flex items-center gap-1 opacity-0 transition-opacity duration-200 group-hover:opacity-100">
            <button
              onClick={copy}
              className="flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11px] text-slate-500 transition hover:bg-white/5 hover:text-slate-200"
            >
              {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
              {copied ? t.copied : t.copy}
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
});
