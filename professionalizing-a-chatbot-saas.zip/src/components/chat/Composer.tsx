"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { FileText, Hammer, Loader2, MessageCircle, Mic, Paperclip, SendHorizonal, Square, X } from "lucide-react";
import { num } from "@/lib/format";
import { useLang } from "@/lib/i18n";

const MAX_LEN = 2000;
const MAX_ATTACH = 3;
const MAX_FILE_BYTES = 5 * 1024 * 1024;
const ACCEPT = ".txt,.md,.markdown,.csv,.tsv,.json,.log,.js,.mjs,.ts,.tsx,.jsx,.py,.rb,.go,.rs,.html,.htm,.css,.scss,.sql,.yml,.yaml,.xml,.env,.toml,.ini,.sh,.java,.c,.cpp,.h,.zip";

export type ComposerMode = "chat" | "build";

type Props = {
  disabled?: boolean;
  mode: ComposerMode;
  onModeChange: (m: ComposerMode) => void;
  onSend: (text: string, uploadIds?: string[]) => void;
};

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
};

export function Composer({ disabled, mode, onModeChange, onSend }: Props) {
  const { lang, t } = useLang();
  const [value, setValue] = useState("");
  const [listening, setListening] = useState(false);
  const [voiceSupported, setVoiceSupported] = useState(false);
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [attachError, setAttachError] = useState<string | null>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<SpeechRecognitionLike | null>(null);

  useEffect(() => {
    const w = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition;
    setVoiceSupported(Boolean(Ctor));
    if (Ctor) {
      const rec = new Ctor();
      rec.lang = lang === "fa" ? "fa-IR" : "en-US";
      rec.interimResults = true;
      rec.continuous = false;
      rec.onresult = (e) => {
        const last = e.results[e.results.length - 1];
        const text = last?.[0]?.transcript ?? "";
        if (text) setValue((v) => (v.replace(/\s*$/, "") + " " + text).trim());
      };
      rec.onend = () => setListening(false);
      rec.onerror = () => setListening(false);
      recRef.current = rec;
    }
    return () => {
      try {
        recRef.current?.stop();
      } catch {
        /* noop */
      }
    };
  }, [lang]);

  const autosize = useCallback(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "0px";
    ta.style.height = Math.min(ta.scrollHeight, 168) + "px";
  }, []);

  useEffect(autosize, [value, autosize]);

  function addFiles(list: FileList | null) {
    if (!list) return;
    setAttachError(null);
    const incoming = Array.from(list);
    for (const f of incoming) {
      if (pendingFiles.length >= MAX_ATTACH) break;
      const extOk = ACCEPT.split(",").some((e) => f.name.toLowerCase().endsWith(e));
      if (!extOk) {
        setAttachError(t.attachErrType);
        continue;
      }
      if (f.size > MAX_FILE_BYTES) {
        setAttachError(t.attachErrSize);
        continue;
      }
      setPendingFiles((prev) => (prev.length >= MAX_ATTACH ? prev : [...prev, f]));
    }
    if (incoming.length && pendingFiles.length + incoming.length > MAX_ATTACH) {
      setAttachError(t.attachErrMax);
    }
    if (fileRef.current) fileRef.current.value = "";
  }

  async function uploadPending(): Promise<string[] | null> {
    if (!pendingFiles.length) return [];
    setUploading(true);
    try {
      const fd = new FormData();
      for (const f of pendingFiles) fd.append("files", f, f.name);
      const res = await fetch("/api/files", { method: "POST", body: fd });
      const data = (await res.json().catch(() => null)) as {
        uploads?: { id: string }[];
        error?: string;
      } | null;
      if (!res.ok || !data?.uploads?.length) {
        setAttachError(data?.error ?? t.attachErr);
        return null;
      }
      setPendingFiles([]);
      return data.uploads.map((u) => u.id);
    } catch {
      setAttachError(t.attachErr);
      return null;
    } finally {
      setUploading(false);
    }
  }

  async function submit() {
    const text = value.trim();
    if ((!text && !pendingFiles.length) || disabled || uploading) return;
    if (listening) toggleVoice();
    const ids = await uploadPending();
    if (ids === null) return; // آپلود ناموفق — ارسال نشود
    const fallback = lang === "fa" ? "این فایل‌ها را بررسی کن" : "Analyze these attached files";
    onSend(text || fallback, ids.length ? ids : undefined);
    setValue("");
    requestAnimationFrame(() => {
      autosize();
      taRef.current?.focus();
    });
  }

  function toggleVoice() {
    const rec = recRef.current;
    if (!rec) return;
    if (listening) {
      setListening(false);
      try {
        rec.stop();
      } catch {
        /* noop */
      }
    } else {
      try {
        rec.start();
        setListening(true);
      } catch {
        setListening(false);
      }
    }
  }

  const remaining = MAX_LEN - value.length;
  const busyUI = disabled || uploading;

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 px-3 pb-4 sm:px-6 sm:pb-6">
      <div className="pointer-events-auto mx-auto w-full max-w-3xl">
        {/* تاگل حالت گفت‌وگو / سازنده */}
        <div className="mx-auto mb-2.5 flex w-fit items-center gap-1 rounded-full border border-white/10 bg-[#101018]/85 p-1 backdrop-blur-xl">
          <button
            type="button"
            onClick={() => onModeChange("chat")}
            className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[12px] font-bold transition ${
              mode === "chat"
                ? "bg-white/10 text-white shadow-sm"
                : "text-slate-500 hover:text-slate-300"
            }`}
          >
            <MessageCircle size={13} />
            {t.modeChat}
          </button>
          <button
            type="button"
            onClick={() => onModeChange("build")}
            className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[12px] font-bold transition ${
              mode === "build"
                ? "bg-gradient-to-l from-violet-500 to-fuchsia-600 text-white shadow-[0_6px_18px_-6px_rgba(217,70,239,0.7)]"
                : "text-slate-500 hover:text-slate-300"
            }`}
          >
            <Hammer size={13} />
            {t.modeBuild}
          </button>
        </div>

        <div
          className={`group/composer relative rounded-[26px] border bg-[#101018]/85 shadow-[0_18px_50px_-12px_rgba(0,0,0,0.7)] backdrop-blur-xl transition-colors duration-300 ${
            listening
              ? "border-rose-400/50"
              : "border-white/10 focus-within:border-violet-400/50"
          }`}
        >
          {/* خط گرادیانی بالای باکس هنگام فوکوس */}
          <div className="pointer-events-none absolute inset-x-8 -top-px h-px bg-gradient-to-l from-transparent via-violet-400/60 to-transparent opacity-0 transition-opacity duration-300 group-focus-within/composer:opacity-100" />

          {/* چیپ‌های فایل پیوست‌شده */}
          {pendingFiles.length > 0 && (
            <div className="flex flex-wrap gap-1.5 px-4 pt-3">
              {pendingFiles.map((f, i) => (
                <span
                  key={`${f.name}-${i}`}
                  className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.05] px-2.5 py-1 text-[11px] text-slate-300"
                >
                  <FileText size={12} className="text-cyan-300" />
                  <span className="max-w-[160px] truncate" dir="ltr">{f.name}</span>
                  <span className="text-slate-500">{num(Math.max(1, Math.round(f.size / 1024)), lang)}{lang === "fa" ? " کیلوبایت" : " KB"}</span>
                  <button
                    onClick={() => setPendingFiles((p) => p.filter((_, j) => j !== i))}
                    className="text-slate-500 transition hover:text-rose-300"
                    aria-label={t.del}
                  >
                    <X size={11} />
                  </button>
                </span>
              ))}
            </div>
          )}
          {attachError && (
            <p className="px-5 pt-2 text-[11px] font-medium text-rose-300">{attachError}</p>
          )}

          <textarea
            id="nova-composer"
            ref={taRef}
            rows={1}
            dir="auto"
            value={value}
            disabled={disabled}
            placeholder={
              busyUI
                ? uploading
                  ? t.attachUploading
                  : t.composerBusy
                : mode === "build"
                  ? t.composerBuildPh
                  : t.composerPh
            }
            onChange={(e) => setValue(e.target.value.slice(0, MAX_LEN))}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void submit();
              }
            }}
            className="block w-full resize-none bg-transparent px-5 pt-4 pb-2 text-[15px] leading-7 text-slate-100 placeholder:text-slate-500 focus:outline-none disabled:opacity-60"
          />

          <div className="flex items-center justify-between gap-2 px-3 pb-2.5">
            <div className="flex items-center gap-1.5">
              {/* پیوست فایل */}
              <input
                ref={fileRef}
                type="file"
                multiple
                accept={ACCEPT}
                className="hidden"
                onChange={(e) => addFiles(e.target.files)}
              />
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                title={`${t.attach} — ${t.attachHint}`}
                disabled={busyUI}
                className="grid h-10 w-10 place-items-center rounded-xl text-slate-400 transition hover:bg-white/5 hover:text-white disabled:opacity-40"
              >
                <Paperclip size={18} />
              </button>
              {voiceSupported && (
                <button
                  type="button"
                  onClick={toggleVoice}
                  title={listening ? t.voiceStop : t.voice}
                  className={`relative grid h-10 w-10 place-items-center rounded-xl transition ${
                    listening
                      ? "bg-rose-500/20 text-rose-300"
                      : "text-slate-400 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  {listening && (
                    <span className="absolute inset-0 animate-ping rounded-xl bg-rose-500/20" />
                  )}
                  {listening ? <Square size={17} /> : <Mic size={18} />}
                </button>
              )}
              <span
                className={`hidden text-[11px] select-none sm:block ${
                  remaining < 200
                    ? remaining < 50
                      ? "text-rose-400"
                      : "text-amber-400"
                    : "text-slate-600"
                }`}
              >
                {value.length > 0 && t.charsLeft(num(remaining, lang))}
              </span>
            </div>

            <button
              type="button"
              onClick={() => void submit()}
              disabled={busyUI || (!value.trim() && !pendingFiles.length)}
              className="group relative inline-flex h-10 items-center gap-2 overflow-hidden rounded-xl bg-gradient-to-l from-violet-500 to-fuchsia-600 px-4 text-sm font-bold text-white shadow-[0_8px_24px_-6px_rgba(217,70,239,0.6)] transition enabled:hover:brightness-110 enabled:active:scale-95 disabled:cursor-not-allowed disabled:opacity-35"
            >
              {uploading ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <>
                  <span>{t.send}</span>
                  <SendHorizonal
                    size={16}
                    className={`transition-transform group-enabled:group-hover:-translate-x-0.5 ${
                      t.dir === "rtl" ? "-scale-x-100" : ""
                    }`}
                  />
                </>
              )}
            </button>
          </div>
        </div>

        <p className="mt-2.5 text-center text-[11px] text-slate-600">
          {t.disclaimer}
          <span className="mx-1.5 text-slate-700">•</span>
          {t.newlineTip}
          <span className="mx-1.5 text-slate-700">•</span>
          <kbd className="rounded border border-white/10 bg-white/5 px-1 py-px font-sans text-[10px]">
            Ctrl K
          </kbd>{" "}
          {t.newChatTip}
        </p>
      </div>
    </div>
  );
}
