"use client";

import { motion } from "framer-motion";
import { BrainCircuit, Code2, Lightbulb, PenLine } from "lucide-react";
import { useLang } from "@/lib/i18n";

function greetingKey(hour: number): "morning" | "noon" | "afternoon" | "night" {
  if (hour >= 5 && hour < 12) return "morning";
  if (hour >= 12 && hour < 17) return "noon";
  if (hour >= 17 && hour < 20) return "afternoon";
  return "night";
}

export function EmptyState({ onPick }: { onPick: (prompt: string) => void }) {
  const { t } = useLang();

  const suggestions = [
    { icon: PenLine, title: t.sug1t, prompt: t.sug1p, hue: "from-violet-500/20 to-fuchsia-500/10 text-violet-300" },
    { icon: Code2, title: t.sug2t, prompt: t.sug2p, hue: "from-cyan-500/20 to-sky-500/10 text-cyan-300" },
    { icon: BrainCircuit, title: t.sug3t, prompt: t.sug3p, hue: "from-emerald-500/20 to-teal-500/10 text-emerald-300" },
    { icon: Lightbulb, title: t.sug4t, prompt: t.sug4p, hue: "from-amber-500/20 to-orange-500/10 text-amber-300" },
  ];

  const h = parseInt(
    new Date().toLocaleTimeString("en-US", {
      hour: "numeric",
      hour12: false,
      timeZone: "Asia/Tehran",
    }),
    10
  );

  return (
    <div className="flex min-h-full flex-col items-center justify-center px-4 pt-10 pb-44 sm:pb-48">
      {/* آواتار با هاله‌های نورانی */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative mb-7"
      >
        <div className="absolute -inset-8 rounded-full bg-[conic-gradient(from_0deg,transparent,rgba(139,92,246,0.35),transparent,rgba(34,211,238,0.3),transparent)] blur-xl animate-[spin_9s_linear_infinite]" />
        <div className="absolute -inset-3 animate-pulse rounded-full bg-violet-500/25 blur-lg" />
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/nova-avatar.png"
          alt="Nova"
          className="relative h-24 w-24 rounded-full border border-white/15 object-cover shadow-[0_0_50px_rgba(139,92,246,0.55)]"
        />
        <span className="absolute end-1 bottom-1 h-4 w-4 rounded-full border-[3px] border-[#07070d] bg-emerald-400">
          <span className="absolute inset-0 animate-ping rounded-full bg-emerald-400/60" />
        </span>
      </motion.div>

      <motion.p
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.5 }}
        className="text-sm font-medium text-violet-300/80"
      >
        {t[greetingKey(h)]}، {t.welcome}
      </motion.p>

      <motion.h1
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25, duration: 0.5 }}
        className="mt-2 bg-gradient-to-l from-white via-violet-200 to-cyan-200 bg-clip-text text-center text-4xl leading-tight font-black text-transparent sm:text-5xl"
      >
        {t.heroTitle}
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35, duration: 0.5 }}
        className="mt-3 max-w-md text-center text-[15px] leading-7 text-slate-400"
      >
        {t.heroSub}
      </motion.p>

      <div className="mt-9 grid w-full max-w-2xl grid-cols-1 gap-3 sm:grid-cols-2">
        {suggestions.map((s, i) => (
          <motion.button
            key={s.title}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 + i * 0.08, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            whileHover={{ y: -4, scale: 1.015 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onPick(s.prompt)}
            className="group relative overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.03] p-4 text-start backdrop-blur-sm transition-colors hover:border-white/15 hover:bg-white/[0.06]"
          >
            <div
              className={`absolute -top-10 -end-10 h-28 w-28 rounded-full bg-gradient-to-br opacity-60 blur-2xl transition-opacity duration-300 group-hover:opacity-100 ${s.hue.split(" ").slice(0, 2).join(" ")}`}
            />
            <div className="relative flex items-start gap-3.5">
              <div
                className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-white/10 bg-gradient-to-br backdrop-blur ${s.hue}`}
              >
                <s.icon size={18} />
              </div>
              <div className="min-w-0">
                <div className="text-[13px] font-bold text-white">{s.title}</div>
                <div className="mt-1 truncate text-[13px] leading-6 text-slate-400">
                  {s.prompt}
                </div>
              </div>
            </div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
