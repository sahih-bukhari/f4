"use client";

import { FileText } from "lucide-react";
import { num } from "@/lib/format";
import { useLang } from "@/lib/i18n";

type Meta = { name: string; sizeBytes: number };

/** نمایش چیپ‌های فایل پیوست‌شده در پیام کاربر */
export function AttachmentChips({ json }: { json: string }) {
  const { lang } = useLang();
  let items: Meta[] = [];
  try {
    const parsed = JSON.parse(json) as unknown;
    if (Array.isArray(parsed)) {
      items = parsed
        .filter(
          (x): x is Meta =>
            typeof x === "object" && x !== null &&
            typeof (x as Meta).name === "string" &&
            typeof (x as Meta).sizeBytes === "number"
        )
        .slice(0, 5);
    }
  } catch {
    return null;
  }
  if (!items.length) return null;

  return (
    <div className="mt-2 flex flex-wrap gap-1.5">
      {items.map((f, i) => (
        <span
          key={`${f.name}-${i}`}
          className="flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/10 px-2.5 py-1 text-[11px] text-white"
        >
          <FileText size={11} className="shrink-0 text-cyan-200" />
          <span className="max-w-[150px] truncate" dir="ltr">{f.name}</span>
          <span className="opacity-70">
            {num(Math.max(1, Math.round(f.sizeBytes / 1024)), lang)}
            {lang === "fa" ? " کیلوبایت" : " KB"}
          </span>
        </span>
      ))}
    </div>
  );
}
