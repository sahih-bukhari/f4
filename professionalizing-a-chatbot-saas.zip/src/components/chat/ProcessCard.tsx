"use client";

import { motion } from "framer-motion";
import { Check, Code2, Eye, Flag, LayoutTemplate, Loader2, Search, X } from "lucide-react";
import { useLang } from "@/lib/i18n";
import { num } from "@/lib/format";

export type StepState = "pending" | "run" | "done";
export type ProcessStep = { id: string; state: StepState };

const STEP_ICONS: Record<string, typeof Search> = {
  analyze: Search,
  design: LayoutTemplate,
  code: Code2,
  preview: Eye,
  finish: Flag,
};

export const STEP_IDS = ["analyze", "design", "code", "preview", "finish"] as const;

export function ProcessCard({
  steps,
  chars,
  onCancel,
}: {
  steps: ProcessStep[];
  chars: number;
  onCancel: () => void;
}) {
  const { t, lang } = useLang();

  const labels: Record<string, string> = {
    analyze: t.stAnalyze,
    design: t.stDesign,
    code: t.stCode,
    preview: t.stPreview,
    finish: t.stFinish,
  };

  const doneCount = steps.filter((s) => s.state === "done").length;
  const pct = (doneCount / STEP_IDS.length) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className="flex items-start gap-3"
    >
      {/* آواتار مثل پیام‌های نُوا */}
      <div className="relative h-[34px] w-[34px] shrink-0">
        <div className="absolute inset-0 animate-pulse rounded-full bg-violet-500/40 blur-md" />
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/nova-avatar.png"
          alt=""
          className="relative h-full w-full rounded-full border border-white/15 object-cover"
        />
      </div>

      <div className="w-full max-w-[86%] sm:max-w-[76%]">
        <div className="flex items-center gap-2 pb-1.5">
          <span className="text-[12px] font-bold text-violet-200">
            {lang === "fa" ? "نُوا" : "Nova"}
          </span>
          <span className="rounded-full border border-cyan-400/25 bg-cyan-400/10 px-2 py-px text-[10px] text-cyan-300/90">
            {lang === "fa" ? "حالت سازنده" : "Builder mode"}
          </span>
        </div>

        <div className="relative overflow-hidden rounded-2xl rounded-ss-sm border border-white/[0.08] bg-white/[0.045] px-4 py-3.5 backdrop-blur-sm">
          {/* خط پیشرفت بالای کارت */}
          <div className="absolute inset-x-0 top-0 h-[2px] bg-white/[0.06]">
            <motion.div
              className="h-full bg-gradient-to-l from-violet-400 via-fuchsia-400 to-cyan-400"
              initial={{ width: 0 }}
              animate={{ width: `${pct}%` }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            />
          </div>

          <div className="flex items-center justify-between pb-2.5">
            <span className="bg-gradient-to-l from-violet-300 via-slate-100 to-cyan-300 bg-clip-text text-[12px] font-bold text-transparent animate-[shimmer_2s_linear_infinite] bg-[length:200%_100%]">
              {t.building}
            </span>
            <button
              onClick={onCancel}
              className="flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] text-slate-500 transition hover:bg-rose-500/15 hover:text-rose-300"
            >
              <X size={12} />
              {t.cancel}
            </button>
          </div>

          <div className="space-y-2.5">
            {steps.map((s) => {
              const Icon = STEP_ICONS[s.id] ?? Search;
              return (
                <div key={s.id} className="flex items-center gap-2.5">
                  <div
                    className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg border transition-colors ${
                      s.state === "done"
                        ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
                        : s.state === "run"
                          ? "border-violet-400/40 bg-violet-400/10 text-violet-300"
                          : "border-white/[0.07] bg-white/[0.03] text-slate-600"
                    }`}
                  >
                    {s.state === "run" ? (
                      <Loader2 size={13} className="animate-spin" />
                    ) : s.state === "done" ? (
                      <Check size={13} />
                    ) : (
                      <Icon size={13} />
                    )}
                  </div>
                  <span
                    className={`text-[13px] transition-colors ${
                      s.state === "run"
                        ? "font-bold text-white"
                        : s.state === "done"
                          ? "text-slate-400 line-through decoration-slate-600"
                          : "text-slate-600"
                    }`}
                  >
                    {labels[s.id]}
                    {s.id === "code" && chars > 0 && s.state === "run" && (
                      <span className="ms-2 font-mono text-[11px] font-normal text-cyan-300/80">
                        {t.codeChars(num(chars, lang))}
                      </span>
                    )}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
