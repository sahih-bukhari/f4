"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, MessageSquare, Pencil, Plus, Search, ShieldCheck, Trash2, X } from "lucide-react";
import { relativeTime } from "@/lib/format";
import { useLang, type Dict } from "@/lib/i18n";
import type { ChatConversation } from "@/lib/types";

type Props = {
  conversations: ChatConversation[];
  activeId: string | null;
  open: boolean;
  loading: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onNew: () => void;
  onRename: (id: string, title: string) => void;
  onDelete: (id: string) => void;
};

type Group = { label: string; items: ChatConversation[] };

function groupByDay(items: ChatConversation[], t: Dict): Group[] {
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const startOfYesterday = new Date(startOfToday.getTime() - 86400000);

  const today: ChatConversation[] = [];
  const yesterday: ChatConversation[] = [];
  const older: ChatConversation[] = [];

  for (const c of items) {
    const d = new Date(c.updatedAt);
    if (d >= startOfToday) today.push(c);
    else if (d >= startOfYesterday) yesterday.push(c);
    else older.push(c);
  }
  const groups: Group[] = [];
  if (today.length) groups.push({ label: t.groupToday, items: today });
  if (yesterday.length) groups.push({ label: t.groupYesterday, items: yesterday });
  if (older.length) groups.push({ label: t.groupOlder, items: older });
  return groups;
}

export function Sidebar({
  conversations,
  activeId,
  open,
  loading,
  onClose,
  onSelect,
  onNew,
  onRename,
  onDelete,
}: Props) {
  const { t, lang } = useLang();
  const [query, setQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState("");
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingId) inputRef.current?.focus();
  }, [editingId]);

  const filtered = useMemo(() => {
    if (!query.trim()) return conversations;
    return conversations.filter((c) =>
      c.title.toLowerCase().includes(query.trim().toLowerCase())
    );
  }, [conversations, query]);

  const groups = useMemo(() => groupByDay(filtered, t), [filtered, t]);

  function commitRename() {
    if (editingId && editingValue.trim()) onRename(editingId, editingValue.trim());
    setEditingId(null);
  }

  const content = (
    <div className="flex h-full w-full flex-col">
      {/* لوگو */}
      <div className="flex items-center gap-3 px-5 pt-5 pb-4">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-violet-500/50 blur-md" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images/nova-avatar.png"
            alt=""
            className="relative h-10 w-10 rounded-full border border-white/15 object-cover"
          />
        </div>
        <div>
          <div className="text-lg font-black tracking-tight text-white">
            {lang === "fa" ? "نُوا" : "Nova"}
          </div>
          <div className="text-[11px] text-slate-500">
            {lang === "fa" ? "دستیار هوش مصنوعی" : "AI assistant"}
          </div>
        </div>
        <button
          onClick={onClose}
          className="ms-auto grid h-8 w-8 place-items-center rounded-lg text-slate-500 transition hover:bg-white/5 hover:text-white lg:hidden"
          aria-label={t.close}
        >
          <X size={16} />
        </button>
      </div>

      {/* گفت‌وگوی جدید */}
      <div className="px-4">
        <button
          onClick={onNew}
          className="group flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-violet-500 to-fuchsia-600 px-4 py-2.5 text-sm font-bold text-white shadow-[0_10px_30px_-10px_rgba(217,70,239,0.7)] transition hover:brightness-110 active:scale-[0.98]"
        >
          <Plus size={17} className="transition-transform group-hover:rotate-90" />
          {t.newChat}
          <kbd className="rounded-md border border-white/20 bg-white/10 px-1.5 py-px font-sans text-[10px] font-medium opacity-80">
            Ctrl K
          </kbd>
        </button>
      </div>

      {/* جست‌وجو */}
      <div className="px-4 pt-4">
        <div className="flex items-center gap-2 rounded-xl border border-white/[0.07] bg-white/[0.03] px-3 py-2 transition focus-within:border-violet-400/40">
          <Search size={15} className="shrink-0 text-slate-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.searchPh}
            className="w-full bg-transparent text-[13px] text-slate-200 placeholder:text-slate-600 focus:outline-none"
          />
          {query && (
            <button onClick={() => setQuery("")} className="text-slate-500 hover:text-white">
              <X size={13} />
            </button>
          )}
        </div>
      </div>

      {/* لیست مکالمات گروه‌بندی‌شده */}
      <div className="mt-3 flex-1 overflow-y-auto px-3 pb-3">
        {loading ? (
          <div className="space-y-2 pt-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <div
                key={i}
                className="h-12 animate-pulse rounded-xl bg-white/[0.04]"
                style={{ animationDelay: `${i * 120}ms` }}
              />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-2 pt-14 text-center">
            <MessageSquare size={26} className="text-slate-700" />
            <p className="text-[13px] text-slate-600">
              {query ? t.noResults : t.emptyChats}
            </p>
          </div>
        ) : (
          groups.map((g) => (
            <div key={g.label} className="mb-3 last:mb-0">
              <div className="px-2 pt-2 pb-1.5 text-[10px] font-bold tracking-wider text-slate-600 uppercase">
                {g.label}
              </div>
              <div className="space-y-1">
                <AnimatePresence initial={false}>
                  {g.items.map((c) => {
                    const isActive = c.id === activeId;
                    const isEditing = editingId === c.id;
                    const isConfirming = confirmDeleteId === c.id;
                    return (
                      <motion.div
                        key={c.id}
                        layout
                        initial={{ opacity: 0, x: 12 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -12, height: 0, marginBottom: 0 }}
                        transition={{ duration: 0.25 }}
                        className={`group relative overflow-hidden rounded-xl border transition-colors ${
                          isActive
                            ? "border-violet-400/30 bg-violet-500/[0.12]"
                            : "border-transparent hover:bg-white/[0.045]"
                        }`}
                      >
                        {isEditing ? (
                          <div className="flex items-center gap-1.5 px-3 py-2.5">
                            <input
                              ref={inputRef}
                              value={editingValue}
                              onChange={(e) => setEditingValue(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") commitRename();
                                if (e.key === "Escape") setEditingId(null);
                              }}
                              className="w-full rounded-lg border border-violet-400/40 bg-[#0d0d16] px-2.5 py-1.5 text-[13px] text-white focus:outline-none"
                            />
                            <button
                              onClick={commitRename}
                              className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30"
                              aria-label={t.yes}
                            >
                              <Check size={14} />
                            </button>
                          </div>
                        ) : isConfirming ? (
                          <div className="flex items-center gap-2 px-3 py-3">
                            <span className="text-[12px] text-rose-300">{t.delQ}</span>
                            <div className="ms-auto flex gap-1">
                              <button
                                onClick={() => {
                                  onDelete(c.id);
                                  setConfirmDeleteId(null);
                                }}
                                className="rounded-lg bg-rose-500/20 px-2.5 py-1 text-[11px] font-bold text-rose-300 transition hover:bg-rose-500/30"
                              >
                                {t.yes}
                              </button>
                              <button
                                onClick={() => setConfirmDeleteId(null)}
                                className="rounded-lg bg-white/5 px-2.5 py-1 text-[11px] text-slate-300 transition hover:bg-white/10"
                              >
                                {t.no}
                              </button>
                            </div>
                          </div>
                        ) : (
                          <>
                            <button
                              onClick={() => {
                                onSelect(c.id);
                                onClose();
                              }}
                              className="flex w-full flex-col gap-1 px-3 py-2.5 text-start"
                            >
                              <span
                                className={`truncate text-[13.5px] leading-6 ${
                                  isActive ? "font-bold text-white" : "text-slate-300"
                                }`}
                              >
                                {c.title}
                              </span>
                              <span className="text-[11px] text-slate-600">
                                {relativeTime(c.updatedAt, lang)}
                              </span>
                            </button>
                            <div
                              className={`absolute end-1.5 top-1/2 flex -translate-y-1/2 gap-0.5 transition-opacity ${
                                isActive ? "opacity-100" : "opacity-0 group-hover:opacity-100"
                              }`}
                            >
                              <button
                                onClick={() => {
                                  setEditingId(c.id);
                                  setEditingValue(c.title);
                                }}
                                className="grid h-7 w-7 place-items-center rounded-lg text-slate-500 transition hover:bg-white/10 hover:text-white"
                                aria-label={t.rename}
                              >
                                <Pencil size={13} />
                              </button>
                              <button
                                onClick={() => setConfirmDeleteId(c.id)}
                                className="grid h-7 w-7 place-items-center rounded-lg text-slate-500 transition hover:bg-rose-500/15 hover:text-rose-300"
                                aria-label={t.del}
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </>
                        )}
                        {isActive && !isEditing && !isConfirming && (
                          <span className="absolute inset-y-2 end-0 w-[3px] rounded-full bg-gradient-to-b from-violet-400 to-fuchsia-500" />
                        )}
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </div>
          ))
        )}
      </div>

      {/* فوتر امنیتی */}
      <div className="border-t border-white/[0.06] px-5 py-3.5">
        <div className="flex items-center gap-2 text-[11px] text-slate-600">
          <ShieldCheck size={12} className="text-emerald-400/70" />
          <span>{t.secureFooter}</span>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* نسخه دسکتاپ */}
      <aside className="relative hidden h-full w-[300px] shrink-0 border-e border-white/[0.06] bg-[#0a0a12]/80 backdrop-blur-xl lg:block">
        {content}
      </aside>

      {/* نسخه موبایل */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
              className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm lg:hidden"
            />
            <motion.aside
              initial={{ x: t.dir === "rtl" ? "100%" : "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: t.dir === "rtl" ? "100%" : "-100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="fixed inset-y-0 end-0 z-40 w-[290px] border-s border-white/10 bg-[#0a0a12] lg:hidden"
            >
              {content}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
