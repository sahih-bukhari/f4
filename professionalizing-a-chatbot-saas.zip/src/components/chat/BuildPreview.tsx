"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { zipSync, strToU8 } from "fflate";
import {
  Check,
  Copy,
  Database,
  Download,
  ExternalLink,
  FileCode2,
  FileText,
  Folder,
  Monitor,
  RotateCw,
  Smartphone,
  Tablet,
  X,
} from "lucide-react";
import { useLang } from "@/lib/i18n";
import { num } from "@/lib/format";

type ProjectFile = { path: string; content: string };
type Build = {
  id: string;
  title: string;
  html: string;
  files: ProjectFile[];
  fileCount: number;
};
type Device = "desktop" | "tablet" | "mobile";
type Tab = "preview" | "files";

const DEVICE_WIDTH: Record<Device, string> = { desktop: "100%", tablet: "768px", mobile: "390px" };

function fileIcon(path: string) {
  if (/readme|\.md$/i.test(path)) return FileText;
  if (/\.(json|ya?ml|toml|env|txt|csv)$/i.test(path)) return FileText;
  return FileCode2;
}

export function BuildPreview({
  buildId,
  onClose,
}: {
  buildId: string | null;
  onClose: () => void;
}) {
  const { t, lang } = useLang();
  const [build, setBuild] = useState<Build | null>(null);
  const [failed, setFailed] = useState(false);
  const [device, setDevice] = useState<Device>("desktop");
  const [tab, setTab] = useState<Tab>("preview");
  const [frameKey, setFrameKey] = useState(0);
  const [copied, setCopied] = useState(false);
  const [fileCopied, setFileCopied] = useState<string | null>(null);
  const [openPath, setOpenPath] = useState<string | null>(null);

  useEffect(() => {
    if (!buildId) return;
    setBuild(null);
    setFailed(false);
    setTab("preview");
    setOpenPath(null);
    setFrameKey((k) => k + 1);
    fetch(`/api/builds/${buildId}?full=1`)
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => {
        setBuild(d.build);
        const first = (d.build.files as ProjectFile[])?.[0];
        if (first) setOpenPath(first.path);
      })
      .catch(() => setFailed(true));
  }, [buildId]);

  const close = useCallback(() => onClose(), [onClose]);

  useEffect(() => {
    if (!buildId) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") close();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [buildId, close]);

  const hasFiles = Boolean(build?.files?.length);
  const openFile = useMemo(
    () => build?.files?.find((f) => f.path === openPath) ?? build?.files?.[0] ?? null,
    [build, openPath]
  );

  async function copyText(text: string, which: "all" | string) {
    try {
      await navigator.clipboard.writeText(text);
      if (which === "all") {
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      } else {
        setFileCopied(which);
        setTimeout(() => setFileCopied(null), 1500);
      }
    } catch {
      /* noop */
    }
  }

  function downloadHtml() {
    if (!build) return;
    const blob = new Blob([build.html], { type: "text/html" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${build.title.replace(/\s+/g, "-").slice(0, 40) || "nova-app"}.html`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }

  function downloadZip() {
    if (!build) return;
    const entries: Record<string, Uint8Array> = {};
    const files = build.files?.length
      ? build.files
      : [{ path: "index.html", content: build.html }];
    for (const f of files) entries[f.path] = strToU8(f.content);
    const zipped = zipSync(entries, { level: 6 });
    const blob = new Blob([new Uint8Array(zipped)], { type: "application/zip" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${build.title.replace(/\s+/g, "-").slice(0, 40) || "nova-project"}.zip`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }

  function openTabPreview() {
    if (!build) return;
    const blob = new Blob([build.html], { type: "text/html" });
    window.open(URL.createObjectURL(blob), "_blank", "noopener,noreferrer");
  }

  const devices: { k: Device; icon: typeof Monitor; label: string }[] = [
    { k: "desktop", icon: Monitor, label: "Desktop" },
    { k: "tablet", icon: Tablet, label: "Tablet" },
    { k: "mobile", icon: Smartphone, label: "Mobile" },
  ];

  return (
    <AnimatePresence>
      {buildId && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex flex-col bg-[#050509]/95 backdrop-blur-xl"
        >
          {/* هدر پنل */}
          <div className="flex h-14 shrink-0 items-center gap-3 border-b border-white/[0.07] px-4">
            {/* تب‌ها */}
            <div className="flex items-center gap-1 rounded-xl border border-white/10 bg-white/[0.04] p-1">
              <button
                onClick={() => setTab("preview")}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12px] font-bold transition ${
                  tab === "preview" ? "bg-violet-500/25 text-violet-200" : "text-slate-500 hover:text-white"
                }`}
              >
                <Monitor size={13} />
                <span className="hidden sm:inline">{t.previewTab}</span>
              </button>
              <button
                onClick={() => setTab("files")}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12px] font-bold transition ${
                  tab === "files" ? "bg-violet-500/25 text-violet-200" : "text-slate-500 hover:text-white"
                }`}
              >
                <Folder size={13} />
                <span className="hidden sm:inline">{t.filesTab}</span>
                {build && hasFiles && (
                  <span className="rounded-full bg-white/10 px-1.5 text-[10px] text-slate-300" dir="ltr">
                    {num(build.files.length, lang)}
                  </span>
                )}
              </button>
            </div>

            <h2 className="flex min-w-0 items-center gap-2 truncate text-sm font-bold text-white">
              {build?.title ?? "…"}
              {hasFiles && (
                <span className="hidden shrink-0 items-center gap-1 rounded-full border border-cyan-400/25 bg-cyan-400/10 px-2 py-px text-[10px] font-bold text-cyan-300 md:flex">
                  <Database size={10} />
                  {t.backendBadge}
                </span>
              )}
            </h2>

            {tab === "preview" && (
              <div className="ms-auto hidden items-center gap-1 rounded-xl border border-white/10 bg-white/[0.04] p-1 sm:flex">
                {devices.map((d) => (
                  <button
                    key={d.k}
                    onClick={() => setDevice(d.k)}
                    title={d.label}
                    className={`grid h-8 w-8 place-items-center rounded-lg transition ${
                      device === d.k ? "bg-violet-500/25 text-violet-200" : "text-slate-500 hover:text-white"
                    }`}
                  >
                    <d.icon size={15} />
                  </button>
                ))}
              </div>
            )}

            <div className="ms-auto flex items-center gap-1.5 sm:ms-0">
              {tab === "preview" && (
                <button onClick={() => setFrameKey((k) => k + 1)} title={t.refresh}
                  className="grid h-9 w-9 place-items-center rounded-lg text-slate-400 transition hover:bg-white/5 hover:text-white">
                  <RotateCw size={15} />
                </button>
              )}
              <button onClick={downloadZip} title={t.downloadZip}
                className="grid h-9 w-9 place-items-center rounded-lg text-slate-400 transition hover:bg-white/5 hover:text-white">
                <Download size={15} />
              </button>
              {tab === "preview" && (
                <>
                  <button onClick={() => build && copyText(build.html, "all")} title={t.copyCode}
                    className="grid h-9 w-9 place-items-center rounded-lg text-slate-400 transition hover:bg-white/5 hover:text-white">
                    {copied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}
                  </button>
                  <button onClick={openTabPreview} title={t.openNewTab}
                    className="grid h-9 w-9 place-items-center rounded-lg text-slate-400 transition hover:bg-white/5 hover:text-white">
                    <ExternalLink size={15} />
                  </button>
                </>
              )}
              <button onClick={close} title={t.close}
                className="ms-1 grid h-9 w-9 place-items-center rounded-lg border border-white/10 text-slate-300 transition hover:bg-rose-500/15 hover:text-rose-300">
                <X size={16} />
              </button>
            </div>
          </div>

          {/* بدنه */}
          <div className="relative flex min-h-0 flex-1 overflow-hidden bg-[radial-gradient(800px_400px_at_50%_0%,rgba(139,92,246,0.08),transparent)]">
            {failed ? (
              <div className="m-auto rounded-xl border border-rose-400/30 bg-rose-500/10 px-5 py-4 text-sm text-rose-200">
                {t.errGeneric}
              </div>
            ) : !build ? (
              <div className="m-4 h-[85%] w-full max-w-5xl animate-pulse rounded-2xl border border-white/[0.06] bg-white/[0.03] sm:m-6" />
            ) : tab === "preview" ? (
              <div className="flex w-full items-start justify-center p-3 sm:p-6">
                <motion.div
                  key={frameKey}
                  initial={{ opacity: 0, scale: 0.985 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                  className="h-[calc(100dvh-120px)] overflow-hidden rounded-2xl border border-white/10 bg-white shadow-[0_30px_90px_-20px_rgba(0,0,0,0.8)] transition-[max-width] duration-500"
                  style={{ maxWidth: DEVICE_WIDTH[device], width: "100%" }}
                >
                  <iframe
                    title={build.title}
                    sandbox="allow-scripts allow-modals"
                    srcDoc={build.html}
                    className="h-full w-full border-0"
                  />
                </motion.div>
              </div>
            ) : (
              /* مرورگر فایل‌های پروژه */
              <div className="flex min-h-0 w-full">
                <aside className="w-52 shrink-0 overflow-y-auto border-e border-white/[0.07] p-2 sm:w-64">
                  {build.files.map((f) => {
                    const Icon = fileIcon(f.path);
                    const active = openFile?.path === f.path;
                    return (
                      <button
                        key={f.path}
                        onClick={() => setOpenPath(f.path)}
                        className={`group mb-0.5 flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-start text-[12px] transition ${
                          active ? "bg-violet-500/[0.15] text-white" : "text-slate-400 hover:bg-white/[0.05] hover:text-slate-200"
                        }`}
                      >
                        <Icon size={13} className={`shrink-0 ${active ? "text-violet-300" : "text-slate-600"}`} />
                        <span className="truncate font-mono" dir="ltr">{f.path}</span>
                      </button>
                    );
                  })}
                </aside>
                <div className="flex min-w-0 flex-1 flex-col">
                  {openFile ? (
                    <>
                      <div className="flex items-center justify-between border-b border-white/[0.07] px-4 py-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[12px] text-cyan-300" dir="ltr">{openFile.path}</span>
                          <span className="text-[11px] text-slate-600">
                            {t.fileLines(num(openFile.content.split("\n").length, lang))}
                          </span>
                        </div>
                        <button
                          onClick={() => copyText(openFile.content, openFile.path)}
                          className="flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11px] text-slate-400 transition hover:bg-white/5 hover:text-white"
                        >
                          {fileCopied === openFile.path ? (
                            <><Check size={12} className="text-emerald-400" />{t.copied}</>
                          ) : (
                            <><Copy size={12} />{t.copy}</>
                          )}
                        </button>
                      </div>
                      <pre dir="ltr" className="min-h-0 flex-1 overflow-auto p-4 font-mono text-[12.5px] leading-6 text-slate-300">
                        {openFile.content}
                      </pre>
                    </>
                  ) : (
                    <div className="m-auto text-sm text-slate-600">{t.selectFile}</div>
                  )}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
