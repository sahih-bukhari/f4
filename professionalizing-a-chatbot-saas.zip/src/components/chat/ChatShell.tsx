"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowDown, Cpu, Languages, PanelRightOpen, ShieldAlert, Square } from "lucide-react";
import { Composer, type ComposerMode } from "./Composer";
import { EmptyState } from "./EmptyState";
import { BuildPreview } from "./BuildPreview";
import { OPEN_BUILD_EVENT } from "./BuildCard";
import { ProcessCard, STEP_IDS, type ProcessStep, type StepState } from "./ProcessCard";
import { LangProvider, useLang, type Dict } from "@/lib/i18n";
import { MessageBubble, TypingDots } from "./MessageBubble";
import { Sidebar } from "./Sidebar";
import { AccountMenu } from "@/components/account/AccountMenu";
import { num } from "@/lib/format";
import type { ChatConversation, ChatMessage } from "@/lib/types";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** نگاشت کدهای خطای سرور به پیام محلی‌سازی‌شده */
function localizedError(code: string | undefined, retryAfterSec: number | undefined, t: Dict, lang: "fa" | "en"): string {
  switch (code) {
    case "rate_limited":
      return t.errRateLimited(num(retryAfterSec ?? 60, lang));
    case "missing_key":
      return t.errMissingKey;
    case "timeout":
      return t.errTimeout;
    case "conversation_full":
      return t.errFull;
    case "daily_quota":
      return t.errDailyQuota;
    case "blocked":
      return t.errBlocked;
    case "upstream_busy":
    case "upstream_error":
      return t.errUpstream;
    default:
      return t.errGeneric;
  }
}

function ChatApp() {
  const { lang, t, toggle } = useLang();
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadingConvs, setLoadingConvs] = useState(true);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const [busy, setBusy] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showJump, setShowJump] = useState(false);
  const [streamingId, setStreamingId] = useState<string | null>(null);
  const [service, setService] = useState<{ configured: boolean; model: string } | null>(null);
  const [mode, setMode] = useState<ComposerMode>("chat");
  const [buildSteps, setBuildSteps] = useState<ProcessStep[] | null>(null);
  const [buildChars, setBuildChars] = useState(0);
  const [openBuildId, setOpenBuildId] = useState<string | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const streamToken = useRef(0);
  const nearBottom = useRef(true);
  const buildAbort = useRef<AbortController | null>(null);

  /* ------------------------------- data loading ------------------------------ */

  const loadConversations = useCallback(async () => {
    try {
      const res = await fetch("/api/conversations");
      if (!res.ok) return;
      const data = (await res.json()) as { conversations: ChatConversation[] };
      setConversations(data.conversations);
    } catch {
      /* noop */
    } finally {
      setLoadingConvs(false);
    }
  }, []);

  useEffect(() => {
    void loadConversations();
    fetch("/api/config")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => d && setService(d))
      .catch(() => setService(null));
  }, [loadConversations]);

  async function openConversation(id: string) {
    if (id === activeId) return;
    streamToken.current++;
    setStreamingId(null);
    setBusy(false);
    setActiveId(id);
    setMessages([]);
    setLoadingMsgs(true);
    setError(null);
    try {
      const res = await fetch(`/api/conversations/${id}`);
      if (!res.ok) throw new Error("load");
      const data = (await res.json()) as { messages: ChatMessage[] };
      setMessages(data.messages);
    } catch {
      setError(t.errGeneric);
    } finally {
      setLoadingMsgs(false);
    }
  }

  const startNewChat = useCallback(() => {
    streamToken.current++;
    setStreamingId(null);
    setBusy(false);
    setActiveId(null);
    setMessages([]);
    setError(null);
    setSidebarOpen(false);
  }, []);

  async function renameConversation(id: string, title: string) {
    setConversations((cs) => cs.map((c) => (c.id === id ? { ...c, title } : c)));
    try {
      const res = await fetch(`/api/conversations/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title }),
      });
      if (!res.ok) throw new Error();
    } catch {
      void loadConversations();
    }
  }

  async function deleteConversation(id: string) {
    const backup = conversations;
    setConversations((cs) => cs.filter((c) => c.id !== id));
    if (activeId === id) startNewChat();
    try {
      const res = await fetch(`/api/conversations/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
    } catch {
      setConversations(backup);
    }
  }

  /* ------------------------------ streaming reply ----------------------------- */

  async function streamAssistantMessage(finalMsg: ChatMessage) {
    const token = streamToken.current;
    const full = finalMsg.content;
    const step = full.length > 1200 ? 14 : full.length > 500 ? 8 : 4;

    setStreamingId(finalMsg.id);
    setMessages((ms) => [...ms, { ...finalMsg, content: "" }]);
    await sleep(350);

    for (let i = step; i < full.length + step; i += step) {
      if (streamToken.current !== token) return;
      const slice = full.slice(0, i);
      setMessages((ms) =>
        ms.map((m) => (m.id === finalMsg.id ? { ...m, content: slice } : m))
      );
      await sleep(14);
    }
    if (streamToken.current !== token) return;
    setMessages((ms) =>
      ms.map((m) => (m.id === finalMsg.id ? { ...m, content: full } : m))
    );
    setStreamingId(null);
  }

  function stopStreaming() {
    streamToken.current++;
    setStreamingId(null);
    setBusy(false);
  }

  /* --------------------------------- send ------------------------------------ */

  const sendChat = useCallback(
    async (text: string, uploadIds?: string[]) => {
      if (busy) return;
      setBusy(true);
      setError(null);
      const token = ++streamToken.current;

      const optimistic: ChatMessage = {
        id: `tmp-${Date.now()}`,
        role: "user",
        content: text,
        createdAt: new Date().toISOString(),
      };
      setMessages((ms) => [...ms, optimistic]);

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            conversationId: activeId ?? undefined,
            message: text,
            lang,
            uploadIds,
          }),
        });
        if (!res.ok) {
          const data = (await res.json().catch(() => null)) as {
            error?: string;
            code?: string;
            retryAfterSec?: number;
          } | null;
          throw new Error(
            data?.code
              ? localizedError(data.code, data.retryAfterSec, t, lang)
              : data?.error ?? t.errGeneric
          );
        }
        const data = (await res.json()) as {
          conversationId: string;
          title: string | null;
          userMessage: ChatMessage;
          assistantMessage: ChatMessage;
        };

        if (streamToken.current !== token) return;

        if (!activeId) {
          setActiveId(data.conversationId);
          setConversations((cs) => [
            {
              id: data.conversationId,
              title: data.title ?? t.defaultChatTitle,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
            ...cs,
          ]);
        } else {
          setConversations((cs) =>
            cs.map((c) =>
              c.id === data.conversationId
                ? { ...c, updatedAt: new Date().toISOString() }
                : c
            )
          );
        }

        setMessages((ms) =>
          ms.map((m) => (m.id === optimistic.id ? data.userMessage : m))
        );
        await streamAssistantMessage(data.assistantMessage);
      } catch (err) {
        if (streamToken.current !== token) return;
        setMessages((ms) => ms.filter((m) => m.id !== optimistic.id));
        setError(
          err instanceof TypeError
            ? t.errNetwork
            : err instanceof Error
              ? err.message
              : t.errGeneric
        );
      } finally {
        if (streamToken.current === token) setBusy(false);
      }
    },
    [busy, activeId, lang, t]
  );

  /* ------------------------------ build mode (SSE) ---------------------------- */

  const cancelBuild = useCallback(() => {
    buildAbort.current?.abort();
    streamToken.current++;
    setBuildSteps(null);
    setBusy(false);
    // پیام خوش‌بینانه‌ی لغوشده را بردار
    setMessages((ms) => ms.filter((m) => !m.id.startsWith("tmp-")));
  }, []);

  const sendBuild = useCallback(
    async (text: string, uploadIds?: string[]) => {
      if (busy) return;
      setBusy(true);
      setError(null);
      const token = ++streamToken.current;

      const optimistic: ChatMessage = {
        id: `tmp-${Date.now()}`,
        role: "user",
        content: text,
        createdAt: new Date().toISOString(),
      };
      setMessages((ms) => [...ms, optimistic]);
      setBuildSteps(STEP_IDS.map((id) => ({ id, state: "pending" }) as ProcessStep));
      setBuildChars(0);

      const ctrl = new AbortController();
      buildAbort.current = ctrl;

      try {
        const res = await fetch("/api/build", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            conversationId: activeId ?? undefined,
            message: text,
            lang,
            uploadIds,
          }),
          signal: ctrl.signal,
        });

        if (!res.ok || !res.body) {
          const data = (await res.json().catch(() => null)) as {
            code?: string;
            retryAfterSec?: number;
          } | null;
          const mapped = localizedError(data?.code, data?.retryAfterSec, t, lang);
          throw new Error(mapped === t.errGeneric ? t.errBuild : mapped);
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buf = "";
        let doneData: { buildId: string; conversationId: string; title: string } | null = null;

        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          const chunks = buf.split("\n\n");
          buf = chunks.pop() ?? "";
          for (const chunk of chunks) {
            const line = chunk.trim();
            if (!line.startsWith("data:")) continue;
            let ev: {
              t: string;
              id?: string;
              s?: "run" | "done";
              n?: number;
              code?: string;
              buildId?: string;
              conversationId?: string;
              title?: string;
            };
            try {
              ev = JSON.parse(line.slice(5));
            } catch {
              continue;
            }
            if (streamToken.current !== token) return;
            if (ev.t === "step" && ev.id && ev.s) {
              const stepId = ev.id;
              const stepState = ev.s as StepState;
              setBuildSteps((st) =>
                st?.map((x) => (x.id === stepId ? { ...x, state: stepState } : x)) ?? st
              );
            } else if (ev.t === "progress" && typeof ev.n === "number") {
              setBuildChars(ev.n);
            } else if (ev.t === "done" && ev.buildId && ev.conversationId && ev.title) {
              doneData = { buildId: ev.buildId, conversationId: ev.conversationId, title: ev.title };
            } else if (ev.t === "error") {
              const mapped = localizedError(ev.code, undefined, t, lang);
              throw new Error(mapped === t.errGeneric ? t.errBuild : mapped);
            }
          }
        }

        if (streamToken.current !== token) return;
        if (!doneData) throw new Error(t.errBuild);

        const summary =
          lang === "fa"
            ? `ساختمش! **«${doneData.title}»** آماده است — روی کارت زیر بزن تا پیش‌نمایش زنده را ببینی و کدش را بگیری.`
            : `Done! **"${doneData.title}"** is ready — open the card below for the live preview and code.`;

        const buildMsgContent = `${summary}\n\n\`\`\`build\n${doneData.buildId}\n\`\`\``;
        const convId = doneData.conversationId;

        setMessages((ms) => [
          ...ms.map((m) =>
            m.id === optimistic.id ? { ...m, id: `u-${doneData!.buildId}` } : m
          ),
          {
            id: `a-${doneData.buildId}`,
            role: "assistant",
            content: buildMsgContent,
            createdAt: new Date().toISOString(),
          } as ChatMessage,
        ]);

        if (!activeId) {
          setActiveId(convId);
          setConversations((cs) => [
            {
              id: convId,
              title: doneData!.title,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
            ...cs,
          ]);
        }

        // باز شدن خودکار پنل پیش‌نمایش — حس Lovable
        setOpenBuildId(doneData.buildId);
      } catch (err) {
        if (streamToken.current !== token) return;
        setMessages((ms) => ms.filter((m) => m.id !== optimistic.id));
        if (!(err instanceof Error && err.name === "AbortError")) {
          setError(
            err instanceof TypeError
              ? t.errNetwork
              : err instanceof Error
                ? err.message
                : t.errBuild
          );
        }
      } finally {
        if (streamToken.current === token) {
          setBusy(false);
          setBuildSteps(null);
          buildAbort.current = null;
        }
      }
    },
    [busy, activeId, lang, t]
  );

  const send = useCallback(
    (text: string, uploadIds?: string[]) => {
      if (mode === "build") void sendBuild(text, uploadIds);
      else void sendChat(text, uploadIds);
    },
    [mode, sendBuild, sendChat]
  );

  /* ------------------------------- shortcuts --------------------------------- */

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        startNewChat();
        document.getElementById("nova-composer")?.focus();
      } else if (e.key === "/" && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) {
        e.preventDefault();
        document.getElementById("nova-composer")?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [startNewChat]);

  /* ------------------------- باز کردن پنل پیش‌نمایش ساخت ------------------------ */

  useEffect(() => {
    function onOpen(e: Event) {
      const id = (e as CustomEvent<{ id?: string }>).detail?.id;
      if (id) setOpenBuildId(id);
    }
    window.addEventListener(OPEN_BUILD_EVENT, onOpen);
    return () => window.removeEventListener(OPEN_BUILD_EVENT, onOpen);
  }, []);

  /* --------------------------------- scroll ---------------------------------- */

  useEffect(() => {
    const el = scrollRef.current;
    if (!el || !nearBottom.current) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  function onScroll() {
    const el = scrollRef.current;
    if (!el) return;
    const dist = el.scrollHeight - el.scrollTop - el.clientHeight;
    nearBottom.current = dist < 120;
    setShowJump(dist > 300);
  }

  const isEmpty = !activeId && messages.length === 0;

  return (
    <div className="relative flex h-dvh overflow-hidden">
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        open={sidebarOpen}
        loading={loadingConvs}
        onClose={() => setSidebarOpen(false)}
        onSelect={openConversation}
        onNew={startNewChat}
        onRename={renameConversation}
        onDelete={deleteConversation}
      />

      <main className="relative flex min-w-0 flex-1 flex-col">
        {/* هدر */}
        <header className="relative z-10 flex h-14 shrink-0 items-center gap-3 border-b border-white/[0.06] bg-[#07070d]/70 px-4 backdrop-blur-xl sm:px-6">
          <button
            onClick={() => setSidebarOpen(true)}
            className="grid h-9 w-9 place-items-center rounded-lg text-slate-400 transition hover:bg-white/5 hover:text-white lg:hidden"
            aria-label={t.menu}
          >
            <PanelRightOpen size={17} />
          </button>
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400" />
            </span>
            <span className="text-sm font-bold text-white">
              {lang === "fa" ? "نُوا" : "Nova"}
            </span>
            <span className="text-xs text-slate-500">{t.online}</span>
          </div>
          <div className="ms-auto flex items-center gap-2">
            {service && (
              <span
                className={`hidden items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] sm:flex ${
                  service.configured
                    ? "border-emerald-400/20 bg-emerald-400/[0.07] text-emerald-300/90"
                    : "border-amber-400/25 bg-amber-400/[0.07] text-amber-300/90"
                }`}
              >
                <Cpu size={11} />
                {service.configured ? t.modelOn(service.model) : t.modelOff}
              </span>
            )}
            <AccountMenu />
            <button
              onClick={toggle}
              className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[11px] font-bold text-slate-300 transition hover:border-violet-400/40 hover:text-white"
              aria-label={t.langLabel}
            >
              <Languages size={12} className="text-cyan-300" />
              {t.langLabel}
            </button>
          </div>
        </header>

        {/* بنر وضعیت سرویس */}
        {service && !service.configured && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative z-10 flex shrink-0 items-center justify-center gap-2 border-b border-amber-400/20 bg-amber-400/[0.06] px-4 py-2 text-center text-[12px] text-amber-200/90"
          >
            <ShieldAlert size={14} className="shrink-0" />
            {t.bannerA}{" "}
            <code dir="ltr" className="rounded bg-white/10 px-1.5 py-px font-mono text-[11px]">
              OPENAI_API_KEY
            </code>
            {t.bannerB}
          </motion.div>
        )}

        {/* ناحیه پیام‌ها */}
        <div
          ref={scrollRef}
          onScroll={onScroll}
          className="relative flex-1 overflow-y-auto overscroll-contain"
        >
          {isEmpty ? (
            <EmptyState onPick={send} />
          ) : (
            <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 pt-8 pb-48 sm:px-6">
              {loadingMsgs ? (
                <div className="flex flex-col gap-6 pt-4">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className="flex items-start gap-3"
                      style={{ opacity: 0.5 - i * 0.13 }}
                    >
                      <div className="h-[34px] w-[34px] shrink-0 animate-pulse rounded-full bg-white/10" />
                      <div className="h-20 w-2/3 animate-pulse rounded-2xl bg-white/[0.05]" />
                    </div>
                  ))}
                </div>
              ) : (
                messages.map((m) => (
                  <MessageBubble key={m.id} message={m} streaming={m.id === streamingId} />
                ))
              )}

              {/* کارت روند ساخت — مثل Lovable */}
              {buildSteps && (
                <ProcessCard steps={buildSteps} chars={buildChars} onCancel={cancelBuild} />
              )}

              {/* نشانگر فکر کردن */}
              {busy && !streamingId && !buildSteps && messages[messages.length - 1]?.role === "user" && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-3"
                >
                  <div className="relative h-[34px] w-[34px]">
                    <div className="absolute inset-0 animate-pulse rounded-full bg-violet-500/40 blur-md" />
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src="/images/nova-avatar.png"
                      alt=""
                      className="relative h-full w-full rounded-full border border-white/15 object-cover"
                    />
                  </div>
                  <div className="flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.045] px-4 py-3">
                    <TypingDots />
                    <span className="animate-[shimmer_2s_linear_infinite] bg-[length:200%_100%] bg-gradient-to-l from-violet-300 via-slate-300 to-cyan-300 bg-clip-text text-[12px] text-transparent">
                      {t.thinking}
                    </span>
                  </div>
                </motion.div>
              )}

              {error && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-xl border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200"
                >
                  {error}
                </motion.div>
              )}
            </div>
          )}

          {/* دکمه پرش به پایین */}
          <AnimatePresence>
            {showJump && (
              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                onClick={() => {
                  nearBottom.current = true;
                  scrollRef.current?.scrollTo({
                    top: scrollRef.current.scrollHeight,
                    behavior: "smooth",
                  });
                }}
                className="fixed bottom-32 left-1/2 z-10 grid h-9 w-9 -translate-x-1/2 place-items-center rounded-full border border-white/15 bg-[#12121c]/90 text-slate-300 shadow-lg backdrop-blur transition hover:text-white"
                aria-label={t.jump}
              >
                <ArrowDown size={15} />
              </motion.button>
            )}
          </AnimatePresence>
        </div>

        {/* دکمه توقف پاسخ */}
        <AnimatePresence>
          {streamingId && (
            <motion.button
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              onClick={stopStreaming}
              className="fixed bottom-28 left-1/2 z-20 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/15 bg-[#14141f]/95 px-4 py-2 text-[12px] font-bold text-slate-200 shadow-[0_10px_30px_rgba(0,0,0,0.5)] backdrop-blur transition hover:border-rose-400/40 hover:text-rose-200"
              aria-label={t.stopAria}
            >
              <Square size={11} className="fill-current" />
              {t.stop}
            </motion.button>
          )}
        </AnimatePresence>

        <Composer
          disabled={busy}
          mode={mode}
          onModeChange={setMode}
          onSend={send}
        />

        {/* پنل پیش‌نمایش زنده‌ی ساخت‌ها */}
        <BuildPreview buildId={openBuildId} onClose={() => setOpenBuildId(null)} />
      </main>
    </div>
  );
}

export function ChatShell() {
  return (
    <LangProvider>
      <ChatApp />
    </LangProvider>
  );
}
