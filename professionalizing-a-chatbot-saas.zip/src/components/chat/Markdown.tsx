"use client";

import { memo, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Check, Copy } from "lucide-react";
import { BuildCard } from "./BuildCard";
import { AttachmentChips } from "./AttachmentChips";

function CodeBlock({ lang, code }: { lang: string; code: string }) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      /* noop */
    }
  }

  return (
    <div dir="ltr" className="group/code my-3 overflow-hidden rounded-xl border border-white/10 bg-[#0b0b14] shadow-[0_8px_30px_rgba(0,0,0,0.45)]">
      <div className="flex items-center justify-between border-b border-white/10 bg-white/[0.04] px-3.5 py-1.5">
        <span className="text-[11px] font-medium tracking-wider text-violet-300/80 uppercase">
          {lang || "code"}
        </span>
        <button
          onClick={copy}
          className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] text-slate-400 transition hover:bg-white/10 hover:text-white"
        >
          {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
          {copied ? "کپی شد" : "کپی"}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 text-[13px] leading-6 text-slate-200">
        <code className="font-mono">{code}</code>
      </pre>
    </div>
  );
}

export const Markdown = memo(function Markdown({ content }: { content: string }) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      components={{
        code({ className, children, ...props }) {
          const inline = !className;
          const code = String(children).replace(/\n$/, "");
          if (inline) {
            return (
              <code
                dir="ltr"
                className="rounded-md border border-white/10 bg-white/[0.07] px-1.5 py-0.5 font-mono text-[0.85em] text-cyan-200"
                {...props}
              >
                {code}
              </code>
            );
          }
          const lang = /language-(\w+)/.exec(className)?.[1] ?? "";
          // بلوک ویژه‌ی ساخت → کارت پیش‌نمایش زنده
          if (lang === "build") {
            return <BuildCard id={code.trim()} />;
          }
          // بلوک ویژه‌ی پیوست‌ها → چیپ فایل
          if (lang === "attachments") {
            return <AttachmentChips json={code} />;
          }
          return <CodeBlock lang={lang} code={code} />;
        },
        p({ children }) {
          return <p className="my-2 leading-8 first:mt-0 last:mb-0">{children}</p>;
        },
        ul({ children }) {
          return <ul className="my-2 list-disc space-y-1.5 ps-5 marker:text-violet-400">{children}</ul>;
        },
        ol({ children }) {
          return <ol className="my-2 list-decimal space-y-1.5 ps-5 marker:text-violet-400">{children}</ol>;
        },
        li({ children }) {
          return <li className="leading-7">{children}</li>;
        },
        a({ href, children }) {
          return (
            <a
              href={href}
              target="_blank"
              rel="noreferrer"
              className="text-cyan-300 underline decoration-cyan-300/40 underline-offset-4 transition hover:text-cyan-200"
            >
              {children}
            </a>
          );
        },
        blockquote({ children }) {
          return (
            <blockquote className="my-3 rounded-lg border-s-2 border-violet-400/60 bg-violet-400/[0.07] px-4 py-1 text-violet-100/90 italic">
              {children}
            </blockquote>
          );
        },
        table({ children }) {
          return (
            <div className="my-3 overflow-x-auto rounded-xl border border-white/10">
              <table className="w-full border-collapse text-sm">{children}</table>
            </div>
          );
        },
        thead({ children }) {
          return <thead className="bg-white/[0.06]">{children}</thead>;
        },
        th({ children }) {
          return (
            <th className="border-b border-white/10 px-3.5 py-2 text-start font-semibold text-white">
              {children}
            </th>
          );
        },
        td({ children }) {
          return <td className="border-b border-white/5 px-3.5 py-2 align-top">{children}</td>;
        },
        hr() {
          return <hr className="my-4 border-white/10" />;
        },
        strong({ children }) {
          return <strong className="font-bold text-white">{children}</strong>;
        },
        h1({ children }) {
          return <h1 className="mt-4 mb-2 text-xl font-extrabold text-white">{children}</h1>;
        },
        h2({ children }) {
          return <h2 className="mt-4 mb-2 text-lg font-extrabold text-white">{children}</h2>;
        },
        h3({ children }) {
          return <h3 className="mt-3 mb-1.5 text-base font-bold text-white">{children}</h3>;
        },
      }}
    >
      {content}
    </ReactMarkdown>
  );
});
