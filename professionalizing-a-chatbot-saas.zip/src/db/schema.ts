import { pgTable, uuid, text, timestamp, index, jsonb, integer, boolean, primaryKey } from "drizzle-orm/pg-core";

export const conversations = pgTable(
  "conversations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    /**
     * شناسه‌ی جلسه‌ی ناشناس مالک — برای ایزوله‌سازی حریم خصوصی بازدیدکنندگان.
     * رکوردهای قدیمی با مقدار null در لیست‌ها نمایش داده نمی‌شوند.
     */
    sessionId: text("session_id"),
    title: text("title").notNull().default("گفت‌وگوی جدید"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    index("conversations_updated_at_idx").on(t.updatedAt),
    index("conversations_session_idx").on(t.sessionId, t.updatedAt),
  ]
);

export const messages = pgTable(
  "messages",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    role: text("role", { enum: ["user", "assistant"] }).notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("messages_conversation_idx").on(t.conversationId, t.createdAt)]
);

export const builds = pgTable(
  "builds",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    /** مالک = جلسه‌ی ناشناس */
    sessionId: text("session_id").notNull(),
    title: text("title").notNull(),
    prompt: text("prompt").notNull(),
    /** پیش‌نمایش زنده‌ی تک‌فایلی */
    html: text("html").notNull(),
    /** پروژه‌ی چندفایلی: [{path, content}] — برای ساخت‌های فول‌استک */
    files: jsonb("files").$type<{ path: string; content: string }[]>(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("builds_session_idx").on(t.sessionId, t.createdAt)]
);

export const uploads = pgTable(
  "uploads",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    /** مالک = جلسه‌ی ناشناس */
    sessionId: text("session_id").notNull(),
    name: text("name").notNull(),
    ext: text("ext").notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    /** متن استخراج‌شده برای کانتکست مدل — حداکثر ۸۰۰۰ نویسه */
    extract: text("extract").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("uploads_session_idx").on(t.sessionId, t.createdAt)]
);

export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Build = typeof builds.$inferSelect;
export type Upload = typeof uploads.$inferSelect;

/* ------------------------------ حساب کاربری ------------------------------ */

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    email: text("email").notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    role: text("role", { enum: ["user", "admin"] }).notNull().default("user"),
    /**
     * شناسه‌ی جلسه‌ی پایدار کاربر — همان مقدار کوکی nova_sid است.
     * به‌این‌ترتیب تمام جدول‌های قبلی (گفتگو، ساخت، فایل) بدون تغییر کار می‌کنند.
     */
    sessionId: text("session_id").notNull().unique(),
    plan: text("plan", { enum: ["free", "pro"] }).notNull().default("free"),
    planExpiresAt: timestamp("plan_expires_at", { withTimezone: true }),
    blocked: boolean("blocked").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("users_created_idx").on(t.createdAt)]
);

export const authSessions = pgTable(
  "auth_sessions",
  {
    /** هش SHA-256 توکن (خود توکن فقط در کوکی کاربر است) */
    tokenHash: text("token_hash").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("auth_sessions_user_idx").on(t.userId)]
);

export const passwordResets = pgTable(
  "password_resets",
  {
    tokenHash: text("token_hash").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
  },
  (t) => [index("password_resets_user_idx").on(t.userId)]
);

/** مصرف روزانه به‌ازای هر جلسه (کاربر ثبت‌نام‌شده یا مهمان) و نوع */
export const usage = pgTable(
  "usage",
  {
    sessionId: text("session_id").notNull(),
    day: text("day").notNull(), // YYYY-MM-DD (UTC)
    kind: text("kind", { enum: ["chat", "build"] }).notNull(),
    count: integer("count").notNull().default(0),
  },
  (t) => [primaryKey({ columns: [t.sessionId, t.day, t.kind] })]
);

export const payments = pgTable(
  "payments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    provider: text("provider").notNull(), // manual | stripe
    status: text("status", { enum: ["pending", "paid", "rejected", "canceled"] })
      .notNull()
      .default("pending"),
    amountCents: integer("amount_cents").notNull(),
    currency: text("currency").notNull().default("usd"),
    months: integer("months").notNull().default(1),
    /** شناسه‌ی سمت درگاه (Stripe session) یا کد پیگیری پرداخت دستی */
    externalId: text("external_id"),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    paidAt: timestamp("paid_at", { withTimezone: true }),
  },
  (t) => [
    index("payments_user_idx").on(t.userId, t.createdAt),
    index("payments_status_idx").on(t.status),
    index("payments_external_idx").on(t.externalId),
  ]
);

export type User = typeof users.$inferSelect;
export type Payment = typeof payments.$inferSelect;
