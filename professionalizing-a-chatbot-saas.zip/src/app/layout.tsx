import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "نُوا — دستیار هوش مصنوعی فارسی",
  description:
    "چت‌بات دوزبانه (فارسی/انگلیسی) مبتنی بر GPT با ذخیره‌سازی امن و خصوصی مکالمات، رابط مدرن و امنیت سطح پروداکشن.",
  keywords: [
    "چت‌بات فارسی",
    "هوش مصنوعی",
    "دستیار هوشمند",
    "GPT فارسی",
    "نُوا",
    "Nova AI",
    "Persian AI chatbot",
  ],
  robots: { index: true, follow: true },
  openGraph: {
    title: "نُوا — دستیار هوش مصنوعی فارسی",
    description: "با دستیار هوشمند فارسی گفت‌وگو کنید — سریع، امن و دائمی.",
    locale: "fa_IR",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#07070d",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-[#07070d] font-sans text-slate-200 antialiased">
        {/* فونت وزیرمتن — React آن را به head منتقل می‌کند */}
        <link rel="preconnect" href="https://cdn.jsdelivr.net" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css"
        />
        {/* پس‌زمینه‌ی محیطی */}
        <div className="scene" aria-hidden>
          <div className="scene-orb scene-orb--a" />
          <div className="scene-orb scene-orb--b" />
          <div className="scene-orb scene-orb--c" />
          <div className="scene-grid" />
          <div className="scene-noise" />
        </div>
        {children}
      </body>
    </html>
  );
}
