import { AuthForm } from "@/components/account/AuthForm";

export const dynamic = "force-dynamic";

export default function Page() {
  return <AuthForm mode="register" />;
}
