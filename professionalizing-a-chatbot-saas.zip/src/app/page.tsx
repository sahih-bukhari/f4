import { ChatShell } from "@/components/chat/ChatShell";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <ChatShell />;
}
