import { PricingClient } from "@/components/account/PricingClient";

export const dynamic = "force-dynamic";

export default function Page() {
  return <PricingClient />;
}
