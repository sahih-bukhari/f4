import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { clientIp, isSameOrigin } from "@/lib/security";
import { rateLimit } from "@/lib/ratelimit";
import { resolveSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const idSchema = z.uuid();
const patchSchema = z.object({
  title: z.string().min(1).max(120),
});

/** بررسی مالکیت: مکالمه باید متعلق به جلسه‌ی فعلی باشد */
async function findOwned(req: Request, id: string) {
  if (!idSchema.safeParse(id).success) return { status: 400 as const };
  const { sessionId } = await resolveSession(req);
  if (!sessionId) return { status: 404 as const };
  const rows = await db
    .select({ id: conversations.id })
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.sessionId, sessionId)))
    .limit(1);
  if (!rows.length) return { status: 404 as const };
  return { status: 200 as const, sessionId };
}

async function mutationGuard(req: Request, bucketPrefix: string) {
  if (!isSameOrigin(req)) {
    return NextResponse.json({ error: "Bad request." }, { status: 403 });
  }
  const gate = await rateLimit(`${bucketPrefix}:${clientIp(req)}`, 40, 5 * 60 * 1000);
  if (!gate.ok) {
    return NextResponse.json(
      { error: "محدودیت تعداد درخواست.", code: "rate_limited" },
      { status: 429, headers: { "Retry-After": String(gate.retryAfterSec) } }
    );
  }
  return null;
}

export async function GET(req: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const own = await findOwned(req, id);
    if (own.status !== 200) {
      return NextResponse.json({ error: "گفت‌وگو یافت نشد." }, { status: own.status });
    }
    const rows = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(messages.createdAt);
    return NextResponse.json({ messages: rows });
  } catch (err) {
    console.error("conversation GET error:", err);
    return NextResponse.json({ error: "خطا در دریافت پیام‌ها" }, { status: 500 });
  }
}

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const blocked = await mutationGuard(req, "conv:patch");
    if (blocked) return blocked;

    const { id } = await ctx.params;
    const parsed = patchSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json({ error: "عنوان نامعتبر است" }, { status: 400 });
    }
    const own = await findOwned(req, id);
    if (own.status !== 200) {
      return NextResponse.json({ error: "گفت‌وگو یافت نشد" }, { status: own.status });
    }
    const [updated] = await db
      .update(conversations)
      .set({ title: parsed.data.title.trim(), updatedAt: new Date() })
      .where(eq(conversations.id, id))
      .returning();
    return NextResponse.json({ conversation: updated });
  } catch (err) {
    console.error("conversation PATCH error:", err);
    return NextResponse.json({ error: "خطا در ویرایش عنوان" }, { status: 500 });
  }
}

export async function DELETE(req: Request, ctx: Ctx) {
  try {
    const blocked = await mutationGuard(req, "conv:delete");
    if (blocked) return blocked;

    const { id } = await ctx.params;
    const own = await findOwned(req, id);
    if (own.status !== 200) {
      return NextResponse.json({ error: "گفت‌وگو یافت نشد" }, { status: own.status });
    }
    await db
      .delete(conversations)
      .where(and(eq(conversations.id, id), eq(conversations.sessionId, own.sessionId)));
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("conversation DELETE error:", err);
    return NextResponse.json({ error: "خطا در حذف مکالمه" }, { status: 500 });
  }
}
