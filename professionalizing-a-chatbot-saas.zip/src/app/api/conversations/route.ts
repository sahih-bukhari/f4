import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { conversations } from "@/db/schema";
import { resolveSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * فقط گفت‌وگوهای متعلق به جلسه‌ی ناشناس فعلی برمی‌گردد.
 * بدون کوکی جلسه → لیست خالی (حریم خصوصی در برابر بازدیدکنندگان دیگر).
 */
export async function GET(req: Request) {
  try {
    const { sessionId } = await resolveSession(req);
    if (!sessionId) return NextResponse.json({ conversations: [] });

    const rows = await db
      .select()
      .from(conversations)
      .where(eq(conversations.sessionId, sessionId))
      .orderBy(desc(conversations.updatedAt))
      .limit(100);
    return NextResponse.json({ conversations: rows });
  } catch (err) {
    console.error("conversations GET error:", err);
    return NextResponse.json({ error: "خطا در دریافت مکالمات" }, { status: 500 });
  }
}
