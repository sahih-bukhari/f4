import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { builds } from "@/db/schema";
import { resolveSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

/**
 * دریافت ساخت — فقط برای مالک جلسه.
 * بدون ?full=1 فقط متادیتا برمی‌گردد؛ با ?full=1 کد HTML هم می‌آید.
 */
export async function GET(req: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    if (!z.uuid().safeParse(id).success) {
      return NextResponse.json({ error: "شناسه نامعتبر است." }, { status: 400 });
    }
    const { sessionId } = await resolveSession(req);
    if (!sessionId) {
      return NextResponse.json({ error: "ساخت یافت نشد." }, { status: 404 });
    }
    const rows = await db
      .select()
      .from(builds)
      .where(and(eq(builds.id, id), eq(builds.sessionId, sessionId)))
      .limit(1);
    const b = rows[0];
    if (!b) {
      return NextResponse.json({ error: "ساخت یافت نشد." }, { status: 404 });
    }
    const full = new URL(req.url).searchParams.get("full") === "1";
    return NextResponse.json(
      {
        build: {
          id: b.id,
          title: b.title,
          createdAt: b.createdAt,
          fileCount: b.files?.length ?? 0,
          ...(full ? { html: b.html, files: b.files ?? [] } : {}),
        },
      },
      { headers: { "Cache-Control": "private, max-age=60" } }
    );
  } catch (err) {
    console.error("build GET error:", err);
    return NextResponse.json({ error: "خطا در دریافت ساخت" }, { status: 500 });
  }
}
