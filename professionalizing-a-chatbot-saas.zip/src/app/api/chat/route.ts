import { NextResponse } from "next/server";
import { z } from "zod";
import { and, count, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { conversations, messages, uploads } from "@/db/schema";
import { generateReply, type AiErrorCode } from "@/lib/ai";
import { buildAttachmentsContext } from "@/lib/files";
import { clientIp, isSameOrigin, sanitizeUserText } from "@/lib/security";
import { rateLimitAll } from "@/lib/ratelimit";
import { resolveSession } from "@/lib/auth";
import { consumeQuota, refundQuota } from "@/lib/quota";
import { buildSessionCookie, newSessionId } from "@/lib/session";

export const dynamic = "force-dynamic";

/** سقف‌های امنیتی */
const LIMITS = {
  perMinute: 5, // پیام در هر دقیقه
  per5Min: 15, // پیام در هر ۵ دقیقه
  perHour: 60, // پیام در هر ساعت
  maxMessagesPerConversation: 200,
  maxConversationsPerSession: 50,
  maxBodyBytes: 16 * 1024,
} as const;

const bodySchema = z.object({
  conversationId: z.uuid().optional(),
  message: z
    .string()
    .min(1, "پیام خالی است.")
    .max(2000, "پیام بیش از حد طولانی است (حداکثر ۲۰۰۰ نویسه)."),
  lang: z.enum(["fa", "en"]).catch("fa"),
  uploadIds: z.array(z.uuid()).max(5).optional(),
});

function deriveTitle(message: string, lang: "fa" | "en"): string {
  const clean = message.replace(/\s+/g, " ").trim();
  if (!clean) return lang === "fa" ? "گفت‌وگوی جدید" : "New chat";
  if (clean.length <= 42) return clean;
  const cut = clean.slice(0, 42);
  const lastSpace = cut.lastIndexOf(" ");
  return (lastSpace > 20 ? cut.slice(0, lastSpace) : cut) + "…";
}

function aiErrorToResponse(code: AiErrorCode) {
  switch (code) {
    case "missing_key":
      return NextResponse.json(
        { error: "سرویس هوش مصنوعی هنوز پیکربندی نشده است.", code: "missing_key" },
        { status: 503 }
      );
    case "timeout":
      return NextResponse.json(
        { error: "پاسخ مدل بیش از حد طول کشید؛ لطفاً دوباره تلاش کن.", code: "timeout" },
        { status: 504 }
      );
    case "rate_limited":
      return NextResponse.json(
        { error: "سرویس موقتاً شلوغ است؛ چند لحظه‌ی دیگر تلاش کن.", code: "upstream_busy" },
        { status: 503 }
      );
    default:
      return NextResponse.json(
        { error: "خطا در ارتباط با سرویس هوش مصنوعی.", code: "upstream_error" },
        { status: 502 }
      );
  }
}

export async function POST(req: Request) {
  try {
    // ۱) ضد CSRF: فقط درخواست‌های Same-Origin
    if (!isSameOrigin(req)) {
      return NextResponse.json({ error: "Bad request.", code: "bad_request" }, { status: 403 });
    }

    // ۲) فقط JSON با بدنه‌ی کوچک
    const contentType = req.headers.get("content-type") ?? "";
    if (!contentType.includes("application/json")) {
      return NextResponse.json(
        { error: "نوع محتوا نامعتبر است.", code: "bad_request" },
        { status: 415 }
      );
    }
    const contentLength = Number(req.headers.get("content-length") ?? "0");
    if (contentLength > LIMITS.maxBodyBytes) {
      return NextResponse.json(
        { error: "بدنه‌ی درخواست بیش از حد بزرگ است.", code: "bad_request" },
        { status: 413 }
      );
    }

    // ۳) ریت‌لیمیت چندلایه بر اساس IP
    const ip = clientIp(req);
    const blocked = await rateLimitAll([
      { key: `chat:1m:${ip}`, limit: LIMITS.perMinute, windowMs: 60 * 1000 },
      { key: `chat:5m:${ip}`, limit: LIMITS.per5Min, windowMs: 5 * 60 * 1000 },
      { key: `chat:1h:${ip}`, limit: LIMITS.perHour, windowMs: 60 * 60 * 1000 },
    ]);
    if (!blocked.ok) {
      return NextResponse.json(
        {
          error: `محدودیت ارسال — ${blocked.retryAfterSec} ثانیه دیگر تلاش کن.`,
          code: "rate_limited",
          retryAfterSec: blocked.retryAfterSec,
        },
        { status: 429, headers: { "Retry-After": String(blocked.retryAfterSec) } }
      );
    }

    // ۴) اعتبارسنجی دقیق ورودی
    const raw = await req.json().catch(() => null);
    const parsed = bodySchema.safeParse(raw);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? "ورودی نامعتبر است.", code: "bad_request" },
        { status: 400 }
      );
    }

    const content = sanitizeUserText(parsed.data.message);
    if (!content) {
      return NextResponse.json({ error: "پیام خالی است.", code: "bad_request" }, { status: 400 });
    }
    const lang = parsed.data.lang;

    // ۵) جلسه‌ی ناشناس: مالکیت مکالمه باید با جلسه‌ی فعلی یکی باشد
    const auth = await resolveSession(req);
    if (auth.user?.blocked) {
      return NextResponse.json(
        { error: "این حساب مسدود شده است.", code: "blocked" },
        { status: 403 }
      );
    }
    let sessionId = auth.sessionId;
    let freshCookie: string | null = null;
    let conversationId = parsed.data.conversationId ?? null;

    if (conversationId) {
      if (!sessionId) {
        // بدون جلسه، ادعای مالکیت غیرقابل اثبات است
        conversationId = null;
      } else {
        const owned = await db
          .select({ id: conversations.id })
          .from(conversations)
          .where(
            and(eq(conversations.id, conversationId), eq(conversations.sessionId, sessionId))
          )
          .limit(1);
        if (!owned.length) {
          return NextResponse.json(
            { error: "گفت‌وگو یافت نشد.", code: "not_found" },
            { status: 404 }
          );
        }
      }
    }

    // ۶) سقف پیام‌ها در مکالمه + سقف مکالمات در هر جلسه
    let priorTurns: { role: "user" | "assistant"; content: string }[] = [];
    if (conversationId) {
      const [{ total }] = await db
        .select({ total: count() })
        .from(messages)
        .where(eq(messages.conversationId, conversationId));
      if (total >= LIMITS.maxMessagesPerConversation) {
        return NextResponse.json(
          { error: "این گفت‌وگو پر شده است — یک گفت‌وگوی جدید بساز.", code: "conversation_full" },
          { status: 400 }
        );
      }
      const rows = await db
        .select({ role: messages.role, content: messages.content })
        .from(messages)
        .where(eq(messages.conversationId, conversationId))
        .orderBy(desc(messages.createdAt), desc(messages.id))
        .limit(12);
      priorTurns = rows.reverse();
    } else if (sessionId) {
      const [{ total }] = await db
        .select({ total: count() })
        .from(conversations)
        .where(eq(conversations.sessionId, sessionId));
      if (total >= LIMITS.maxConversationsPerSession) {
        return NextResponse.json(
          { error: "به سقف تعداد گفت‌وگوها رسیدی — یکی را حذف کن.", code: "quota_full" },
          { status: 400 }
        );
      }
    }

    // ۷) پیوست‌ها: فقط فایل‌های متعلق به همین جلسه قابل استفاده‌اند
    let attachMeta: { name: string; sizeBytes: number }[] = [];
    let attachBlock = "";
    if (parsed.data.uploadIds?.length && sessionId) {
      const attRows = await db
        .select({ name: uploads.name, extract: uploads.extract, sizeBytes: uploads.sizeBytes })
        .from(uploads)
        .where(and(inArray(uploads.id, parsed.data.uploadIds), eq(uploads.sessionId, sessionId)));
      attachMeta = attRows.map((r) => ({ name: r.name, sizeBytes: r.sizeBytes }));
      attachBlock = buildAttachmentsContext(attRows, lang);
    }

    // ۷.۵) سهمیه‌ی روزانه‌ی پلن (مهمان / رایگان / حرفه‌ای)
    const quotaKey = sessionId ?? `ip:${ip}`;
    const quota = await consumeQuota(quotaKey, "chat", auth.tier);
    if (!quota.ok) {
      return NextResponse.json(
        {
          error:
            auth.tier === "pro"
              ? "سهمیه‌ی امروز تمام شد؛ فردا دوباره امتحان کن."
              : "سهمیه‌ی روزانه‌ات تمام شد — برای سقف بالاتر وارد شو یا پلن حرفه‌ای بگیر.",
          code: "daily_quota",
          tier: auth.tier,
          limit: quota.limit,
        },
        { status: 429 }
      );
    }

    // ۸) تولید پاسخ از API — پیش از هرگونه نوشتن در دیتابیس
    const modelInput = attachBlock ? `${content}\n\n${attachBlock}` : content;
    const reply = await generateReply([...priorTurns, { role: "user", content: modelInput }], lang);
    if (!reply.ok) {
      await refundQuota(quotaKey, "chat").catch(() => undefined);
      return aiErrorToResponse(reply.code);
    }

    // ۹) جلسه‌ی جدید اگر لازم باشد
    if (!sessionId) {
      sessionId = newSessionId();
      freshCookie = buildSessionCookie(sessionId);
    }

    // متن ذخیره‌شده‌ی پیام کاربر شامل نشانگر پیوست‌ها
    const storedContent = attachMeta.length
      ? `${content}\n\n\`\`\`attachments\n${JSON.stringify(attachMeta)}\n\`\`\``
      : content;

    // ۱۰) ذخیره‌سازی اتمیک: مکالمه (در صورت نیاز) + هر دو پیام — مالک = جلسه‌ی فعلی
    const sid = sessionId;
    const title = conversationId ? null : deriveTitle(content, lang);
    const result = await db.transaction(async (tx) => {
      let convId = conversationId;
      if (!convId) {
        const [created] = await tx
          .insert(conversations)
          .values({ title: title ?? "گفت‌وگوی جدید", sessionId: sid })
          .returning({ id: conversations.id });
        convId = created.id;
      }
      const [userMessage] = await tx
        .insert(messages)
        .values({ conversationId: convId, role: "user", content: storedContent })
        .returning();
      const [assistantMessage] = await tx
        .insert(messages)
        .values({ conversationId: convId, role: "assistant", content: reply.content })
        .returning();
      await tx
        .update(conversations)
        .set({ updatedAt: new Date() })
        .where(eq(conversations.id, convId));
      return { convId, userMessage, assistantMessage };
    });

    const res = NextResponse.json({
      conversationId: result.convId,
      title,
      userMessage: result.userMessage,
      assistantMessage: result.assistantMessage,
    });
    if (freshCookie) res.headers.append("Set-Cookie", freshCookie);
    return res;
  } catch (err) {
    console.error("chat error:", err);
    return NextResponse.json(
      { error: "مشکلی در پردازش پیام پیش آمد.", code: "server_error" },
      { status: 500 }
    );
  }
}
