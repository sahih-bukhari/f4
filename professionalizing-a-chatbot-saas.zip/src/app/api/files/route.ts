import { NextResponse } from "next/server";
import { count, eq } from "drizzle-orm";
import { db } from "@/db";
import { uploads } from "@/db/schema";
import { processUpload, UPLOAD_RULES } from "@/lib/files";
import { clientIp, isSameOrigin } from "@/lib/security";
import { rateLimitAll } from "@/lib/ratelimit";
import { resolveSession } from "@/lib/auth";
import { buildSessionCookie, newSessionId } from "@/lib/session";

export const dynamic = "force-dynamic";

const ERRORS_FA: Record<string, string> = {
  file_too_large: "فایل بزرگ‌تر از ۵ مگابایت است.",
  bad_zip: "فایل ZIP معتبر نیست.",
  zip_too_many: "تعداد فایل‌های داخل ZIP بیش از حد است.",
  zip_no_text: "در ZIP فایل متنی قابل خواندنی پیدا نشد.",
  bad_type: "نوع فایل پشتیبانی نمی‌شود.",
  binary: "فایل باینری قابل پذیرش نیست.",
  empty: "فایل خالی است.",
};

export async function POST(req: Request) {
  try {
    if (!isSameOrigin(req)) {
      return NextResponse.json({ error: "Bad request." }, { status: 403 });
    }
    const ct = req.headers.get("content-type") ?? "";
    if (!ct.includes("multipart/form-data")) {
      return NextResponse.json({ error: "نوع محتوا نامعتبر است." }, { status: 415 });
    }
    if (Number(req.headers.get("content-length") ?? "0") > 18 * 1024 * 1024) {
      return NextResponse.json({ error: "حجم درخواست بیش از حد است." }, { status: 413 });
    }

    const ip = clientIp(req);
    const gate = await rateLimitAll([
      { key: `upload:5m:${ip}`, limit: 10, windowMs: 5 * 60 * 1000 },
      { key: `upload:1h:${ip}`, limit: 40, windowMs: 60 * 60 * 1000 },
    ]);
    if (!gate.ok) {
      const retry = gate.retryAfterSec;
      return NextResponse.json(
        { error: "محدودیت آپلود.", code: "rate_limited", retryAfterSec: retry },
        { status: 429, headers: { "Retry-After": String(retry) } }
      );
    }

    let form: FormData;
    try {
      form = await req.formData();
    } catch {
      return NextResponse.json({ error: "فرم نامعتبر است." }, { status: 400 });
    }

    const files = form.getAll("files").filter((f): f is File => f instanceof File);
    if (!files.length || files.length > UPLOAD_RULES.maxFilesPerRequest) {
      return NextResponse.json(
        { error: `حداکثر ${UPLOAD_RULES.maxFilesPerRequest} فایل در هر بار.` },
        { status: 400 }
      );
    }

    // جلسه‌ی ناشناس: ایجاد یا استفاده از موجود
    const auth = await resolveSession(req);
    if (auth.user?.blocked) {
      return NextResponse.json({ error: "این حساب مسدود شده است.", code: "blocked" }, { status: 403 });
    }
    const hadSession = Boolean(auth.sessionId);
    const sessionId = auth.sessionId ?? newSessionId();

    // سقف آپلودها در هر جلسه
    const [{ total }] = await db
      .select({ total: count() })
      .from(uploads)
      .where(eq(uploads.sessionId, sessionId));
    if (total >= 60) {
      return NextResponse.json({ error: "به سقف فایل‌ها رسیدی." }, { status: 400 });
    }

    const saved: { id: string; name: string; sizeBytes: number }[] = [];
    const failed: { name: string; reason: string }[] = [];

    for (const file of files) {
      const buf = new Uint8Array(await file.arrayBuffer());
      const result = processUpload(buf, file.name);
      if ("error" in result) {
        failed.push({ name: file.name, reason: ERRORS_FA[result.error] ?? "نامعتبر" });
        continue;
      }
      for (const ex of result) {
        if (total + saved.length >= 60) break;
        const [row] = await db
          .insert(uploads)
          .values({
            sessionId,
            name: ex.name,
            ext: ex.ext,
            sizeBytes: ex.sizeBytes,
            extract: ex.extract,
          })
          .returning({ id: uploads.id });
        saved.push({ id: row.id, name: ex.name, sizeBytes: ex.sizeBytes });
      }
    }

    if (!saved.length) {
      return NextResponse.json(
        { error: failed[0]?.reason ?? "هیچ فایلی پذیرفته نشد.", failed },
        { status: 400 }
      );
    }

    const res = NextResponse.json({ uploads: saved, failed });
    if (!hadSession) res.headers.append("Set-Cookie", buildSessionCookie(sessionId));
    return res;
  } catch (err) {
    console.error("upload error:", err);
    return NextResponse.json({ error: "خطا در آپلود فایل." }, { status: 500 });
  }
}
