import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { jsonError } from "@/lib/http";

export const dynamic = "force-dynamic";

/** تاریخچه‌ی پرداخت‌های خود کاربر */
export async function GET(req: Request) {
  const user = await getCurrentUser(req);
  if (!user) return jsonError("ابتدا وارد حساب شو.", "unauthorized", 401);
  const rows = await db
    .select({
      id: payments.id,
      provider: payments.provider,
      status: payments.status,
      amountCents: payments.amountCents,
      currency: payments.currency,
      months: payments.months,
      externalId: payments.externalId,
      createdAt: payments.createdAt,
    })
    .from(payments)
    .where(eq(payments.userId, user.id))
    .orderBy(desc(payments.createdAt))
    .limit(20);
  return NextResponse.json({ payments: rows }, { headers: { "Cache-Control": "no-store" } });
}
