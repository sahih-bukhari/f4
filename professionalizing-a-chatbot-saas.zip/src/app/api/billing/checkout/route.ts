import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { guardJson, jsonError, limitByIp } from "@/lib/http";
import { appBaseUrl } from "@/lib/mail";
import { ALLOWED_MONTHS, getProvider, monthlyPriceCents, priceCurrency } from "@/lib/payments";

export const dynamic = "force-dynamic";

const schema = z.object({
  provider: z.string().max(20),
  months: z.number().int().refine((m) => (ALLOWED_MONTHS as readonly number[]).includes(m)),
});

export async function POST(req: Request) {
  try {
    const bad = guardJson(req);
    if (bad) return bad;
    const limited = await limitByIp(req, "checkout", [{ limit: 10, windowMs: 60 * 60 * 1000 }]);
    if (limited) return limited;

    const user = await getCurrentUser(req);
    if (!user || user.blocked) return jsonError("ابتدا وارد حساب شو.", "unauthorized", 401);

    const parsed = schema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return jsonError("ورودی نامعتبر است.", "bad_request", 400);
    const provider = getProvider(parsed.data.provider);
    if (!provider) return jsonError("این روش پرداخت فعال نیست.", "provider_unavailable", 400);

    const amountCents = monthlyPriceCents() * parsed.data.months;
    const currency = priceCurrency();

    const [pay] = await db
      .insert(payments)
      .values({
        userId: user.id,
        provider: provider.id,
        amountCents,
        currency,
        months: parsed.data.months,
      })
      .returning();

    try {
      const out = await provider.createCheckout({
        user,
        paymentId: pay.id,
        months: parsed.data.months,
        amountCents,
        currency,
        baseUrl: appBaseUrl(req),
      });
      await db.update(payments).set({ externalId: out.externalId }).where(eq(payments.id, pay.id));
      return NextResponse.json({
        paymentId: pay.id,
        redirectUrl: out.redirectUrl ?? null,
        instructions: out.instructions ?? null,
        reference: out.externalId,
      });
    } catch (err) {
      console.error("checkout provider error:", err);
      await db.update(payments).set({ status: "canceled" }).where(eq(payments.id, pay.id));
      return jsonError("ساخت پرداخت ناموفق بود.", "provider_error", 502);
    }
  } catch (err) {
    console.error("checkout error:", err);
    return jsonError("مشکلی پیش آمد.", "server_error", 500);
  }
}
