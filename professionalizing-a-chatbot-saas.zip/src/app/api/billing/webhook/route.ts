import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { markPaid } from "@/lib/payments";
import { verifyStripeSignature } from "@/lib/payments/stripe";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** webhook استریپ — بدنه‌ی خام برای بررسی امضا لازم است */
export async function POST(req: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) return NextResponse.json({ error: "not_configured" }, { status: 503 });

  const raw = await req.text();
  if (!verifyStripeSignature(raw, req.headers.get("stripe-signature"), secret)) {
    return NextResponse.json({ error: "bad_signature" }, { status: 400 });
  }

  try {
    const event = JSON.parse(raw) as {
      type?: string;
      data?: { object?: { id?: string; payment_status?: string; metadata?: Record<string, string> } };
    };
    if (event.type === "checkout.session.completed" || event.type === "checkout.session.async_payment_succeeded") {
      const obj = event.data?.object;
      if (obj?.payment_status === "paid" && obj.id) {
        const rows = await db
          .select({ id: payments.id })
          .from(payments)
          .where(and(eq(payments.externalId, obj.id), eq(payments.provider, "stripe")))
          .limit(1);
        if (rows[0]) await markPaid(rows[0].id);
      }
    }
    return NextResponse.json({ received: true });
  } catch (err) {
    console.error("stripe webhook error:", err);
    return NextResponse.json({ error: "server_error" }, { status: 500 });
  }
}
