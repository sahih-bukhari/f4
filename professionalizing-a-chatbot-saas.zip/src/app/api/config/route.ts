import { NextResponse } from "next/server";
import { isConfigured, publicModelName } from "@/lib/ai";

export const dynamic = "force-dynamic";

/**
 * وضعیت عمومی سرویس برای نمایش در UI.
 * هیچ مقدار محرمانه‌ای فاش نمی‌کند — فقط «پیکربندی شده/نشده» و نام مدل.
 */
export async function GET() {
  return NextResponse.json(
    {
      configured: isConfigured(),
      model: publicModelName(),
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}
