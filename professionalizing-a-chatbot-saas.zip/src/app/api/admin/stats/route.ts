import { NextResponse } from "next/server";
import { and, count, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { payments, usage, users } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { jsonError } from "@/lib/http";
import { todayKey } from "@/lib/quota";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const admin = await requireAdmin(req);
  if (!admin) return jsonError("دسترسی ندارید.", "forbidden", 403);

  const [{ total }] = await db.select({ total: count() }).from(users);
  const [{ pro }] = await db
    .select({ pro: count() })
    .from(users)
    .where(and(eq(users.plan, "pro"), gt(users.planExpiresAt, new Date())));
  const [{ pending }] = await db
    .select({ pending: count() })
    .from(payments)
    .where(eq(payments.status, "pending"));
  const revenue = await db
    .select({ currency: payments.currency, cents: sql<number>`coalesce(sum(${payments.amountCents}), 0)::int` })
    .from(payments)
    .where(eq(payments.status, "paid"))
    .groupBy(payments.currency);
  const today = await db
    .select({ kind: usage.kind, total: sql<number>`coalesce(sum(${usage.count}), 0)::int` })
    .from(usage)
    .where(eq(usage.day, todayKey()))
    .groupBy(usage.kind);

  return NextResponse.json(
    {
      users: total,
      proUsers: pro,
      pendingPayments: pending,
      revenue,
      today: {
        chat: today.find((r) => r.kind === "chat")?.total ?? 0,
        build: today.find((r) => r.kind === "build")?.total ?? 0,
      },
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}
