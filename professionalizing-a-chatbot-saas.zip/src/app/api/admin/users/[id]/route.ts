import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { authSessions, users } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { guardJson, jsonError } from "@/lib/http";
import { extendExpiry } from "@/lib/payments";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const schema = z
  .object({
    blocked: z.boolean().optional(),
    role: z.enum(["user", "admin"]).optional(),
    plan: z.enum(["free", "pro"]).optional(),
    /** تمدید دستی پلن حرفه‌ای (روز) */
    extendDays: z.number().int().min(1).max(3650).optional(),
  })
  .refine((o) => Object.keys(o).length > 0);

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const bad = guardJson(req);
    if (bad) return bad;
    const admin = await requireAdmin(req);
    if (!admin) return jsonError("دسترسی ندارید.", "forbidden", 403);

    const { id } = await ctx.params;
    if (!z.uuid().safeParse(id).success) return jsonError("شناسه نامعتبر است.", "bad_request", 400);
    const parsed = schema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return jsonError("ورودی نامعتبر است.", "bad_request", 400);
    const body = parsed.data;

    // ادمین نمی‌تواند خودش را مسدود یا تنزیل کند (جلوگیری از قفل‌شدن پنل)
    if (id === admin.id && (body.blocked === true || body.role === "user")) {
      return jsonError("نمی‌توانی خودت را مسدود یا تنزیل بدهی.", "self_change", 400);
    }

    const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
    const target = rows[0];
    if (!target) return jsonError("کاربر یافت نشد.", "not_found", 404);

    const patch: Partial<typeof users.$inferInsert> = {};
    if (body.blocked !== undefined) patch.blocked = body.blocked;
    if (body.role) patch.role = body.role;
    if (body.plan === "free") {
      patch.plan = "free";
      patch.planExpiresAt = null;
    }
    if (body.plan === "pro" && !body.extendDays) {
      patch.plan = "pro";
      patch.planExpiresAt = extendExpiry(target.plan === "pro" ? target.planExpiresAt : null, 30);
    }
    if (body.extendDays) {
      patch.plan = "pro";
      patch.planExpiresAt = extendExpiry(target.plan === "pro" ? target.planExpiresAt : null, body.extendDays);
    }

    const [updated] = await db.update(users).set(patch).where(eq(users.id, id)).returning();
    if (body.blocked === true) {
      await db.delete(authSessions).where(eq(authSessions.userId, id));
    }
    return NextResponse.json({
      user: {
        id: updated.id,
        email: updated.email,
        role: updated.role,
        plan: updated.plan,
        planExpiresAt: updated.planExpiresAt,
        blocked: updated.blocked,
      },
    });
  } catch (err) {
    console.error("admin user patch error:", err);
    return jsonError("مشکلی پیش آمد.", "server_error", 500);
  }
}
