import { NextResponse } from "next/server";
import { desc, ilike, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { jsonError } from "@/lib/http";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 30;

export async function GET(req: Request) {
  const admin = await requireAdmin(req);
  if (!admin) return jsonError("دسترسی ندارید.", "forbidden", 403);

  const url = new URL(req.url);
  const page = Math.max(1, Math.min(1000, Number(url.searchParams.get("page") ?? "1") || 1));
  const q = (url.searchParams.get("q") ?? "").trim().slice(0, 100).replace(/[%_\\]/g, "");

  const rows = await db
    .select({
      id: users.id,
      email: users.email,
      role: users.role,
      plan: users.plan,
      planExpiresAt: users.planExpiresAt,
      blocked: users.blocked,
      createdAt: users.createdAt,
      conversations: sql<number>`(select count(*)::int from conversations c where c.session_id = ${users.sessionId})`,
      builds: sql<number>`(select count(*)::int from builds b where b.session_id = ${users.sessionId})`,
    })
    .from(users)
    .where(q ? ilike(users.email, `%${q}%`) : undefined)
    .orderBy(desc(users.createdAt))
    .limit(PAGE_SIZE + 1)
    .offset((page - 1) * PAGE_SIZE);

  return NextResponse.json(
    { users: rows.slice(0, PAGE_SIZE), hasMore: rows.length > PAGE_SIZE, page },
    { headers: { "Cache-Control": "no-store" } }
  );
}
