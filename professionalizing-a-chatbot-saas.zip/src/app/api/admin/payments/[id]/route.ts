import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { guardJson, jsonError } from "@/lib/http";
import { markPaid } from "@/lib/payments";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({ action: z.enum(["approve", "reject"]) });

export async function POST(req: Request, ctx: Ctx) {
  try {
    const bad = guardJson(req);
    if (bad) return bad;
    const admin = await requireAdmin(req);
    if (!admin) return jsonError("دسترسی ندارید.", "forbidden", 403);

    const { id } = await ctx.params;
    if (!z.uuid().safeParse(id).success) return jsonError("شناسه نامعتبر است.", "bad_request", 400);
    const parsed = schema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return jsonError("ورودی نامعتبر است.", "bad_request", 400);

    if (parsed.data.action === "approve") {
      const done = await markPaid(id);
      if (!done) return jsonError("این پرداخت دیگر در انتظار نیست.", "not_pending", 409);
    } else {
      const res = await db
        .update(payments)
        .set({ status: "rejected" })
        .where(and(eq(payments.id, id), eq(payments.status, "pending")))
        .returning({ id: payments.id });
      if (!res.length) return jsonError("این پرداخت دیگر در انتظار نیست.", "not_pending", 409);
    }
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("admin payment error:", err);
    return jsonError("مشکلی پیش آمد.", "server_error", 500);
  }
}
