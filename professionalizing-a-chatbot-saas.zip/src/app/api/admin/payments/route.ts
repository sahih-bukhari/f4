import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { payments, users } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { jsonError } from "@/lib/http";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const admin = await requireAdmin(req);
  if (!admin) return jsonError("دسترسی ندارید.", "forbidden", 403);

  const status = new URL(req.url).searchParams.get("status");
  const valid = status === "pending" || status === "paid" || status === "rejected" || status === "canceled";

  const rows = await db
    .select({
      id: payments.id,
      email: users.email,
      provider: payments.provider,
      status: payments.status,
      amountCents: payments.amountCents,
      currency: payments.currency,
      months: payments.months,
      externalId: payments.externalId,
      createdAt: payments.createdAt,
    })
    .from(payments)
    .innerJoin(users, eq(users.id, payments.userId))
    .where(valid ? eq(payments.status, status) : undefined)
    .orderBy(desc(payments.createdAt))
    .limit(100);

  return NextResponse.json({ payments: rows }, { headers: { "Cache-Control": "no-store" } });
}
