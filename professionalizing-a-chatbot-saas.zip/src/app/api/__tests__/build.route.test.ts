import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/db", () => ({ db: {} }));
vi.mock("@/lib/auth", () => ({ resolveSession: vi.fn() }));
vi.mock("@/lib/quota", () => ({ consumeQuota: vi.fn(), refundQuota: vi.fn() }));
vi.mock("@/lib/ratelimit", () => ({ rateLimitAll: vi.fn() }));

import { POST } from "@/app/api/build/route";
import { resolveSession } from "@/lib/auth";
import { consumeQuota } from "@/lib/quota";
import { rateLimitAll } from "@/lib/ratelimit";

const mkReq = (body: unknown, headers: Record<string, string> = {}) =>
  new Request("https://x.test/api/build", {
    method: "POST",
    headers: { "content-type": "application/json", host: "x.test", ...headers },
    body: typeof body === "string" ? body : JSON.stringify(body),
  });

beforeEach(() => {
  vi.mocked(rateLimitAll).mockResolvedValue({ ok: true, retryAfterSec: 0 });
  vi.mocked(resolveSession).mockResolvedValue({ user: null, sessionId: null, tier: "guest" });
  vi.mocked(consumeQuota).mockResolvedValue({ ok: true, used: 1, limit: 1 });
});

describe("POST /api/build", () => {
  it("Origin بیگانه → 403", async () => {
    const res = await POST(mkReq({ message: "یک لندینگ کافی‌شاپ" }, { origin: "https://evil.test" }));
    expect(res.status).toBe(403);
  });

  it("غیر JSON → 415", async () => {
    const res = await POST(mkReq("x", { "content-type": "text/plain" }));
    expect(res.status).toBe(415);
  });

  it("پیام کوتاه‌تر از ۴ نویسه → 400", async () => {
    const res = await POST(mkReq({ message: "ab" }));
    expect(res.status).toBe(400);
  });

  it("محدودیت درخواست → 429", async () => {
    vi.mocked(rateLimitAll).mockResolvedValue({ ok: false, retryAfterSec: 30 });
    const res = await POST(mkReq({ message: "یک لندینگ کافی‌شاپ" }));
    expect(res.status).toBe(429);
  });

  it("سقف روزانه‌ی ساخت تمام → 429 daily_quota", async () => {
    vi.mocked(consumeQuota).mockResolvedValue({ ok: false, used: 1, limit: 1 });
    const res = await POST(mkReq({ message: "یک لندینگ کافی‌شاپ" }));
    expect(res.status).toBe(429);
    expect((await res.json()).code).toBe("daily_quota");
  });
});
