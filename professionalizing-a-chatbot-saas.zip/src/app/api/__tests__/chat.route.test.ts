import { beforeEach, describe, expect, it, vi } from "vitest";

// دیتابیس و سرویس‌های بیرونی شبیه‌سازی می‌شوند؛ فقط مسیرهای پیش از نوشتن در دیتابیس تست می‌شوند
vi.mock("@/db", () => ({ db: {} }));
vi.mock("@/lib/ai", () => ({ generateReply: vi.fn() }));
vi.mock("@/lib/auth", () => ({ resolveSession: vi.fn() }));
vi.mock("@/lib/quota", () => ({ consumeQuota: vi.fn(), refundQuota: vi.fn() }));
vi.mock("@/lib/ratelimit", () => ({ rateLimitAll: vi.fn() }));

import { POST } from "@/app/api/chat/route";
import { resolveSession } from "@/lib/auth";
import { consumeQuota } from "@/lib/quota";
import { rateLimitAll } from "@/lib/ratelimit";

const mkReq = (body: unknown, headers: Record<string, string> = {}) =>
  new Request("https://x.test/api/chat", {
    method: "POST",
    headers: { "content-type": "application/json", host: "x.test", ...headers },
    body: typeof body === "string" ? body : JSON.stringify(body),
  });

beforeEach(() => {
  vi.mocked(rateLimitAll).mockResolvedValue({ ok: true, retryAfterSec: 0 });
  vi.mocked(resolveSession).mockResolvedValue({ user: null, sessionId: null, tier: "guest" });
  vi.mocked(consumeQuota).mockResolvedValue({ ok: true, used: 1, limit: 10 });
});

describe("POST /api/chat", () => {
  it("Origin بیگانه → 403", async () => {
    const res = await POST(mkReq({ message: "سلام" }, { origin: "https://evil.test" }));
    expect(res.status).toBe(403);
  });

  it("غیر JSON → 415", async () => {
    const res = await POST(mkReq("x", { "content-type": "text/plain" }));
    expect(res.status).toBe(415);
  });

  it("پیام خالی → 400", async () => {
    const res = await POST(mkReq({ message: "" }));
    expect(res.status).toBe(400);
  });

  it("محدودیت درخواست → 429 با Retry-After", async () => {
    vi.mocked(rateLimitAll).mockResolvedValue({ ok: false, retryAfterSec: 12 });
    const res = await POST(mkReq({ message: "سلام" }));
    expect(res.status).toBe(429);
    expect(res.headers.get("Retry-After")).toBe("12");
  });

  it("حساب مسدود → 403 blocked", async () => {
    vi.mocked(resolveSession).mockResolvedValue({
      user: { blocked: true } as never,
      sessionId: "s",
      tier: "free",
    });
    const res = await POST(mkReq({ message: "سلام" }));
    expect(res.status).toBe(403);
    expect((await res.json()).code).toBe("blocked");
  });

  it("سقف روزانه تمام → 429 daily_quota", async () => {
    vi.mocked(consumeQuota).mockResolvedValue({ ok: false, used: 10, limit: 10 });
    const res = await POST(mkReq({ message: "سلام" }));
    expect(res.status).toBe(429);
    expect((await res.json()).code).toBe("daily_quota");
  });
});
