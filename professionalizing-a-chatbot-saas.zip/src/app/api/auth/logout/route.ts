import { NextResponse } from "next/server";
import { clearAuthCookie, destroyAuthSession, getAuthToken } from "@/lib/auth";
import { isSameOrigin } from "@/lib/security";
import { buildSessionCookie, newSessionId } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  if (!isSameOrigin(req)) return NextResponse.json({ error: "Bad request." }, { status: 403 });
  const token = getAuthToken(req);
  if (token) await destroyAuthSession(token).catch(() => undefined);
  const res = NextResponse.json({ ok: true });
  res.headers.append("Set-Cookie", clearAuthCookie());
  // بعد از خروج یک جلسه‌ی مهمان تازه می‌گیرد تا داده‌های حساب دیده نشود
  res.headers.append("Set-Cookie", buildSessionCookie(newSessionId()));
  return res;
}
