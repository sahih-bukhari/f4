import { NextResponse } from "next/server";
import { and, eq, gt, isNull } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { authSessions, passwordResets, users } from "@/db/schema";
import { guardJson, jsonError, limitByIp } from "@/lib/http";
import { hashPassword, sha256, validatePassword } from "@/lib/password";

export const dynamic = "force-dynamic";

const schema = z.object({
  token: z.string().regex(/^[0-9a-f]{64}$/),
  password: z.string().max(128),
});

export async function POST(req: Request) {
  try {
    const bad = guardJson(req);
    if (bad) return bad;
    const limited = await limitByIp(req, "reset", [{ limit: 10, windowMs: 60 * 60 * 1000 }]);
    if (limited) return limited;

    const parsed = schema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return jsonError("لینک نامعتبر است.", "bad_request", 400);
    if (!validatePassword(parsed.data.password)) {
      return jsonError("رمز عبور باید حداقل ۸ نویسه باشد.", "weak_password", 400);
    }

    const tokenHash = sha256(parsed.data.token);
    const rows = await db
      .select()
      .from(passwordResets)
      .where(
        and(
          eq(passwordResets.tokenHash, tokenHash),
          isNull(passwordResets.usedAt),
          gt(passwordResets.expiresAt, new Date())
        )
      )
      .limit(1);
    const reset = rows[0];
    if (!reset) return jsonError("لینک منقضی یا استفاده‌شده است.", "invalid_token", 400);

    const passwordHash = await hashPassword(parsed.data.password);
    await db.transaction(async (tx) => {
      await tx.update(users).set({ passwordHash }).where(eq(users.id, reset.userId));
      await tx.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.tokenHash, tokenHash));
      // همه‌ی نشست‌های قبلی بسته می‌شوند
      await tx.delete(authSessions).where(eq(authSessions.userId, reset.userId));
    });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("reset error:", err);
    return jsonError("مشکلی پیش آمد.", "server_error", 500);
  }
}
