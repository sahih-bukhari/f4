import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { buildAuthCookie, createAuthSession, pickSessionIdForNewUser, tierOf } from "@/lib/auth";
import { guardJson, jsonError, limitByIp, publicUser } from "@/lib/http";
import { hashPassword, normalizeEmail, validatePassword } from "@/lib/password";
import { buildSessionCookie } from "@/lib/session";

export const dynamic = "force-dynamic";

const schema = z.object({
  email: z.string().trim().max(254).pipe(z.email()),
  password: z.string().max(128),
});

export async function POST(req: Request) {
  try {
    const bad = guardJson(req);
    if (bad) return bad;
    const limited = await limitByIp(req, "register", [
      { limit: 5, windowMs: 60 * 60 * 1000 },
      { limit: 20, windowMs: 24 * 60 * 60 * 1000 },
    ]);
    if (limited) return limited;

    const parsed = schema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return jsonError("ایمیل یا رمز نامعتبر است.", "bad_request", 400);
    if (!validatePassword(parsed.data.password)) {
      return jsonError("رمز عبور باید حداقل ۸ نویسه باشد.", "weak_password", 400);
    }

    const email = normalizeEmail(parsed.data.email);
    const passwordHash = await hashPassword(parsed.data.password);
    const sessionId = await pickSessionIdForNewUser(req);

    // کاربری که با ایمیل ADMIN_EMAIL ثبت‌نام کند ادمین می‌شود
    const adminEmail = process.env.ADMIN_EMAIL ? normalizeEmail(process.env.ADMIN_EMAIL) : null;
    const role = adminEmail && adminEmail === email ? "admin" : "user";

    const inserted = await db
      .insert(users)
      .values({ email, passwordHash, sessionId, role })
      .onConflictDoNothing({ target: users.email })
      .returning();
    if (!inserted.length) return jsonError("این ایمیل قبلاً ثبت شده است.", "email_taken", 409);

    const user = inserted[0];
    const token = await createAuthSession(user.id);
    const res = NextResponse.json({ user: publicUser(user, tierOf(user)) }, { status: 201 });
    res.headers.append("Set-Cookie", buildAuthCookie(token));
    res.headers.append("Set-Cookie", buildSessionCookie(user.sessionId));
    return res;
  } catch (err) {
    console.error("register error:", err);
    return jsonError("مشکلی در ثبت‌نام پیش آمد.", "server_error", 500);
  }
}
