import { NextResponse } from "next/server";
import { getCurrentUser, tierOf } from "@/lib/auth";
import { publicUser } from "@/lib/http";
import { DAILY_LIMITS } from "@/lib/limits";
import { ALLOWED_MONTHS, availableProviders, monthlyPriceCents, priceCurrency } from "@/lib/payments";
import { getUsage } from "@/lib/quota";
import { clientIp } from "@/lib/security";
import { getSessionId } from "@/lib/session";

export const dynamic = "force-dynamic";

/** وضعیت ورود، پلن و مصرف امروز — برای نمایش در UI */
export async function GET(req: Request) {
  const user = await getCurrentUser(req);
  const tier = tierOf(user);
  const key = user ? user.sessionId : (getSessionId(req) ?? `ip:${clientIp(req)}`);
  const used = await getUsage(key).catch(() => ({ chat: 0, build: 0 }));
  return NextResponse.json(
    {
      user: user ? publicUser(user, tier) : null,
      tier,
      limits: DAILY_LIMITS[tier],
      used,
      paymentProviders: availableProviders(),
      price: { monthlyCents: monthlyPriceCents(), currency: priceCurrency(), months: ALLOWED_MONTHS },
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}
