import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { buildAuthCookie, createAuthSession, mergeGuestData, tierOf } from "@/lib/auth";
import { guardJson, jsonError, limitByIp, publicUser } from "@/lib/http";
import { normalizeEmail, verifyPassword } from "@/lib/password";
import { rateLimit } from "@/lib/ratelimit";
import { buildSessionCookie, getSessionId } from "@/lib/session";

export const dynamic = "force-dynamic";

const schema = z.object({
  email: z.string().trim().max(254),
  password: z.string().max(128),
});

// هش ساختگی برای یکسان‌سازی زمان پاسخ وقتی ایمیل وجود ندارد
const DUMMY_HASH = "scrypt$16384$8$1$00000000000000000000000000000000$" + "00".repeat(64);

export async function POST(req: Request) {
  try {
    const bad = guardJson(req);
    if (bad) return bad;
    const limited = await limitByIp(req, "login", [
      { limit: 10, windowMs: 15 * 60 * 1000 },
      { limit: 60, windowMs: 24 * 60 * 60 * 1000 },
    ]);
    if (limited) return limited;

    const parsed = schema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return jsonError("ایمیل یا رمز نامعتبر است.", "bad_request", 400);
    const email = normalizeEmail(parsed.data.email);

    // سقف تلاش برای هر ایمیل (ضد حدس رمز)
    const perEmail = await rateLimit(`login-email:${email}`, 8, 15 * 60 * 1000);
    if (!perEmail.ok) {
      return jsonError(
        `تلاش بیش از حد — ${perEmail.retryAfterSec} ثانیه دیگر دوباره امتحان کن.`,
        "rate_limited",
        429,
        { "Retry-After": String(perEmail.retryAfterSec) }
      );
    }

    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const user = rows[0];
    const ok = await verifyPassword(parsed.data.password, user?.passwordHash ?? DUMMY_HASH);
    if (!user || !ok) return jsonError("ایمیل یا رمز اشتباه است.", "invalid_credentials", 401);
    if (user.blocked) return jsonError("این حساب مسدود شده است.", "blocked", 403);

    await mergeGuestData(getSessionId(req), user.sessionId);
    const token = await createAuthSession(user.id);
    const res = NextResponse.json({ user: publicUser(user, tierOf(user)) });
    res.headers.append("Set-Cookie", buildAuthCookie(token));
    res.headers.append("Set-Cookie", buildSessionCookie(user.sessionId));
    return res;
  } catch (err) {
    console.error("login error:", err);
    return jsonError("مشکلی در ورود پیش آمد.", "server_error", 500);
  }
}
