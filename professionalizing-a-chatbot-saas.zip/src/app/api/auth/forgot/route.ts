import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { passwordResets, users } from "@/db/schema";
import { guardJson, jsonError, limitByIp } from "@/lib/http";
import { appBaseUrl, sendMail } from "@/lib/mail";
import { normalizeEmail, randomToken, sha256 } from "@/lib/password";

export const dynamic = "force-dynamic";

const schema = z.object({ email: z.string().trim().max(254) });

/** همیشه پاسخ یکسان می‌دهد تا وجود یا نبود ایمیل فاش نشود */
export async function POST(req: Request) {
  try {
    const bad = guardJson(req);
    if (bad) return bad;
    const limited = await limitByIp(req, "forgot", [{ limit: 5, windowMs: 60 * 60 * 1000 }]);
    if (limited) return limited;

    const parsed = schema.safeParse(await req.json().catch(() => null));
    if (parsed.success) {
      const email = normalizeEmail(parsed.data.email);
      const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
      const user = rows[0];
      if (user && !user.blocked) {
        const token = randomToken();
        await db.insert(passwordResets).values({
          tokenHash: sha256(token),
          userId: user.id,
          expiresAt: new Date(Date.now() + 60 * 60 * 1000),
        });
        const link = `${appBaseUrl(req)}/reset?token=${token}`;
        await sendMail(
          user.email,
          "بازیابی رمز عبور نُوا / Nova password reset",
          `برای انتخاب رمز جدید این لینک را باز کن (یک ساعت اعتبار دارد):\n${link}\n\nOpen this link to set a new password (valid for 1 hour):\n${link}`
        );
      }
    }
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("forgot error:", err);
    return jsonError("مشکلی پیش آمد.", "server_error", 500);
  }
}
