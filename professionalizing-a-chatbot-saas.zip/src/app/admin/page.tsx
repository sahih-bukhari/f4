import { AdminClient } from "@/components/account/AdminClient";

export const dynamic = "force-dynamic";

export const metadata = { robots: { index: false, follow: false } };

export default function Page() {
  return <AdminClient />;
}
