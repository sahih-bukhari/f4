import { NextRequest, NextResponse } from "next/server";

/**
 * هدرهای امنیتی پروداکشن روی تمام پاسخ‌ها.
 * CSP به‌گونه‌ای تنظیم شده که با Next.js (اسکریپت‌های درون‌خطی RSC و فونت CDN) سازگار باشد.
 */
const SECURITY_HEADERS: Record<string, string> = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy":
    "camera=(), geolocation=(), payment=(), usb=(), microphone=(self)",
  "Cross-Origin-Opener-Policy": "same-origin",
  "X-DNS-Prefetch-Control": "on",
  "Strict-Transport-Security": "max-age=63072000; includeSubDomains; preload",
};

const CSP = [
  "default-src 'self'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  "object-src 'none'",
  // Next.js برای استریم RSC به اسکریپت درون‌خطی نیاز دارد
  "script-src 'self' 'unsafe-inline'",
  "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net",
  "font-src 'self' data: https://cdn.jsdelivr.net",
  "img-src 'self' data: https:",
  "media-src 'self'",
  "connect-src 'self'",
  "worker-src 'self' blob:",
].join("; ");

export function middleware(req: NextRequest) {
  const res = NextResponse.next({ request: { headers: req.headers } });
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.headers.set(k, v);
  res.headers.set("Content-Security-Policy", CSP);
  // پاسخ‌های API هرگز کش نشوند
  if (req.nextUrl.pathname.startsWith("/api/")) {
    res.headers.set("Cache-Control", "no-store");
  }
  return res;
}

export const config = {
  matcher: [
    /*
     * همه‌ی مسیرها به‌جز فایل‌های استاتیک داخلی Next و تصاویر عمومی
     * (هدرها روی آن‌ها هم می‌توانست بیاید؛ این‌طوری سبک‌تر است)
     */
    "/((?!_next/static|_next/image|favicon.ico|images/).*)",
  ],
};
